# Capacity Engine v2 — offline rough-cut planning source package

**Python 3.11+; standard library only; no installation or network required.** This is an independent calculation foundation, not an Excel repair, an ERP connection, a UI, or finite/optimal APS. Chase remains blocked pending operating inputs. All examples under `examples/synthetic/` are invented test data, never Chase operations.

## One-command quick start

From this directory:

```sh
python -m capacity_engine plan examples/synthetic/two_site.json --output verification/example_plan.json --csv-dir verification/example_csv
```

Run the deterministic tests: `python -m unittest discover -s tests -v`.

## Stable entry contract

```sh
python -m capacity_engine validate CONFIG.json [--demand-csv RELEASES.csv] [--output RESULT.json]
python -m capacity_engine plan CONFIG.json [--demand-csv RELEASES.csv] [--output PLAN.json] [--csv-dir DIRECTORY]
python -m capacity_engine scenario CONFIG.json SCENARIO.json [--output PLAN.json] [--config-output UPDATED.json]
python -m capacity_engine history-audit HISTORY.json [--output AUDIT.json]
```

Commands emit JSON to stdout unless `--output` is provided. Exit **0** means physically evaluable (`Ready` or `No demand`); **2** means `Blocked` or invalid input. Financial gates are reported separately and never turn missing wages into zero cost. `Ready` is a validated day-bucket calculation, NOT a claim that a forecast is operationally approved or executable at intraday precision. Incomplete release rows remain visible and make their facility `Blocked`, even when other complete rows have a partial plan.

Importable API: `from capacity_engine import validate_config, plan, apply_scenario, audit_history`. Each accepts an ordinary configuration dictionary; `validate_config` returns a frozen `ValidationResult` (`.as_dict()`); the other functions return dictionaries and do not mutate their inputs. Decimal outputs serialize as decimal strings, not binary floats. `apply_scenario` returns a deep-copied updated configuration; `plan(apply_scenario(base, change))` performs its calculation.

## Inputs and everyday operation

`schema/input_contract.json` is a structural JSON Schema plus semantic notes; executable `validate_config` is the authoritative cross-record validator. No external JSON Schema library is needed. `examples/synthetic/two_site.json` is a complete, hand-checkable **invented** example. It produces 5 units at SYNTHETIC_A and 2 at SYNTHETIC_B, not a Chase forecast.

1. Update a **new version** of your approved JSON configuration. Never promote fixture values into a live facility. Dates use `YYYY-MM-DD`; decimal strings are preferred. Unknown is `null` or a missing field and blocks its required gate; explicit `0` is a known zero.
2. Set `as_of`, configuration approval, evidence records and a deliberate freshness policy. Every assumption references evidence by ID. An approval record documents a human assertion; **it is not authentication, authorization or RBAC**. Unapproved physical assumptions block. Stale referenced evidence blocks unless the configuration explicitly requests warnings; future-dated evidence/approvals are rejected.
3. Set each facility's inclusive `horizon.start`, `end`, and `occupancy_end`. Supply every labor/machine calendar day through `end`, including explicit zero/closed days. Space needs every calendar day through the occupancy tail, weekends included. Bounds are 1–366 planning days and at most 732 occupied days; unsupported/invalid spans are bounded before date expansion.
4. Declare family/resource/stock keys and effective routes. Every route must state `required` or `not_required` for **every** declared resource. Missing route, missing BOM, unknown snapshot or blank applicability is not free capacity. All production units are whole `EA`; material UOMs are `EA`, `KG`, `LB`, `M`, `FT`, `L`, `SQFT`, with exact matches and no implicit conversions. Numeric inputs are finite, nonnegative, at most 1e12 with 12 fractional decimal places; integer fields cannot be booleans or fractions.
5. Load approved releases in JSON, or replace all releases with canonical CSV using `--demand-csv`. See `schema/demand_template.csv`; `examples/synthetic/demand_releases.csv` is a populated synthetic sample. Missing quantity/UOM/family/release/due fields remain a visible incomplete queue and block a complete-facility readiness claim. A header-only CSV intentionally removes all demand: do not use it to stand in for an unknown snapshot.
6. Run `validate`, then `plan`; inspect both physical and financial statuses, unplanned reasons, full occupied tail, source freshness and per-period loads. A no-exception run alone is not acceptance. Obtain an operational review before treating a modeled date as a planning assumption.

To add a facility, add a new object to `facilities`, with independently owned resource/stock/workforce identities, calendars, family routes and releases. **No code change and no prescribed family names/count are required.** Change a rolling horizon only after reconciling opening stock, quality authorizations and starting WIP; do not append old backlog to the same release snapshot. Outstanding quantities are counted once per business key. This engine does not automatically roll partial starting jobs into a new run.

## Method and physical semantics

This is a deterministic **day-bucket rough-cut greedy allocator**, not optimal or finite APS. It iterates candidate start dates, then ascending explicit priority (0 first), earliest selected due date, and business key. A monotonic integer search finds the maximum feasible quantity for that release/date lot. All required gates must pass. An earlier due date does not authorize an earlier release or negative inventory. Late allocations are allowed and reported; they are not promises. Default due policy uses the customer-requested date; `promised_then_requested` is explicit. Internal expected dates never silently become customer dates.

- **Timing:** BOM and quality production authorization must be available at the **opening of the start date**. Same-date receipts mean available at opening, not sometime that afternoon. Operations consume their resource only on `start + offset_days`; `offset_days < lead_days`. Modeled shipment is `start + lead_days` at the opening of that date (`lead_days >= 1`). Starts/shipments stay inside the planning horizon; no future completion is credited outside it. Routes lock to the effective version at start; wage costs use each operation date; shipment values use the modeled shipment date. No later resource or receipt is borrowed into an earlier dated operation.
- **Labor:** Each pool has one fixed simultaneous crew size and maximum concurrent crews. Per shift, crews = `min(floor(qualified_headcount * attendance / crew_size), max_concurrent_crews)`. Capacity = whole crews × crew size × paid regular/OT hours × productive fraction, less explicit productive-hour external reservations. Qualified-but-uncrewed expected attendance remains in staffed payroll, not productive capacity. Shifts in one pool cannot overlap or cross midnight; split overnight calendars explicitly. Productive hours are not clock/pay hours. Heterogeneous crew sizes in one shared pool are unsupported and block.
- **Shared pools:** Any number of families and route stages reference the **same facility resource ID**, consuming one ledger and one staffed payroll budget. Do not copy a pool into multiple family/resource objects. Physical-pool, stock and workforce ownership identifiers prevent known duplication. **Cross-site shared-pool scheduling is unimplemented and explicitly Blocked** (`UNSUPPORTED_CROSS_SITE_SHARED_POOL`); it is not counted as supported shared planning. Sites run independently; no implicit cross-site transfers, labor borrowing, alternate routes or inventory reuse. Declared IDs cannot detect deliberately mislabeled real-world duplicate assets; ownership reconciliation remains a human control.
- **Machines:** Net machine-hours = `(count * scheduled_hours - total maintenance_hours) * uptime * performance - reserved_hours`. Maintenance is total machine-hours, not hours per machine. Availability and performance are separate; there is no additional yield/OEE factor. Calendar losses must not already be bundled in nominal routing standards.
- **Routes/rework/setups:** Per-resource load = whole units × (first-pass + separately measured rework hours) + `ceil(units / batch_size)` × setup hours. For `rework_mode=\"bundled\"`, the first-pass field is the bundled standard and incremental rework must be exactly zero. No extra yield/rework deduction is applied. A partial last batch pays its full setup; releases and start dates do not co-batch. Setup-only operations are supported. The model does not prove intraday sequence or synchronization, single-part nonpreemption, exact failure timing, crew interchangeability or finite machine assignments; day-bucket standards require human approval as suitable for rough-cut use.
- **Space:** Occupied footprint is `(length_ft + 2*clearance_ft) * (width_ft + 2*clearance_ft)`. Every unit consumes that full area and one concurrent slot on **every** date in `[start+offset, start+offset+dwell_days)`, including weekends and the tail. Current WIP/calendar reservations are deducted before planning. Peak area and peak slots are hard daily checks, never average area-day ceilings. Space exposure beyond the explicitly dated tail rejects the start. PSF is financial only.
- **Materials/quality:** Opening stock must be dated exactly at horizon start, with explicit on-hand, external allocation and safety stock. Protected stock is never reused; all family BOMs share the same stock ledger. Ready receipts accumulate by date, and consumption conserves stock. Opening quality authorizations plus dated releases are a separate consumable whole-unit production gate, not a fabricated yield percentage or final inspection schedule.
- **WIP:** `confirmed_none` requires evidence; no default zero-WIP assumption exists. `external_reservations_only` supports non-model occupied area/slots plus separate dated labor/machine reservations and protected materials. Unknown WIP and partial **modeled** starting WIP are unsupported and block. External WIP cannot generate output or satisfy active demand.

## Money, scenarios and diagnostics

Labor rates require `rate_unit=currency_per_paid_person_hour`; annual salary values are **not** accepted as hourly. Supply effective base wage, OT multiplier (at least 1), employer burden per paid hour and currency. Shipment prices require `currency_per_EA`; occupied-area rates use `currency_per_sqft_day`. Overlapping effective rates, missing coverage, unapproved rates or inconsistent currencies block the affected financial metric, not physical units. Validated zero rates are different from missing rates.

Outputs keep **expected staffed payroll** (attendance-adjusted paid regular/OT hours, including unproductive and uncrewed time) separate from **allocated touch labor** (productive hours rate-costed regular first, then OT). Touch cost is not added to payroll and is not a paid-hours allocation. Direct and loaded costs are separate. Money is retained as Decimal, with no intermediate cent rounding and no implicit FX. Each facility/metric has separate currency buckets; there is no cross-currency grand total. Shipment value is **not recognized revenue, margin, profitability or cash**.

`scenario` deep-copies a physically validated baseline and applies a bounded set of existing numeric-leaf replacements. Example: `examples/synthetic/rework_scenario.json`. IDs, routing applicability, dates, site ownership and structure cannot be changed via this shortcut; change/version/revalidate a baseline for those. Scenario metadata records source/version/approval, baseline hash, changed paths and new evidence ownership. Rework reductions need dated quality approval and separately measured rework; bundled standards cannot be discounted through a scenario. Invalid changes fail explicitly. Metadata approvals are not access controls.

`plan` writes:

- `status`: **Ready**, **Blocked**, or **No demand**, with separate financial status and per-facility status. Blocked physical totals are `null`, **not a zero-unit forecast**. Other independently valid sites may still have results. Both `validate` and `plan` report **Blocked** (CLI exit 2) for mixed complete/incomplete releases. Internal physical allocation gates remain separate: complete releases may receive an explicitly marked `partial_plan: true`, never overall readiness.
- Allocations with whole units, batch count, route/evidence version, start, modeled shipment and independent requested/promised/internal dates, plus lateness measures.
- Resource/date capacity, load, slack, net/gross/reservation detail; labor paid/productive/regular/OT breakdown; cumulative inventory and quality ledgers.
- Demand outcomes and dated backlog separating unstarted, in-plan WIP, completed and future-unreleased quantities; no daily re-addition or hidden discarded rows. Identical release rows collapse with a diagnostic; conflicting business-key quantities/UOM/dates block.
- `one_extra_unit_tests`: exact arithmetic shortages for one additional unit at each attempted date/lot. All listed gates must pass; this is **not** an optimization sensitivity, invented threshold, or promised throughput improvement.
- Source age, evidence/assumption versions and a deterministic SHA-256 run hash over engine version plus supplied input (input ordering/representation is part of that identity). No run-clock timestamp makes the calculation nondeterministic.

CSV exports include allocations, resource loads, demand outcomes, inventory and backlog. Formula-like text beginning with `=`, `+`, `-`, `@` or control prefixes is apostrophe-neutralized for spreadsheet safety; actual numeric values remain numeric. JSON preserves original text. No spreadsheet files are opened or edited.

## Chase provenance and readiness

`examples/chase/history.json` contains **aggregate history only** from the existing local handoff: 334 model-defined shipment records over 34 complete weeks, Jan 5–Aug 30, 2026; 2 unresolved duplicate-key excess records; 332 candidate distinct records is not an approved deduplication. Garrett Butler's supplied model designation is the business definition of shipped units. Raw completion-field labels remain provenance; independent Epicor reconciliation is a later control, not a prerequisite for respecting that definition.

`history-audit` verifies totals and exposes the factor-eight denominator error in the source recent-eight-week HPU calculation. It reports the corrected **aggregate clock-hours/record** ratio, **not a routing standard**. Clock/pay hours are not proven productive touch time. There are no raw shipment lines, employee names/IDs, individual wage rows or source spreadsheets in this package. SHA-256 provenance hashes identify the three read-only local handoff files; originals are not bundled.

`examples/chase/blocked_config.json` deliberately returns **Blocked**, with named gaps for demand, routing/lead times, qualified staffing/crews, calendar/productive hours, hourly rates/effectivity, machine losses, safe space/dwell, WIP, dated stock/BOM/receipts, quality, shipment values and currencies. No Chase forecast is populated. The held Excel draft and all existing source/Office files remain unchanged; this engine does not repair or certify that workbook.

Additional readiness evidence does **not** unblock those gaps: a separate daily enclosure-quantity population totals 328 versus the model's 334 in the same complete window; do not force agreement. Its aggregate shipment value is not a product price and its currency/cutoff need approval. Employee-list rate fields have no approved rate-effective snapshot; meeting staffing/weld notes are provisional/conflicting. No individual compensation values are ingested here. Read-only Epicor approval has not established a live connection.

See `integration/epicor_offline_mapping.json` for the **offline export** contract using observed BAQ fields only. It explicitly lists missing request/site/UOM/status/currency mappings and does not invent endpoints or connection capability. A future integration must preserve release grain, separate dates, reconcile snapshots, enforce privacy/approval/freshness, then pass the same validation/conservation checks. There are no API keys, credential stores, UI/browser/server/auth implementations or network dependencies in this unit.
