"""Independent synthetic inputs adapted to the public v2 schema.

Technical namespace prefixes disambiguate TEST_ALPHA / TEST_BETA labels in the
contract's flat resource namespace. No implementation-test fixtures are loaded.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal

A, B = "TEST_ALPHA", "TEST_BETA"
START = date(2030, 1, 7)
LABOR = "labor/" + A
MACHINE = "machine/" + B
SPACE = "space/" + A


def day(offset=0):
    return (START + timedelta(days=offset)).isoformat()


def decimal(value):
    return str(Decimal(str(value)))


def wage(currency="USD", start=0, end=30, amount=10, burden="2.5", version=A):
    return {"version": version, "effective_from": day(start), "effective_to": day(end),
            "currency": currency, "rate_unit": "currency_per_paid_person_hour",
            "base_wage": decimal(amount), "ot_multiplier": "1.5",
            "burden_per_paid_hour": decimal(burden), "evidence": A}


def value(currency="USD", amount=100, start=0, end=30, unit="currency_per_EA", version=A):
    return {"version": version, "effective_from": day(start), "effective_to": day(end),
            "currency": currency, "rate_unit": unit, "amount": decimal(amount), "evidence": A}


def demand(order=A, family=A, quantity=12, release=0, due=0, priority=1):
    return {"business_key": order, "family": family, "quantity": quantity, "uom": "EA", "status": "open",
            "priority": priority, "release_date": day(release), "customer_requested_date": day(due),
            "promised_date": None, "internal_expected_date": None, "evidence": A}


def load(resource=LABOR, hours=1, unit="person_hour", setup=0, rework=0, mode="bundled", offset=0, crew=1):
    result = {"resource": resource, "offset_days": offset, "unit": unit,
              "first_pass_hours_per_unit": decimal(hours), "rework_hours_per_unit": decimal(rework),
              "rework_mode": mode, "setup_hours_per_batch": decimal(setup)}
    if unit == "person_hour":
        result["required_crew_size"] = crew
    return result


def route(family=A, labor=1, machine=1, lead=1, dwell=1, batch=1, material=1, footprint=1,
          start=0, end=30, version=A):
    return {"family": family, "version": version, "effective_from": day(start), "effective_to": day(end),
            "lead_days": lead, "batch_size": batch, "timing_model": "day_bucket",
            "coverage": {LABOR: "required", MACHINE: "required", SPACE: "required"},
            "loads": [load(hours=labor), load(MACHINE, machine, "machine_hour")],
            "space": [{"resource": SPACE, "offset_days": 0, "length_ft": decimal(footprint),
                       "width_ft": "1", "clearance_ft": "0", "dwell_days": dwell}],
            "materials": {"status": "required", "bom": [{"stock": A, "quantity_per_unit": decimal(material), "uom": "EA"}]},
            "evidence": A}


def facility(site=A, labor_hours=8, machine_hours=8, production_days=1, tail_days=0, demand_quantity=12,
             on_hand=100, currency="USD", offset=0, max_slots=20, usable_sqft=20):
    end = offset + production_days
    occupancy_end = end + tail_days
    labor_calendar = []
    machine_calendar = []
    space_calendar = []
    for d in range(offset, end + 1):
        labor_calendar.append({"date": day(d), "shifts": [{"id": A, "workforce": site + "/" + A,
            "start_hour": "0", "qualified_headcount": 1, "attendance": "1",
            "regular_paid_hours": decimal(labor_hours if d < end else 0), "ot_paid_hours": "0", "productive_fraction": "1",
            "reserved_regular_hours": "0", "reserved_ot_hours": "0", "evidence": A}], "evidence": A})
        machine_calendar.append({"date": day(d), "count": 1, "scheduled_hours": decimal(machine_hours if d < end else 0),
            "maintenance_hours": "0", "uptime": "1", "performance": "1", "reserved_hours": "0", "evidence": A})
    for d in range(offset, occupancy_end + 1):
        space_calendar.append({"date": day(d), "usable_sqft": decimal(usable_sqft), "max_slots": max_slots,
                               "reserved_sqft": "0", "reserved_slots": 0, "evidence": A})
    return {"id": site, "name": site, "horizon": {"start": day(offset), "end": day(end), "occupancy_end": day(occupancy_end)},
        "due_date_policy": "customer_requested", "demand_snapshot": {"status": "complete", "evidence": A},
        "wip": {"state": "confirmed_none", "reservations": [], "evidence": A}, "evidence": A,
        "labor": [{"id": LABOR, "physical_pool": site + "/" + LABOR, "crew_size": 1,
                   "max_concurrent_crews": 1, "currency": currency, "calendar": labor_calendar,
                   "rates": [wage(currency, start=offset)], "evidence": A}],
        "machines": [{"id": MACHINE, "physical_pool": site + "/" + MACHINE,
                      "loss_basis": "availability_performance_only", "calendar": machine_calendar, "evidence": A}],
        "space": [{"id": SPACE, "physical_pool": site + "/" + SPACE, "currency": currency,
                   "calendar": space_calendar,
                   "psf_rates": [value(currency, amount=0, start=offset, unit="currency_per_sqft_day")], "evidence": A}],
        "stocks": [{"id": A, "physical_stock": site + "/stock/" + A, "part": A, "uom": "EA",
                    "snapshot_date": day(offset), "on_hand": decimal(on_hand), "allocated": "0", "safety_stock": "0",
                    "receipts": [], "evidence": A}],
        "families": [{"id": A, "uom": "EA", "value_currency": currency,
                      "quality": {"status": "not_required", "evidence": A},
                      "shipment_values": [value(currency, start=offset)], "evidence": A}],
        "routes": [route(start=offset)], "demands": [demand(quantity=demand_quantity, release=offset, due=end)]}


def config(**facility_options):
    offset = facility_options.get("offset", 0)
    return {"schema_version": "capacity-engine/v2",
            "metadata": {"version": A, "source": "TEST_ALPHA independent synthetic arithmetic fixture",
                         "approved": True, "approved_by": A, "approved_on": day(offset)},
            "as_of": day(offset), "synthetic": True,
            "freshness_policy": {"max_age_days": 1, "on_stale": "block"},
            "evidence": [{"id": A, "version": A, "source": "TEST_ALPHA isolated synthetic inputs, not Chase operations",
                          "as_of": day(offset), "approved": True, "approved_by": A}],
            "facilities": [facility(**facility_options)]}


def two_sites(a_hours=8, b_hours=3, **options):
    result = config(labor_hours=a_hours, **options)
    result["facilities"].append(facility(site=B, labor_hours=b_hours, **options))
    for site in result["facilities"]:
        for order in site["demands"]:
            order["business_key"] = site["id"] + "/" + order["business_key"]
    return result


def add_family(configuration, family=B, labor=1, machine=1, material=1, quantity=2, priority=1):
    f = configuration["facilities"][0]
    item = deepcopy(f["families"][0])
    item["id"] = family
    f["families"].append(item)
    f["routes"].append(route(family=family, labor=labor, machine=machine, material=material))
    f["demands"].append(demand(order=family, family=family, quantity=quantity, priority=priority))
    return configuration


def shift(configuration, site_index=0, day_index=0):
    return configuration["facilities"][site_index]["labor"][0]["calendar"][day_index]["shifts"][0]


def change(configuration, path, value):
    result = deepcopy(configuration)
    target = result
    parts = path.strip("/").split("/")
    for key in parts[:-1]:
        target = target[int(key)] if isinstance(target, list) else target[key]
    key = parts[-1]
    if isinstance(target, list):
        target[int(key)] = value
    else:
        target[key] = value
    return result


def scenario(hours=5):
    return {"schema_version": "capacity-scenario/v1", "id": B, "version": A,
            "source": "TEST_BETA isolated acceptance scenario", "as_of": day(),
            "approved": True, "approved_by": A,
            "changes": [{"path": "/facilities/0/labor/0/calendar/0/shifts/0/regular_paid_hours", "value": decimal(hours)}]}
