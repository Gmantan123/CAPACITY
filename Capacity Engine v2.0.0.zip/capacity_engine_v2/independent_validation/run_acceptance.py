"""External, standard-library acceptance harness. Never writes into the engine.

Run: python -B run_acceptance.py --engine-root ../capacity_engine_v2 [--only TEST_ID]
Use --final only for a frozen candidate. CAPACITY_ENGINE_ROOT is also supported.
Oracles use independent input arithmetic/Fraction; implementation tests are not
imported. Results on an evolving build are provisional even if hashes are stable.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import traceback
from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal
from fractions import Fraction as F

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
ENGINE = Path(os.environ.get("CAPACITY_ENGINE_ROOT", str(ROOT.parent / "capacity_engine_v2"))).expanduser().resolve()
from contract_fixtures import A, B, LABOR, MACHINE, SPACE, config, two_sites, add_family, shift, route, demand, wage, value, day, scenario


def serial(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, F):
        return str(Decimal(value.numerator) / Decimal(value.denominator))
    raise TypeError(type(value).__name__)


def encode(value):
    return json.dumps(value, default=serial, sort_keys=True, allow_nan=False)


def checksum(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def source_snapshot():
    manifest = {}
    total = hashlib.sha256()
    files = sorted((ENGINE / "capacity_engine").glob("*.py")) + [ENGINE / "schema/input_contract.json"]
    for path in files:
        content = path.read_bytes()
        relative = str(path.relative_to(ENGINE))
        manifest[relative] = hashlib.sha256(content).hexdigest()
        total.update(relative.encode())
        total.update(content)
    return {"sha256": total.hexdigest(), "files": manifest}


def normalize(value):
    return json.loads(encode(value))


def q(value):
    return F(str(value))


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def equal(actual, expected, label):
    require(actual == expected, f"{label}: expected {expected!r}, observed {actual!r}")


def ready(result):
    require(result["status"] in ("Ready", "No demand"), "Expected physical Ready/No demand; diagnostics=" + encode(result["diagnostics"]))


def totals(result):
    return {f["id"]: f["summary"]["allocated_units"] for f in result["facilities"]}


def total(result):
    return sum(totals(result).values())


def blocked(result, code_fragment=None, financial=False):
    field = "financial_status" if financial else "status"
    equal(result[field], "Blocked", field)
    if financial:
        ready(result)
    if code_fragment:
        codes = [d["code"] for d in result["diagnostics"]]
        fragments = code_fragment.split("|")
        require(any(fragment in code for fragment in fragments for code in codes), f"Missing semantic diagnostic {code_fragment!r}: {codes}")


STRICT_BLOCKED_POLICIES = {
    "AC05_unknown_capacity": {
        "code_families": ("MISSING", "NUMBER"),
        "paths": ("/facilities/0/labor/0/calendar/0/shifts/0/regular_paid_hours",),
        "message_terms": ("number", "numeric", "capacity", "hour", "unknown", "required", "missing"),
    },
    "AC16_missing_source_date": {
        "code_families": ("MISSING", "DATE"),
        "paths": ("/evidence/0/as_of",),
        "message_terms": ("date", "timestamp", "as_of", "yyyy-mm-dd"),
    },
    "AC36_extreme_span": {
        "exact_codes": ("HORIZON_RANGE", "DATE_RANGE"),
        "paths": ("/facilities/0/horizon", "/facilities/0/horizon/start",
                  "/facilities/0/horizon/end", "/facilities/0/horizon/occupancy_end"),
        "message_terms": ("date", "day", "year", "horizon", "range", "span", "start", "end"),
    },
}
GUARD_TIMEOUT_SECONDS = 5


def assert_no_manufactured_plan(result, plan_output):
    equal(result["status"], "Blocked", "overall physical readiness")
    facilities = result.get("facilities")
    require(isinstance(facilities, list) and facilities, "Blocked facility must remain visible")
    equal({f.get("id") for f in facilities}, {A}, "affected facility remains identifiable")
    for facility in facilities:
        equal(facility.get("status"), "Blocked", "affected facility readiness")
        if plan_output or "summary" in facility:
            require("summary" in facility and "allocated_units" in facility["summary"],
                    "Blocked plan must explicitly report unknown allocated_units")
            equal(facility["summary"]["allocated_units"], None, "unknown capacity is not a zero-unit forecast")
        for key in ("allocations", "resource_loads", "inventory", "backlog"):
            if plan_output or key in facility:
                equal(facility.get(key), [], "blocked inputs must not fabricate " + key)
        for outcome in facility.get("demand_outcomes", []):
            require("allocated_quantity" in outcome, "Blocked demand must expose unknown allocation")
            equal(outcome["allocated_quantity"], None, "blocked allocation must remain unknown")
        if plan_output:
            equal(facility.get("financials", {}).get("status"), "Blocked", "blocked plan financial status")


def assert_guarded_block(result, case_id, plan_output=True):
    policy = STRICT_BLOCKED_POLICIES[case_id]
    assert_no_manufactured_plan(result, plan_output)
    matches = []
    for diagnostic in result.get("diagnostics", []):
        code = diagnostic.get("code", "")
        allowed = code in policy.get("exact_codes", ()) or any(
            code == family or code.startswith(family + "_")
            for family in policy.get("code_families", ()))
        message = diagnostic.get("message")
        if (allowed and diagnostic.get("severity") == "block"
                and diagnostic.get("path") in policy["paths"]
                and isinstance(message, str) and message.strip()
                and any(term in message.lower() for term in policy["message_terms"])):
            matches.append(diagnostic)
    require(matches, "Missing blocking diagnostic with equivalent code, correct offending path, and meaningful message: " + encode(result.get("diagnostics", [])))
    return matches


def expect_guarded_block(case_id):
    return lambda inp, result, api: assert_guarded_block(result, case_id)


def allocation_signature(result):
    return sorted((site["id"], row["business_key"], row["family"], str(row["start_date"]),
                   str(row["modeled_ship_date"]), row["quantity"])
                  for site in result["facilities"] for row in site["allocations"])


def simple_count(expected, site_values=None):
    def check(inp, result, api):
        ready(result)
        equal(total(result), expected, "allocated units")
        if site_values:
            equal(totals(result), site_values, "facility isolation")
    return check


def expect_block(code=None, financial=False):
    return lambda inp, result, api: blocked(result, code, financial)


def financial_number(result, metric, currency="USD", field="loaded_by_currency", site_index=0):
    values = result["facilities"][site_index]["financials"][metric][field]
    require(values is not None, f"Unknown {metric} cannot be normalized to zero")
    return q(values.get(currency, "0"))


def conservation(inp, result):
    """Reconstruct loads, inventory prefixes, demand and physical bounds from inputs."""
    for site_out in result["facilities"]:
        if site_out["status"] == "Blocked":
            continue
        site = next(x for x in inp["facilities"] if x["id"] == site_out["id"])
        capacity, expected_load = {}, defaultdict(F)
        material_use = defaultdict(F)
        quality_use = defaultdict(int)
        allocated = defaultdict(int)
        for pool in site["labor"]:
            for calendar in pool["calendar"]:
                capacity[(pool["id"], calendar["date"], "labor")] = sum(
                    (min(math.floor(q(s["qualified_headcount"]) * q(s["attendance"]) / q(pool["crew_size"])),
                         int(pool["max_concurrent_crews"])) * q(pool["crew_size"])
                     * (q(s["regular_paid_hours"]) + q(s["ot_paid_hours"])) * q(s["productive_fraction"])
                     - q(s["reserved_regular_hours"]) - q(s["reserved_ot_hours"]))
                    for s in calendar["shifts"])
        for pool in site["machines"]:
            for row in pool["calendar"]:
                capacity[(pool["id"], row["date"], "machine")] = (
                    (q(row["count"]) * q(row["scheduled_hours"]) - q(row["maintenance_hours"]))
                    * q(row["uptime"]) * q(row["performance"]) - q(row["reserved_hours"]))
        for pool in site["space"]:
            for row in pool["calendar"]:
                reservations = [r for r in site["wip"]["reservations"]
                                if r["resource"] == pool["id"] and r["from"] <= row["date"] <= r["through"]]
                capacity[(pool["id"], row["date"], "space_area")] = q(row["usable_sqft"]) - q(row["reserved_sqft"]) - sum((q(r["sqft"]) for r in reservations), F(0))
                capacity[(pool["id"], row["date"], "space_slots")] = q(row["max_slots"]) - q(row["reserved_slots"]) - sum((q(r["slots"]) for r in reservations), F(0))
        seen_allocations = set()
        for row in site_out["allocations"]:
            qty = row["quantity"]
            require(isinstance(qty, int) and not isinstance(qty, bool) and qty > 0, "Nonpositive/fractional allocation")
            started = str(row["start_date"])
            shipped = str(row["modeled_ship_date"])
            identity = (row["business_key"], started)
            require(identity not in seen_allocations, "Duplicate order/date allocation")
            seen_allocations.add(identity)
            applicable = [r for r in site["routes"] if r["family"] == row["family"] and r["effective_from"] <= started <= r["effective_to"]]
            equal(len(applicable), 1, "effective route count")
            r = applicable[0]
            equal(shipped, (date.fromisoformat(started) + timedelta(days=int(r["lead_days"]))).isoformat(), "lead release")
            order = next(d for d in site["demands"] if d["business_key"] == row["business_key"])
            require(started >= order["release_date"], "Start before customer release")
            allocated[row["business_key"]] += qty
            batches = math.ceil(F(qty, int(r["batch_size"])))
            for load in r["loads"]:
                when = (date.fromisoformat(started) + timedelta(days=int(load["offset_days"]))).isoformat()
                kind = "labor" if load["unit"] == "person_hour" else "machine"
                expected_load[(load["resource"], when, kind)] += qty * (q(load["first_pass_hours_per_unit"]) + q(load["rework_hours_per_unit"])) + batches * q(load["setup_hours_per_batch"])
            for space in r["space"]:
                footprint = (q(space["length_ft"]) + 2*q(space["clearance_ft"])) * (q(space["width_ft"]) + 2*q(space["clearance_ft"]))
                for offset in range(int(space["offset_days"]), int(space["offset_days"]) + int(space["dwell_days"])):
                    when = (date.fromisoformat(started) + timedelta(days=offset)).isoformat()
                    expected_load[(space["resource"], when, "space_area")] += qty * footprint
                    expected_load[(space["resource"], when, "space_slots")] += qty
            for bom in r["materials"]["bom"]:
                material_use[(bom["stock"], started)] += qty * q(bom["quantity_per_unit"])
            quality_use[(row["family"], started)] += qty
        reported_rows = {(r["resource"], str(r["date"]), r["kind"]): r for r in site_out["resource_loads"]}
        equal(len(reported_rows), len(site_out["resource_loads"]), "unique resource/date/kind rows")
        equal(set(reported_rows), set(capacity), "complete resource calendar reporting")
        for key, cap in capacity.items():
            used = expected_load[key]
            require(0 <= used <= cap, f"Per-date capacity exceeded {site['id']}/{key}: {used}>{cap}")
            equal(q(reported_rows[key]["capacity"]), cap, f"reported capacity {key}")
            equal(q(reported_rows[key]["load"]), used, f"reported reconstructed load {key}")
            equal(q(reported_rows[key]["slack"]), cap-used, f"reported slack {key}")
        require(set(expected_load) <= set(capacity), "Resource usage outside declared capacity calendar")
        inventory_rows = {(r["stock"], str(r["date"])): r for r in site_out["inventory"]}
        start, end = date.fromisoformat(site["horizon"]["start"]), date.fromisoformat(site["horizon"]["end"])
        for stock in site["stocks"]:
            balance = q(stock["on_hand"])
            protected = q(stock["allocated"]) + q(stock["safety_stock"])
            for offset in range((end-start).days + 1):
                when = (start+timedelta(days=offset)).isoformat()
                received = sum((q(x["quantity"]) for x in stock["receipts"] if x["date"] == when), F(0))
                balance += received - material_use[(stock["id"], when)]
                require(balance >= protected, f"Prefix stock deficit {stock['id']} on {when}")
                row = inventory_rows[(stock["id"], when)]
                equal(q(row["ending_on_hand"]), balance, "reconstructed inventory balance")
                equal(q(row["consumed"]), material_use[(stock["id"], when)], "material issued once")
        seen_demands = set()
        for d in site["demands"]:
            if d["business_key"] in seen_demands:
                continue
            seen_demands.add(d["business_key"])
            if d["status"] != "open" or d["quantity"] is None:
                continue
            require(0 <= allocated[d["business_key"]] <= d["quantity"], "Demand over-allocation")
        for row in site_out["backlog"]:
            when, key = str(row["date"]), row["business_key"]
            order = next(d for d in site["demands"] if d["business_key"] == key)
            released = order["quantity"] if order["release_date"] <= when else 0
            rows = [a for a in site_out["allocations"] if a["business_key"] == key]
            begun = sum(a["quantity"] for a in rows if str(a["start_date"]) <= when)
            complete = sum(a["quantity"] for a in rows if str(a["modeled_ship_date"]) <= when)
            equal(row["open_quantity"], released-complete, "persistent backlog")
            equal(row["in_plan_wip_quantity"], begun-complete, "in-plan WIP")
            equal(row["unstarted_quantity"], released-begun, "unstarted demand")
            require(0 <= complete <= begun <= released, "Prefix production/demand conservation")
        for family in site["families"]:
            gate = family["quality"]
            if gate["status"] != "required":
                continue
            allowance = q(gate["released_units"])
            for offset in range((end-start).days+1):
                when = (start+timedelta(days=offset)).isoformat()
                allowance += sum((q(r["quantity"]) for r in gate["releases"] if r["date"] == when), F(0))
                allowance -= quality_use[(family["id"], when)]
                require(allowance >= 0, "Dated quality allowance overspent")


INCOMPLETE_REGRESSION_PREFIX = "AC26_incomplete_"


def incomplete_release_fixture():
    inp=two_sites(4,3,demand_quantity=2)
    inp["facilities"][0]["demands"].append(demand(A+"/"+B,quantity=None,due=1))
    inp["facilities"][1]["demands"][0]["quantity"]=3
    return inp


def assert_incomplete_readiness(result, plan_output):
    equal(result["status"],"Blocked","incomplete release overall readiness")
    equal({f["id"]:f["status"] for f in result["facilities"]},
          {A:"Blocked",B:"Ready"},"affected and independent facility readiness")
    diagnostics=[d for d in result.get("diagnostics",[]) if d.get("code")=="INCOMPLETE_DEMAND"
                 and d.get("path")=="/facilities/0/demands/1" and d.get("facility")==A
                 and "quantity" in d.get("message","").lower()]
    require(diagnostics,"Incomplete quantity must remain visible with its offending release path")
    if not plan_output:
        return
    affected=next(f for f in result["facilities"] if f["id"]==A)
    independent=next(f for f in result["facilities"] if f["id"]==B)
    equal(affected["partial_plan"],True,"complete releases retain explicitly partial allocations")
    equal(affected["summary"]["incomplete_release_count"],1,"unknown release remains counted")
    equal(affected["summary"]["allocated_units"],min(2,4),"complete affected-site demand remains allocatable")
    equal(independent["summary"]["allocated_units"],min(3,3),"independent ready facility remains allocatable")
    unknown_key=A+"/"+B
    outcomes={row["business_key"]:row for row in affected["demand_outcomes"]}
    equal(set(outcomes),{A+"/"+A,unknown_key},"no complete or incomplete release silently dropped")
    equal(outcomes[unknown_key]["input_quantity"],None,"unknown original quantity is not zero")
    equal(outcomes[unknown_key]["unserved_quantity"],None,"unknown outstanding quantity is not zero")
    equal(outcomes[unknown_key]["status"],"Queued incomplete","unknown release is visibly queued")
    require(not any(row["business_key"]==unknown_key for row in affected["allocations"]),
            "Unknown release must not receive a manufactured allocation")


def check_incomplete_validate_api(inp,result,api):
    assert_incomplete_readiness(result,True)
    before=checksum(inp)
    exported=api["validate_config"](inp).as_dict()
    api["observations"]["validate_api"]=exported
    equal(checksum(inp),before,"validation preserves unknown input quantity")
    assert_incomplete_readiness(exported,False)
    conservation(inp,result)


def check_incomplete_plan_api(inp,result,api):
    assert_incomplete_readiness(result,True)
    conservation(inp,result)


def check_incomplete_cli(command):
    def check(inp,result,api):
        assert_incomplete_readiness(result,True)
        input_path=ROOT/"inputs"/(INCOMPLETE_REGRESSION_PREFIX+command+"_cli.json")
        input_path.write_text(json.dumps(inp,indent=2,allow_nan=False)+"\n")
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONPATH=str(ENGINE))
        started=time.monotonic()
        completed=subprocess.run([sys.executable,"-B","-m","capacity_engine",command,str(input_path)],
                                 cwd=ROOT,env=env,capture_output=True,text=True,timeout=GUARD_TIMEOUT_SECONDS)
        elapsed=time.monotonic()-started
        parsed=json.loads(completed.stdout)
        api["observations"][command+"_cli"]={"returncode":completed.returncode,"elapsed_seconds":elapsed,"output":parsed}
        equal(completed.returncode,2,"incomplete release CLI "+command+" exit")
        require(elapsed<=GUARD_TIMEOUT_SECONDS,"Incomplete-release CLI exceeded harness timeout")
        assert_incomplete_readiness(parsed,command=="plan")
        if command=="plan":
            conservation(inp,parsed)
    return check


def cases():
    items = []
    def add(key, domain, inp, expected, check, coverage="mapped_scalar_or_invariant"):
        items.append({"id": key, "domain": domain, "config": inp, "expected": expected, "check": check, "coverage": coverage})
    add("AC01_ordinary", "AC01", config(), {"units": min(12, 8, 8)}, simple_count(min(12, 8, 8)))
    add("AC02_isolation", "AC02", two_sites(), {A: min(12,8), B: min(12,3)}, simple_count(min(12,8)+min(12,3), {A:8,B:3}))
    x=two_sites(8,8)
    for f in x["facilities"]: f["labor"][0]["physical_pool"]="global/"+A
    add("AC03_shared_global_budget", "AC03", x, {"capability":"shared cross-site budget, not duplicate rejection"},
        lambda i,r,a: blocked(r,"UNSUPPORTED_CROSS_SITE_SHARED_POOL"), "deferred_capability")
    x=config(); clone=copy.deepcopy(x["facilities"][0]["labor"][0]); clone["id"]="labor/"+B
    x["facilities"][0]["labor"].append(clone); x["facilities"][0]["routes"][0]["coverage"][clone["id"]]="not_required"
    add("AC03_duplicate_budget_guard", "AC03", x, {"status":"Blocked"}, expect_block("DUPLICATED_PHYSICAL_POOL"), "validation_only_not_shared_allocation")
    add("AC04_zero", "AC04", config(labor_hours=0,demand_quantity=6), {"units":0//1}, simple_count(0//1))
    x=config(); shift(x)["regular_paid_hours"]=None
    add("AC05_unknown_capacity", "AC05", x, {"status":"Blocked"}, expect_guarded_block("AC05_unknown_capacity"))
    x=config(); x["facilities"][0]["machines"][0]["calendar"].pop(0)
    add("AC05_missing_calendar", "AC05", x, {"status":"Blocked"}, expect_block("CALENDAR"))
    x=config(labor_hours=6,machine_hours=20,demand_quantity=20)
    x["facilities"][0]["labor"][0].update(crew_size=2,max_concurrent_crews=2)
    shift(x)["qualified_headcount"]=5
    x["facilities"][0]["routes"][0]["loads"][0].update(first_pass_hours_per_unit="2",required_crew_size=2)
    add("AC06_complete_crews", "AC06", x, {"units":(5//2)*6}, simple_count((5//2)*6))
    y=copy.deepcopy(x); y["facilities"][0]["labor"][0].update(crew_size=1,max_concurrent_crews=5)
    y["facilities"][0]["routes"][0]["loads"][0]["required_crew_size"]=1
    add("AC06_divisible_person_hours", "AC06", y, {"units":(5*6)//2}, simple_count((5*6)//2))
    x=config(labor_hours=20,machine_hours=8)
    x["facilities"][0]["machines"][0]["calendar"][0].update(count=2,maintenance_hours="3")
    x["facilities"][0]["routes"][0]["loads"][1]["first_pass_hours_per_unit"]="2"
    add("AC07_downtime_union_aggregated", "AC07", x, {"units":(2*8-3)//2}, simple_count((2*8-3)//2), "daily_net_downtime_only_not_intraday_union_parser")
    x=config(labor_hours=10,machine_hours=20); r=x["facilities"][0]["routes"][0]; r["batch_size"]=3; r["loads"][0]["setup_hours_per_batch"]="2"
    n=max(n for n in range(13) if n+2*math.ceil(F(n,3))<=10)
    add("AC08_fixed_setup_hours", "AC08", x, {"units":n}, simple_count(n), "physical_setup_only_nonlabor_batch_charge_deferred")
    x=config(labor_hours=12,machine_hours=4); x["facilities"][0]["routes"][0]["loads"][0]["first_pass_hours_per_unit"]="2"
    add("AC09_bottleneck", "AC09", x, {"units":min(12//2,4)}, simple_count(min(12//2,4)))
    x=config(machine_hours=6,demand_quantity=0); x["facilities"][0]["routes"][0]=route(labor="0.1",machine="0.1")
    add_family(x,labor=1,machine=2,quantity=12)
    add("AC10_product_route", "AC10", x, {"units":min(8,6//2)}, simple_count(min(8,6//2)))
    y=copy.deepcopy(x); y["facilities"][0]["routes"].pop()
    add("AC10_missing_route", "AC10", y, {"status":"Blocked"}, expect_block("MISSING_ROUTE"))
    x=config(on_hand=5,demand_quantity=2); x["facilities"][0]["routes"][0]=route(material=2); add_family(x,material=3,quantity=2)
    def shared_material(i,r,a):
        ready(r); require(total(r)<=max(u+v for u in range(3) for v in range(3) if 2*u+3*v<=5),"Shared stock double-spent")
    add("AC11_shared_material", "AC11", x, {"total_bound":max(u+v for u in range(3) for v in range(3) if 2*u+3*v<=5)}, shared_material)
    x=config(production_days=2,labor_hours=3,machine_hours=3,on_hand=1,demand_quantity=3)
    x["facilities"][0]["stocks"][0]["receipts"]=[{"id":A,"date":day(1),"quantity":"3","evidence":A}]
    x["facilities"][0]["routes"][0]=route(material=2)
    def future(i,r,a):
        ready(r); equal(total(r),(1+3)//2,"receipt-limited total")
        require(all(str(v["start_date"])>=day(1) for v in r["facilities"][0]["allocations"]),"Future material borrowed backwards")
    add("AC12_future_receipt", "AC12", x, {"first_date_units":1//2,"total_units":(1+3)//2}, future)
    x=config(production_days=2,labor_hours=4,machine_hours=4,demand_quantity=3)
    x["facilities"][0]["demands"]=[demand(A,quantity=5-3,due=-1),demand(B,quantity=3,due=0)]
    shift(x,day_index=1)["regular_paid_hours"]="1"; x["facilities"][0]["machines"][0]["calendar"][1]["scheduled_hours"]="1"
    def backlog(i,r,a):
        ready(r); equal(total(r),(5-3)+3,"outstanding orders counted once")
        per_day=Counter()
        for row in r["facilities"][0]["allocations"]: per_day[str(row["start_date"])]+=row["quantity"]
        equal(dict(per_day),{day():4,day(1):1},"partial start batches")
    add("AC14_partial_backlog", "AC14", x, {"starts":[4,((5-3)+3)-4]}, backlog, "in_horizon_backlog_only_external_history_import_deferred")
    x=config(); x["facilities"][0]["demands"]=[]
    def no_demand(i,r,a):
        equal(r["status"],"No demand","no-demand status"); equal(total(r),0,"no speculative units")
        equal(financial_number(r,"expected_staffed_payroll"),F(8)*F(25,2),"paid labor with no demand")
        equal(financial_number(r,"allocated_touch_labor"),F(0),"zero touch")
    add("AC15_no_demand", "AC15", x, {"units":0,"paid_USD":8*F(25,2),"touch_USD":F(0)}, no_demand)
    x=config(); x["evidence"][0]["as_of"]=day(-2)
    add("AC16_stale_source", "AC16", x, {"status":"Blocked"}, expect_block("STALE"))
    x=config(); x["evidence"][0]["as_of"]=None
    add("AC16_missing_source_date", "AC16", x, {"status":"Blocked"}, expect_guarded_block("AC16_missing_source_date"))
    x=config(); x["metadata"]["approved"]=False
    add("AC17_unapproved", "AC17", x, {"status":"Blocked"}, expect_block("UNAPPROVED"))
    x=config(demand_quantity=2,max_slots=2,usable_sqft=5); x["facilities"][0]["routes"][0]=route(footprint=3)
    add("AC18_peak_area", "AC18", x, {"units":5//3}, simple_count(5//3), "equivalent_footprint_dimension_day_bucket")
    x=config(production_days=2,labor_hours=1,machine_hours=1,demand_quantity=2,max_slots=1,usable_sqft=3)
    x["facilities"][0]["routes"][0]=route(footprint=3)
    add("AC18_sequential_boundary", "AC18", x, {"units":1+1}, simple_count(1+1))
    x=config(offset=4,production_days=3,labor_hours=1,machine_hours=1,demand_quantity=1,max_slots=1,usable_sqft=2)
    for idx in range(1,4):
        shift(x,day_index=idx)["regular_paid_hours"]="0"; x["facilities"][0]["machines"][0]["calendar"][idx]["scheduled_hours"]="0"
    x["facilities"][0]["routes"][0]=route(start=4,lead=3,dwell=3,footprint=2)
    def weekend(i,r,a):
        ready(r); equal(total(r),1,"weekend witness")
        rows={str(v["date"]):q(v["load"]) for v in r["facilities"][0]["resource_loads"] if v["kind"]=="space_area"}
        equal(rows,{day(d):F(2*int(d<7)) for d in range(4,8)},"calendar dwell across closed weekend")
    add("AC19_weekend_dwell", "AC19", x, {"occupied_dates":[day(d) for d in range(4,7)]}, weekend, "calendar_dwell_not_active_opening_WIP")
    x=config(tail_days=2,demand_quantity=1); x["facilities"][0]["routes"][0]=route(dwell=4)
    def tail(i,r,a):
        ready(r); equal(total(r),1,"tail witness")
        for row in r["facilities"][0]["resource_loads"]:
            if row["kind"]=="space_slots": equal(q(row["load"]),F(1),"retained occupied tail")
    add("AC20_occupied_tail", "AC20", x, {"occupied_days":1+1+2}, tail, "post_shipment_occupancy_tail_not_post_horizon_new_WIP")
    x=config(demand_quantity=6); shift(x)["reserved_regular_hours"]=str(3+2)
    add("AC21_reserved_budget", "AC21", x, {"new_units":8-3-2}, simple_count(8-3-2), "external_reserved_hours_only_active_WIP_deferred")
    x=config(production_days=2,labor_hours=1,machine_hours=1,demand_quantity=2)
    x["facilities"][0]["labor"][0]["rates"]=[wage(start=0,end=1),wage(start=1,end=2,amount=12,burden=3,version=B)]
    add("AC22_overlapping_rates", "AC22", x, {"physical":"Ready","financial":"Blocked"}, expect_block("OVERLAPPING_EFFECTIVITY",True))
    y=copy.deepcopy(x); y["facilities"][0]["labor"][0]["rates"]=[wage(start=0,end=0),wage(start=2,end=2,amount=12,burden=3,version=B)]
    add("AC22_rate_gap", "AC22", y, {"physical":"Ready","financial":"Blocked"}, expect_block(financial=True))
    y=copy.deepcopy(x); y["facilities"][0]["labor"][0]["rates"]=[wage(start=0,end=0),wage(start=1,end=2,amount=12,burden=3,version=B)]
    def adjacent(i,r,a):
        ready(r); equal(r["financial_status"],"Ready","adjacent rates financial readiness")
        equal(financial_number(r,"allocated_touch_labor"),F(25,2)+15,"dated touch rates")
    add("AC22_adjacent_rates", "AC22", y, {"touch_USD":F(25,2)+15}, adjacent)
    x=config(machine_hours=10,demand_quantity=9); shift(x)["ot_paid_hours"]="2"
    def overtime(i,r,a):
        ready(r); equal(total(r),min(9,8+2),"OT units")
        equal(financial_number(r,"expected_staffed_payroll"),8*F(25,2)+2*F(35,2),"paid OT and additive burden")
        equal(financial_number(r,"allocated_touch_labor"),8*F(25,2)+F(35,2),"touch OT and additive burden")
    add("AC23_additive_burden_contract_variant", "AC23", x, {"paid_USD":8*F(25,2)+2*F(35,2),"touch_USD":8*F(25,2)+F(35,2)}, overtime,"fixed_burden_per_hour_only_percentage_OT_burden_deferred")
    x=two_sites(2,2,demand_quantity=2); f=x["facilities"][1]
    f["labor"][0]["currency"]="EUR"; f["labor"][0]["rates"]=[wage("EUR")]
    f["space"][0]["currency"]="EUR"; f["space"][0]["psf_rates"]=[value("EUR",0,unit="currency_per_sqft_day")]
    f["families"][0]["value_currency"]="EUR"; f["families"][0]["shipment_values"]=[value("EUR",80)]
    def currencies(i,r,a):
        ready(r)
        equal(financial_number(r,"projected_shipment_value","USD","by_currency",0),F(2*100),"USD partition")
        equal(financial_number(r,"projected_shipment_value","EUR","by_currency",1),F(2*80),"EUR partition")
        require("grand_total" not in r and "total_value" not in r,"Undeclared cross-currency total")
    add("AC24_currency_partitions", "AC24", x, {"USD":2*100,"EUR":2*80}, currencies,"currency_partitions_only_FX_deferred")
    x=config(labor_hours=10,machine_hours=10); x["facilities"][0]["routes"][0]=route(labor="1.25")
    add("AC25_bundled_rework", "AC25", x, {"units":math.floor(F(10)/F(5,4))}, simple_count(math.floor(F(10)/F(5,4))))
    y=copy.deepcopy(x); y["facilities"][0]["routes"][0]["loads"][0]["rework_hours_per_unit"]="0.25"
    add("AC25_double_rework_guard", "AC25", y, {"status":"Blocked"}, expect_block("DOUBLE_REWORK"))
    x=config(); x["facilities"][0]["families"][0]["quality"]={"status":"required","snapshot_date":day(),"released_units":0,"releases":[],"evidence":A}
    add("AC25_quality_hold", "AC25", x, {"units":0}, simple_count(0), "authorization_gate_only_active_WIP_deferred")
    x=config(demand_quantity=2); x["facilities"][0]["demands"].append(copy.deepcopy(x["facilities"][0]["demands"][0]))
    def duplicate_warn(i,r,a):
        ready(r); equal(total(r),2,"identical duplicate counted once")
        require(any(d["code"]=="DUPLICATE_DEMAND_COLLAPSED" for d in r["diagnostics"]),"Silent duplicate deletion")
    add("AC26_identical_duplicate_contract_policy", "AC26", x, {"units":2,"explicit_warning":True}, duplicate_warn,"diagnosed_dedup_policy_not_strict_rejection_oracle")
    y=copy.deepcopy(x); y["facilities"][0]["demands"][-1]["quantity"]=3
    add("AC26_conflicting_duplicate", "AC26", y, {"status":"Blocked"}, expect_block("CONFLICTING_DEMAND_DUPLICATE"))
    x=config(); x["facilities"][0]["demands"][0]["family"]=B
    add("AC26_unknown_family", "AC26", x, {"status":"Blocked"}, expect_block("UNKNOWN_FAMILY"))
    x=config(labor_hours=7); x["facilities"][0]["routes"][0]=route(labor="2.5")
    add("AC27_whole_units", "AC27", x, {"units":math.floor(F(7)/F(5,2))}, simple_count(math.floor(F(7)/F(5,2))))
    for label,bad in (("nan","NaN"),("infinity","Infinity"),("negative_infinity","-Infinity"),("negative",-1),("boolean",True)):
        x=config(); shift(x)["regular_paid_hours"]=bad
        add("AC27_invalid_"+label, "AC27", x, {"status":"Blocked"}, expect_block("NUMBER"))
    x=config(demand_quantity=2.5)
    add("AC27_fractional_demand", "AC27", x, {"status":"Blocked"}, expect_block())
    x=config(); x["facilities"][0]["labor"][0]["rates"][0]["base_wage"]="NaN"
    add("AC27_nonfinite_wage", "AC27", x, {"physical":"Ready","financial":"Blocked"}, expect_block(financial=True))
    x=config(labor_hours=3,machine_hours=3); x["facilities"][0]["demands"]=[demand(A,quantity=2,due=1),demand(B,quantity=2,due=1)]
    def deterministic(i,r,a):
        ready(r); got={z["business_key"]:z["allocated_quantity"] for z in r["facilities"][0]["demand_outcomes"]}
        equal(got,{A:min(2,3),B:min(2,3-min(2,3))},"declared tiebreak")
        alt=copy.deepcopy(i); alt["facilities"][0]["demands"].reverse()
        for kind in ("labor","machines","space"):
            for pool in alt["facilities"][0][kind]: pool["calendar"].reverse()
        other=a["plan"](alt); conservation(alt,other)
        equal(allocation_signature(other),allocation_signature(r),"permuted business allocations")
        equal(normalize(other["facilities"][0]["financials"]),normalize(r["facilities"][0]["financials"]),"permuted costs")
    add("AC28_deterministic_order", "AC28", x, {A:2,B:1}, deterministic)
    def scenario_isolation(i,r,a):
        original=checksum(i); changed=a["apply_scenario"](i,scenario())
        equal(total(a["plan"](changed)),5,"scenario units"); equal(checksum(i),original,"scenario did not mutate baseline")
        equal(total(a["plan"](i)),8,"repeat baseline units")
    add("AC29_scenario_baseline", "AC29", config(), {"sequence":[8,5,8]}, scenario_isolation)
    def monotone(i,r,a):
        vals=[]
        for hours in (0,2,4,6,8):
            x=copy.deepcopy(i); shift(x)["regular_paid_hours"]=str(hours); out=a["plan"](x); conservation(x,out); vals.append(total(out))
        expected=[min(10,h//2,8) for h in (0,2,4,6,8)]
        equal(vals,expected,"single-product maximum vector")
    x=config(demand_quantity=10); x["facilities"][0]["routes"][0]=route(labor=2)
    add("AC30_monotonicity", "AC30", x, {"vector":[min(10,h//2,8) for h in (0,2,4,6,8)]}, monotone)
    x=two_sites(8,8,demand_quantity=3); x["facilities"][0]["stocks"][0]["on_hand"]="0"; x["facilities"][1]["stocks"][0]["on_hand"]="5"; x["facilities"][1]["demands"]=[]
    add("AC31_no_transfer", "AC31", x, {"units":min(3,0)}, simple_count(min(3,0)))
    x=config(demand_quantity=3,on_hand=12); x["facilities"][0]["routes"][0]=route(labor=2,machine=2,material=4)
    add("AC32_preconverted_shipment_unit", "AC32", x, {"units":min(3,8//2,12//4)}, simple_count(min(3,8//2,12//4)),"coefficients_already_per_business_EA_conversion_registry_deferred")
    x=config(); x["facilities"][0]["labor"][0]["rates"]=[]; x["facilities"][0]["families"][0]["shipment_values"]=[]
    def finance_missing(i,r,a):
        ready(r); equal(total(r),min(12,8),"physical result survives missing finance"); blocked(r,financial=True)
        equal(r["facilities"][0]["financials"]["allocated_touch_labor"]["loaded_by_currency"],None,"missing wage is unknown")
        equal(r["facilities"][0]["financials"]["projected_shipment_value"]["by_currency"],None,"missing value is unknown")
    add("AC33_financial_readiness", "AC33", x, {"units":8,"financial":"Blocked"}, finance_missing)
    x=config(production_days=2,labor_hours=1,machine_hours=1,demand_quantity=2,on_hand=3)
    x["facilities"][0]["routes"]=[route(material=2,start=0,end=0,version=A),route(material=1,start=1,end=2,version=B)]
    add("AC34_dated_BOM", "AC34", x, {"units":1+1,"stock_end":3-1*2-1*1}, simple_count(1+1))
    x=config(); x["facilities"][0]["horizon"]={"start":date.min.isoformat(),"end":date.max.isoformat(),"occupancy_end":date.max.isoformat()}
    add("AC36_extreme_span", "AC36", x, {"status":"Blocked","timeout_seconds":5}, None,"isolated_cli_and_api_guard")
    def alias_plan(i,r,a):
        original=checksum(i)
        r["provenance"]["freshness_policy"]["max_age_days"]=0
        equal(checksum(i),original,"mutating returned plan provenance must not mutate input")
    add("AC37_plan_provenance_alias", "AC37", config(), {"input_hash_unchanged":True}, alias_plan)
    def alias_validation(i,r,a):
        v=a["validate_config"](i); original=checksum(i); first=normalize(v.as_dict())
        exposed=v.as_dict(); exposed["provenance"]["freshness_policy"]["max_age_days"]=0
        equal(checksum(i),original,"validation export must not mutate approved input")
        equal(normalize(v.as_dict()),first,"validation export must not mutate frozen result")
        try:
            v.provenance["freshness_policy"]["max_age_days"]=0
        except (TypeError,AttributeError):
            pass
        equal(checksum(i),original,"direct nested validation provenance mutation must not mutate input")
    add("AC37_validation_provenance_alias", "AC37", config(), {"input_and_validation_unchanged":True}, alias_validation)
    def alias_scenario(i,r,a):
        s=scenario(); hi,hs=checksum(i),checksum(s); changed=a["apply_scenario"](i,s)
        shift(changed)["regular_paid_hours"]="0"; changed["scenario"]["changes"][0]["value"]="0"
        changed["evidence"][0]["source"]=B
        equal(checksum(i),hi,"returned scenario must not mutate baseline"); equal(checksum(s),hs,"returned scenario must not mutate scenario argument")
        original_result=checksum(changed); s["changes"][0]["value"]="1"
        equal(checksum(changed),original_result,"scenario argument must not alias returned scenario")
    add("AC37_scenario_alias", "AC37", config(), {"input_and_scenario_argument_unchanged":True}, alias_scenario)
    readiness_expected={"overall":"Blocked","facility_statuses":{A:"Blocked",B:"Ready"},
                        "known_allocated_units":{A:min(2,4),B:min(3,3)},
                        "unknown_input_and_unserved_quantity":None,"validate_and_plan_CLI_exit":2}
    for suffix,check in (("validate_api",check_incomplete_validate_api),
                         ("validate_cli",check_incomplete_cli("validate")),
                         ("plan_api",check_incomplete_plan_api),
                         ("plan_cli",check_incomplete_cli("plan"))):
        add(INCOMPLETE_REGRESSION_PREFIX+suffix,"AC26",incomplete_release_fixture(),
            copy.deepcopy(readiness_expected),check,"new_independent_mixed_readiness_regression")
    return items


DEFERRED = [
    {"domain":"AC01","capability":"Same-day/zero lead is not supported; scalar tests use the same productive buckets plus one explicit zero-capacity completion day."},
    {"domain":"AC03","capability":"Cross-site shared budgets are explicitly rejected; guard coverage is not allocation support."},
    {"domain":"AC08","capability":"Fixed nonlabor batch charge is not in the contract; physical fixed setup is tested without changing its oracle."},
    {"domain":"AC13","capability":"Working-day lead calendars are absent; only calendar-day lead is currently representable."},
    {"domain":"AC14","capability":"History/backlog opening snapshots and automatic cross-run continuation need an external reconciled outstanding-demand input."},
    {"domain":"AC16/AC32","capability":"Existing-model business shipment-designation conversion/approval registry is not an engine field; supplied coefficients must already be per authoritative EA."},
    {"domain":"AC19/AC20/AC21/AC25","capability":"Active modeled opening WIP is explicitly unsupported; external reservations and newly planned occupancy tail are tested separately."},
    {"domain":"AC23","capability":"Contract burden is absolute currency per paid hour, not a fraction of gross OT wage. Additive contract-variant oracle is separately computed; original proportional-burden case is not declared passed."},
    {"domain":"AC24","capability":"Currency partitions exist; dated FX conversion is explicitly absent."},
    {"domain":"AC26","capability":"Identical duplicate demand is diagnosed and collapsed by documented semantic policy, not strictly blocked as the independent spec requests. Conflicting duplicates must block. This is a policy difference, not silent deletion or double allocation."},
    {"domain":"AC35","capability":"Integrated global-pool witness cannot be executed faithfully until cross-site pooling is supported; it remains independently arithmetic-verified, not engine-passed."},
]


def run_extreme(inp_path):
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(ENGINE))
    records=[]
    for interface, commands in (("CLI", ("validate", "plan")), ("API", ("validate_config", "plan"))):
        for command in commands:
            if interface == "CLI":
                argv=[sys.executable,"-B","-m","capacity_engine",command,str(inp_path)]
                expected_exit=2
            else:
                code=("import json,sys; from capacity_engine import "+command+
                      "; x=json.load(open(sys.argv[1])); r="+command+
                      "(x); r=r.as_dict() if hasattr(r,'as_dict') else r; print(json.dumps(r,default=str))")
                argv=[sys.executable,"-B","-c",code,str(inp_path)]
                expected_exit=0
            started=time.monotonic()
            completed=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,text=True,timeout=GUARD_TIMEOUT_SECONDS)
            elapsed=time.monotonic()-started
            equal(completed.returncode,expected_exit,"invalid horizon "+interface+" process exit")
            require(elapsed <= GUARD_TIMEOUT_SECONDS,"Invalid horizon failed bounded-runtime guard")
            parsed=json.loads(completed.stdout)
            matches=assert_guarded_block(parsed,"AC36_extreme_span",plan_output=command=="plan")
            records.append({"interface":interface,"command":command,"elapsed_seconds":elapsed,
                            "timeout_seconds":GUARD_TIMEOUT_SECONDS,"returncode":completed.returncode,
                            "status":parsed["status"],"matched_diagnostics":matches,
                            "null_or_absent_plan_outputs_verified":True,
                            "facility_statuses":{f["id"]:f["status"] for f in parsed["facilities"]}})
    return records


def main():
    global ENGINE
    parser=argparse.ArgumentParser()
    parser.add_argument("--only")
    parser.add_argument("--engine-root",help="Engine source root; otherwise CAPACITY_ENGINE_ROOT or sibling capacity_engine_v2")
    parser.add_argument("--final",action="store_true",help="Verify the frozen candidate once; a changed source hash invalidates the final verdict")
    args=parser.parse_args()
    if args.engine_root:
        ENGINE=Path(args.engine_root).expanduser().resolve()
    if args.final and args.only:
        raise SystemExit("Final verification requires the full independent suite")
    selected=[item for item in cases() if args.only is None or item["id"]==args.only]
    if not selected: raise SystemExit("Unknown test id")
    inputs_dir=ROOT/"inputs"; inputs_dir.mkdir(exist_ok=True)
    before=source_snapshot()
    build_report_path=ENGINE/"BUILD_REPORT.json"
    build_report_bytes=build_report_path.read_bytes() if build_report_path.exists() else None
    build_report=json.loads(build_report_bytes) if build_report_bytes is not None else {}
    engine_relative=os.path.relpath(ENGINE,ROOT)
    sys.path.insert(0,str(ENGINE))
    from capacity_engine import validate_config, plan, apply_scenario
    api={"validate_config":validate_config,"plan":plan,"apply_scenario":apply_scenario}
    results=[]
    for item in selected:
        api["observations"]={}
        inp=copy.deepcopy(item["config"]); inp_path=inputs_dir/(item["id"]+".json")
        inp_path.write_text(json.dumps(inp,indent=2,allow_nan=False)+"\n")
        start_hash=source_snapshot()["sha256"]
        record={"id":item["id"],"domain":item["domain"],"coverage":item["coverage"],
                "expected":item["expected"],"input_file":str(inp_path.relative_to(ROOT)),
                "reproduce":"PYTHONDONTWRITEBYTECODE=1 python -B run_acceptance.py --engine-root "+shlex.quote(engine_relative)+" --only "+item["id"],"source_before":start_hash}
        started=time.monotonic(); result=None
        try:
            if item["id"]=="AC36_extreme_span":
                record["observed"]=run_extreme(inp_path)
            else:
                original=checksum(inp); result=api["plan"](inp)
                equal(checksum(inp),original,"plan call mutated input")
                if result["status"] in ("Ready","No demand"):
                    conservation(inp,result)
                item["check"](inp,result,api)
                if item["id"] in STRICT_BLOCKED_POLICIES:
                    require(time.monotonic()-started<=GUARD_TIMEOUT_SECONDS,"Blocked response exceeded harness runtime guard")
                    record["strict_adapter_checks"]={"status_paths_messages_and_null_outputs":True,"runtime_limit_seconds":GUARD_TIMEOUT_SECONDS}
                record["observed"]={"status":result["status"],"financial_status":result["financial_status"],
                                    "totals":totals(result),"diagnostics":result["diagnostics"]}
            record["status"]="DEFERRED_CAPABILITY" if item["coverage"]=="deferred_capability" else "PASS"
        except Exception as error:
            record["status"]="FAIL"
            record["error"]=str(error); record["exception_type"]=type(error).__name__
            record["traceback"]=traceback.format_exc()
            if result is not None:
                record["observed"]={"status":result["status"],"financial_status":result["financial_status"],"totals":totals(result),"diagnostics":result["diagnostics"]}
                failure_path=ROOT/("failure_"+item["id"]+"_"+start_hash[:12]+".json")
                failure_path.write_text(json.dumps(normalize(result),indent=2)+"\n")
                record["full_output_file"]=failure_path.name
        record["elapsed_seconds"]=time.monotonic()-started
        if api["observations"]:
            record["additional_observations"]=api["observations"]
        record["source_after"]=source_snapshot()["sha256"]
        record["source_changed_during_case"]=record["source_before"]!=record["source_after"]
        record["provisional"]=not args.final or record["source_changed_during_case"]
        results.append(record)
        print(record["status"],item["id"],record.get("error",""))
    after=source_snapshot()
    counts={status:sum(r["status"]==status for r in results) for status in ("PASS","FAIL","DEFERRED_CAPABILITY")}
    unchanged=before["sha256"]==after["sha256"] and not any(r["source_changed_during_case"] for r in results)
    build_report_unchanged=build_report_bytes==(build_report_path.read_bytes() if build_report_path.exists() else None)
    frozen_verified=args.final and unchanged and build_report_unchanged and "FROZEN" in build_report.get("build_status","")
    specification=json.loads((ROOT/"acceptance_cases.json").read_text())
    specified_ids={c["id"] for c in specification["cases"]}
    mapped_ids={r["domain"] for r in results}
    report={"status":"FINAL_FROZEN_CANDIDATE_CHECKS_COMPLETED" if frozen_verified else "PROVISIONAL_NOT_FROZEN_ACCEPTANCE",
            "final_verification_requested":args.final,"frozen_source_verified":frozen_verified,
            "engine_written":False,"network_used":False,"engine_root_relative_to_harness":engine_relative,
            "source_before":before,"source_after":after,"source_changed_during_run":not unchanged,
            "build_report_reference":{"path":os.path.relpath(build_report_path,ROOT),
                "sha256":None if build_report_bytes is None else hashlib.sha256(build_report_bytes).hexdigest(),
                "unchanged_during_run":build_report_unchanged,"build_status":build_report.get("build_status"),
                "builder_reported_self_tests_not_used_as_oracles":build_report.get("tests",{}).get("tests_run")},
            "counts":counts,"separate_mapped_check_counts":{"supported_pass":counts["PASS"],"true_fail":counts["FAIL"],"deferred_not_passed":counts["DEFERRED_CAPABILITY"]},
            "coverage_count_units":{"specified_domain_cases":len(specified_ids),"domain_cases_with_mapped_checks":len(mapped_ids),
                "domain_cases_without_engine_execution":sorted(specified_ids-mapped_ids),"unpassed_capability_gap_entries":len(DEFERRED),
                "note":"Mapped checks and capability-gap entries overlap and are different count units. Passing a limited contract variant does not pass its unsupported domain capability."},
            "mapped_tests":len(results),"results":results,"deferred_or_policy_gaps":DEFERRED,
            "mapping_notes":["Inputs are independent TEST_ALPHA/TEST_BETA arithmetic fixtures, not engine examples or implementation tests.",
                             "Technical kind prefixes disambiguate a flat resource namespace; site/order tuples become global business keys.",
                             "Contract dates/effectivity are inclusive; domain end-exclusive bounds are converted to previous-day inclusive ends.",
                             "Scalar tests preserve productive capacity and add a declared zero-capacity completion day because engine lead_days >= 1.",
                             "Every physically ready plan is checked against independently reconstructed dated resource, BOM/inventory, quality and backlog conservation.",
                             "Financially unsupported domain policies retain their original oracle and are reported as gaps, not silently normalized."]}
    historical_alias_path=ROOT/"initial_alias_probe.json"
    if historical_alias_path.exists():
        historical=json.loads(historical_alias_path.read_text())
        alias_checks=[r for r in results if r["domain"]=="AC37"]
        report["historical_provenance_alias_defect"]={
            "evidence":historical_alias_path.name,"observed_on_source":historical.get("source_before"),
            "original_observations":historical.get("checks"),
            "current_checks":{r["id"]:r["status"] for r in alias_checks},
            "current_classification":"NOT_REPRODUCED_ON_CURRENT_SOURCE" if alias_checks and all(r["status"]=="PASS" for r in alias_checks) else "SEE_CURRENT_CHECK_RESULTS"}
    report["diagnostic_adapter_correction"]={
        "preserved_original_failed_run":"first_run_diagnostic_mapping_report.json",
        "classification":"DIAGNOSTIC_NAME_ADAPTER_MISMATCHES_NOT_ENGINE_ARITHMETIC_DEFECTS",
        "guard_self_test_evidence":"adapter_guard_checks.json",
        "contract":"Equivalent code requires Blocked status, correct offending path and meaningful message, null/no manufactured physical outputs, and a bounded runtime; numeric/conservation oracles are unchanged."}
    readiness_checks=[r for r in results if r["id"].startswith(INCOMPLETE_REGRESSION_PREFIX)]
    report["mixed_incomplete_readiness_regression"]={"separate_from_adapter_corrections":True,
        "checks":{r["id"]:r["status"] for r in readiness_checks},
        "contract":"Validation API/CLI and plan must agree on overall/affected-site Blocked; unknown input/outstanding quantity stays null, known releases may retain explicitly partial allocations, and an independent facility remains Ready."}
    name="final_report.json" if args.final else "run_report.json" if args.only is None else "probe_"+args.only+".json"
    report_text=json.dumps(normalize(report),indent=2)+"\n"
    (ROOT/name).write_text(report_text)
    if args.only is None:
        if args.final:
            (ROOT/"run_report.json").write_text(report_text)
        (ROOT/"failures.json").write_text(json.dumps(normalize([r for r in results if r["status"]=="FAIL"]),indent=2)+"\n")
    print(json.dumps({"report":name,"counts":report["separate_mapped_check_counts"],"source_before":before["sha256"],"source_after":after["sha256"],"frozen_source_verified":frozen_verified},indent=2))
    return int(bool(counts["FAIL"]) or (args.final and not frozen_verified))


if __name__=="__main__":
    raise SystemExit(main())
