"""Deterministic synthetic conservation/property checks, no third-party test libraries."""
import copy
from datetime import date
from decimal import Decimal, ROUND_FLOOR
import random
import unittest

from capacity_engine import apply_scenario, plan, validate_config
from support import EVIDENCE, add_family, config, integrated_config, scenario


D = Decimal


class ConservationTests(unittest.TestCase):
    def test_seeded_mixed_resource_conservation_80_cases(self):
        rng = random.Random(20261021)
        for case in range(80):
            c = config(end="2026-01-09", tail="2026-01-12")
            add_family(c, quantity=rng.randrange(11))
            f = c["facilities"][0]
            f["demands"][0]["quantity"] = rng.randrange(11)
            for release in f["demands"]:
                release.update(priority=rng.randrange(3), release_date=f"2026-01-{rng.randrange(4,11):02d}",
                               customer_requested_date=f"2026-01-{rng.randrange(4,11):02d}")
            for day in f["labor"][0]["calendar"]:
                day["shifts"][0].update(qualified_headcount=rng.randrange(9), regular_paid_hours=str(rng.randrange(9)),
                    ot_paid_hours=str(rng.randrange(4)), attendance=rng.choice(["0", "0.5", "1"]),
                    productive_fraction=rng.choice(["0.5", "0.75", "1"]))
            for day in f["machines"][0]["calendar"]:
                count, scheduled = rng.randrange(3), rng.randrange(9)
                day.update(count=count, scheduled_hours=str(scheduled), maintenance_hours=str(count*scheduled//2),
                    uptime=rng.choice(["0", "0.5", "1"]), performance=rng.choice(["0.5", "1"]))
            for day in f["space"][0]["calendar"]:
                day.update(usable_sqft=str(25*rng.randrange(9)), max_slots=rng.randrange(6))
            s = f["stocks"][0]
            s.update(on_hand=str(rng.randrange(16)), receipts=[{"id": "test-receipt", "date": "2026-01-07",
                "quantity": str(rng.randrange(10)), "evidence": EVIDENCE}])
            for family, route in zip(f["families"], f["routes"]):
                family["quality"].update(released_units=rng.randrange(8), releases=[{"id": "test-q", "date": "2026-01-07",
                    "quantity": rng.randrange(5), "evidence": EVIDENCE}])
                route.update(lead_days=rng.randrange(1,3), batch_size=rng.randrange(1,5))
                route["space"][0]["dwell_days"] = rng.randrange(1,5)
                for load in route["loads"]:
                    load.update(first_pass_hours_per_unit=str(rng.randrange(1,5)), rework_hours_per_unit=rng.choice(["0", "0.5"]),
                        setup_hours_per_batch=str(rng.randrange(3)), offset_days=rng.randrange(route["lead_days"]))
                route["materials"]["bom"][0]["quantity_per_unit"] = str(rng.randrange(1,4))
            with self.subTest(case=case):
                result = plan(c)
                self.assertIn(result["status"], {"Ready", "No demand"}, result["diagnostics"])
                out = result["facilities"][0]
                for row in out["resource_loads"]:
                    self.assertGreaterEqual(row["load"], 0)
                    self.assertLessEqual(row["load"], row["capacity"])
                    self.assertEqual(row["slack"], row["capacity"] - row["load"])
                prior = D(s["on_hand"])
                for row in out["inventory"]:
                    self.assertEqual(row["opening_on_hand"], prior)
                    self.assertEqual(row["ending_on_hand"], prior + row["receipts"] - row["consumed"])
                    self.assertGreaterEqual(row["available"], 0)
                    prior = row["ending_on_hand"]
                expected_consumption = sum((D(a["quantity"]) * D(next(r for r in f["routes"] if r["family"] == a["family"])["materials"]["bom"][0]["quantity_per_unit"])
                                           for a in out["allocations"]), D(0))
                self.assertEqual(sum(row["consumed"] for row in out["inventory"]), expected_consumption)
                for row in out["backlog"]:
                    self.assertEqual(row["open_quantity"], row["in_plan_wip_quantity"] + row["unstarted_quantity"])
                    self.assertEqual(row["released_quantity"], row["completed_quantity"] + row["open_quantity"])
                for outcome in out["demand_outcomes"]:
                    self.assertEqual(outcome["input_quantity"], outcome["allocated_quantity"] + outcome["unserved_quantity"])
                for allocation in out["allocations"]:
                    self.assertIsInstance(allocation["quantity"], int)
                    self.assertGreater(allocation["quantity"], 0)
                    self.assertGreaterEqual(allocation["start_date"], allocation["release_date"])
                    self.assertLessEqual(allocation["modeled_ship_date"], date(2026, 1, 9))
                for quality in out["quality"]:
                    self.assertGreaterEqual(quality["remaining"], 0)

    def test_single_start_bruteforce_oracle_60_cases(self):
        rng = random.Random(7901)
        for case in range(60):
            c = config(end="2026-01-06")
            f = c["facilities"][0]
            q = rng.randrange(1, 21)
            f["demands"][0]["quantity"] = q
            headcount = rng.randrange(9)
            reg = rng.randrange(9)
            attendance = D(rng.choice(["0.5", "1"]))
            productive = D(rng.choice(["0.5", "1"]))
            for day in f["labor"][0]["calendar"]:
                day["shifts"][0].update(qualified_headcount=headcount, regular_paid_hours=str(reg),
                                      attendance=str(attendance), productive_fraction=str(productive))
            machine = rng.randrange(9)
            for day in f["machines"][0]["calendar"]:
                day["scheduled_hours"] = str(machine)
            slots = rng.randrange(5)
            for day in f["space"][0]["calendar"]:
                day["max_slots"] = slots
            stock = rng.randrange(16)
            quality = rng.randrange(10)
            f["stocks"][0]["on_hand"] = str(stock)
            f["families"][0]["quality"]["released_units"] = quality
            batch = rng.randrange(1,5)
            setup = rng.randrange(3)
            f["routes"][0]["batch_size"] = batch
            f["routes"][0]["loads"][1]["setup_hours_per_batch"] = str(setup)
            crews = min(int((D(headcount)*attendance/2).to_integral_value(rounding=ROUND_FLOOR)), 2)
            labor = crews*2*reg*productive
            feasible = [n for n in range(q+1) if 2*n <= labor and 2*n+((n+batch-1)//batch)*setup <= machine
                        and 25*n <= 100 and n <= slots and 2*n <= stock and n <= quality]
            with self.subTest(case=case):
                r = plan(c)
                self.assertEqual(r["status"], "Ready")
                self.assertEqual(r["facilities"][0]["summary"]["allocated_units"], max(feasible))

    def test_multisite_no_capacity_or_inventory_transfer_invariance(self):
        c = integrated_config()
        baseline = plan(c)["facilities"][1]
        c["facilities"][0]["stocks"][0].update(on_hand="0", allocated="0", safety_stock="0", receipts=[])
        changed = plan(c)
        self.assertEqual(changed["facilities"][0]["summary"]["allocated_units"], 0)
        self.assertEqual(changed["facilities"][1], baseline)

    def test_plan_repeatedly_does_not_accumulate_inventory_debits(self):
        c = integrated_config()
        outputs = [plan(c) for _ in range(5)]
        self.assertTrue(all(output == outputs[0] for output in outputs))

    def test_result_metadata_mutations_never_change_input_or_validation(self):
        c = apply_scenario(config(), scenario("/facilities/0/stocks/0/on_hand", "12"))
        original = copy.deepcopy(c)
        validated = validate_config(c)
        expected_validation = validated.as_dict()
        exported = validated.as_dict()
        exported["provenance"]["freshness_policy"]["max_age_days"] = 0
        exported["provenance"]["evidence"][0]["source"] = "changed externally"
        exported["provenance"]["evidence"].append({"external": [1, 2]})
        exported["provenance"]["scenario"]["changes"][0]["value"] = "999"
        exported["provenance"]["scenario"]["changes"].clear()
        exported["facilities"].clear()
        self.assertEqual(c, original)
        self.assertEqual(validated.as_dict(), expected_validation)
        expected_plan = plan(validated)
        output = plan(validated)
        output["provenance"]["freshness_policy"]["max_age_days"] = 0
        output["provenance"]["scenario"]["changes"][0]["path"] = "modified"
        output["provenance"]["evidence"][0]["approved"] = False
        output["facilities"][0]["allocations"].clear()
        self.assertEqual(c, original)
        self.assertEqual(validated.as_dict(), expected_validation)
        self.assertEqual(plan(validated), expected_plan)

    def test_validated_provenance_is_recursively_read_only(self):
        v = validate_config(config())
        with self.assertRaises(TypeError):
            v.provenance["freshness_policy"]["max_age_days"] = 0
        with self.assertRaises(TypeError):
            v.provenance["evidence"][0]["source"] = "changed"
        with self.assertRaises(AttributeError):
            v.provenance["evidence"].append({})

    def test_input_mutation_after_validation_cannot_change_snapshot(self):
        c = apply_scenario(config(), scenario("/facilities/0/stocks/0/on_hand", "12"))
        v = validate_config(c)
        before = v.as_dict()
        c["freshness_policy"]["max_age_days"] = 0
        c["evidence"][0]["source"] = "changed"
        c["scenario"]["changes"].append({"path": "injected", "value": 0})
        c["facilities"][0]["stocks"][0]["on_hand"] = "0"
        self.assertEqual(v.as_dict(), before)
        self.assertEqual(plan(v)["facilities"][0]["summary"]["allocated_units"], 4)


if __name__ == "__main__":
    unittest.main()
