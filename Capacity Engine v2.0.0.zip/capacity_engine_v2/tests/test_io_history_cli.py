import contextlib
import copy
import csv
import io
import json
from pathlib import Path
import shutil
import unittest
import uuid
from decimal import Decimal

from capacity_engine import audit_history, plan
from capacity_engine.cli import main
from capacity_engine.io import (DEMAND_COLUMNS, InputFileError, export_plan_csv, load_demand_csv, load_json,
                                replace_demands_from_csv, safe_csv_cell, write_json)
from support import EVIDENCE, config, demand

ROOT = Path(__file__).resolve().parents[1]


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.work = ROOT / "verification" / ("unittest-" + uuid.uuid4().hex)
        self.work.mkdir(parents=True)

    def tearDown(self):
        shutil.rmtree(self.work)

    def csv(self, rows, headers=DEMAND_COLUMNS):
        path = self.work / "releases.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)
        return path

    def test_json_duplicate_object_keys_rejected(self):
        path = self.work / "bad.json"
        path.write_text('{"a":1,"a":2}')
        with self.assertRaises(InputFileError):
            load_json(path)

    def test_nonfinite_json_or_nonobject_root_rejected(self):
        for text in ('{"a":NaN}', '{"a":Infinity}', '[1,2]'):
            path = self.work / "bad.json"
            path.write_text(text)
            with self.assertRaises(InputFileError):
                load_json(path)

    def test_json_decimal_roundtrip_uses_decimal_strings(self):
        path = self.work / "decimal.json"
        write_json(path, {"value": Decimal("0.10")})
        self.assertEqual(load_json(path), {"value": "0.10"})
        path.write_text('{"value":0.1}')
        self.assertEqual(load_json(path)["value"], Decimal("0.1"))

    def test_demand_csv_import_and_plan(self):
        c = config()
        row = {"facility_id": c["facilities"][0]["id"], **demand(qty=2)}
        path = self.csv([row])
        imported = replace_demands_from_csv(c, path)
        self.assertEqual(imported["facilities"][0]["demands"][0]["quantity"], 2)
        self.assertEqual(plan(imported)["facilities"][0]["summary"]["allocated_units"], 2)
        self.assertEqual(c["facilities"][0]["demands"][0]["quantity"], 4)

    def test_csv_missing_qty_stays_queued_not_zero(self):
        c = config()
        row = {"facility_id": c["facilities"][0]["id"], **demand(qty=None)}
        imported = replace_demands_from_csv(c, self.csv([row]))
        self.assertIsNone(imported["facilities"][0]["demands"][0]["quantity"])
        self.assertEqual(plan(imported)["status"], "Blocked")

    def test_bad_csv_rows_not_silently_dropped(self):
        row = {"facility_id": "SYNTHETIC_A", **demand()}
        for bad in ("1.5", "-1", "TRUE", "NaN", "1e2"):
            with self.subTest(bad=bad), self.assertRaises(InputFileError):
                load_demand_csv(self.csv([{**row, "quantity": bad}]))
        bad_path = self.work / "bad.csv"
        bad_path.write_text(",".join(DEMAND_COLUMNS) + "\nshort,row\n")
        with self.assertRaises(InputFileError):
            load_demand_csv(bad_path)

    def test_duplicate_or_unknown_csv_headers_and_site(self):
        path = self.work / "bad.csv"
        path.write_text("quantity,quantity\n1,2\n")
        with self.assertRaises(InputFileError):
            load_demand_csv(path)
        path.write_text("unknown\n1\n")
        with self.assertRaises(InputFileError):
            load_demand_csv(path)
        path = self.csv([{"facility_id": "UNKNOWN", **demand()}])
        with self.assertRaises(InputFileError):
            replace_demands_from_csv(config(), path)

    def test_empty_csv_explicitly_replaces_all_demand(self):
        c = replace_demands_from_csv(config(), self.csv([]))
        self.assertEqual(plan(c)["status"], "No demand")

    def test_formula_like_csv_text_neutralized(self):
        for text in ("=1+1", "+SUM(A1:A2)", "-DANGEROUS()", "@formula", "\t=1", "\rtext", "\ntext", " \x01bad", "   +bad", "\ufeff=1", "\u0085=1"): 
            with self.subTest(text=text):
                self.assertEqual(safe_csv_cell(text), "'" + text)
        self.assertEqual(safe_csv_cell("ordinary text"), "ordinary text")
        self.assertEqual(safe_csv_cell(Decimal("-2.50")), "-2.50")
        self.assertEqual(safe_csv_cell(-5), -5)
        self.assertEqual(safe_csv_cell(Decimal("0.10")), "0.10")

    def test_exported_formula_business_key_is_text_not_formula(self):
        c = config()
        c["facilities"][0]["demands"][0]["business_key"] = "=SUM(1,2)"
        r = plan(c)
        export_plan_csv(r, self.work / "csv")
        with (self.work / "csv" / "allocations.csv").open(newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(rows[0]["business_key"], "'=SUM(1,2)")
        self.assertEqual(rows[0]["quantity"], "4")
        self.assertEqual(r["facilities"][0]["allocations"][0]["business_key"], "=SUM(1,2)")
        self.assertEqual(len(list((self.work / "csv").glob("*.csv"))), 5)

    def test_all_cli_commands_run_offline(self):
        for command, extra in (
            ("validate", [str(ROOT / "examples/synthetic/two_site.json")]),
            ("plan", [str(ROOT / "examples/synthetic/two_site.json"), "--csv-dir", str(self.work / "csv")]),
            ("scenario", [str(ROOT / "examples/synthetic/two_site.json"), str(ROOT / "examples/synthetic/rework_scenario.json"), "--config-output", str(self.work / "scenario_config.json")]),
            ("history-audit", [str(ROOT / "examples/chase/history.json")]),
        ):
            with self.subTest(command=command):
                output = self.work / (command + ".json")
                self.assertEqual(main([command, *extra, "--output", str(output)]), 0)
                self.assertEqual(load_json(output)["status"], "Ready")

    def test_cli_chase_blocked_exit_two_and_no_forecast(self):
        out = self.work / "chase.json"
        self.assertEqual(main(["plan", str(ROOT / "examples/chase/blocked_config.json"), "--output", str(out)]), 2)
        r = load_json(out)
        self.assertEqual(r["status"], "Blocked")
        self.assertIsNone(r["facilities"][0]["summary"]["allocated_units"])
        self.assertGreaterEqual(len([d for d in r["diagnostics"] if d["code"] == "DECLARED_MISSING_INPUT"]), 10)

    def test_cli_invalid_json_returns_failure_not_success(self):
        bad = self.work / "bad.json"
        bad.write_text('{bad')
        output = io.StringIO()
        with contextlib.redirect_stderr(output):
            status = main(["plan", str(bad)])
        self.assertEqual(status, 2)
        self.assertEqual(json.loads(output.getvalue())["status"], "Blocked")

    def test_cli_missing_file_returns_failure(self):
        output = io.StringIO()
        with contextlib.redirect_stderr(output):
            status = main(["validate", str(self.work / "not-present.json")])
        self.assertEqual(status, 2)
        self.assertIn("Blocked", output.getvalue())

    def test_cli_demand_csv_contract(self):
        path = self.csv([{"facility_id": "SYNTHETIC_A", **demand(qty=2)}])
        cpath = self.work / "config.json"
        write_json(cpath, config())
        result = self.work / "result.json"
        self.assertEqual(main(["plan", str(cpath), "--demand-csv", str(path), "--output", str(result)]), 0)
        self.assertEqual(load_json(result)["facilities"][0]["summary"]["allocated_units"], 2)

    def test_mixed_release_cli_validation_fails_readiness_but_keeps_partial_plan(self):
        c = load_json(ROOT / "examples/synthetic/two_site.json")
        c["facilities"][0]["demands"][0]["quantity"] = None
        cpath = self.work / "mixed-release-config.json"
        write_json(cpath, c)
        validation_path = self.work / "mixed-validation.json"
        self.assertEqual(main(["validate", str(cpath), "--output", str(validation_path)]), 2)
        validated = load_json(validation_path)
        self.assertEqual(validated["status"], "Blocked")
        self.assertEqual([f["status"] for f in validated["facilities"]], ["Blocked", "Ready"])
        plan_path = self.work / "mixed-plan.json"
        self.assertEqual(main(["plan", str(cpath), "--output", str(plan_path)]), 2)
        planned = load_json(plan_path)
        self.assertEqual(planned["status"], "Blocked")
        self.assertEqual(planned["facilities"][0]["status"], "Blocked")
        self.assertTrue(planned["facilities"][0]["partial_plan"])
        self.assertEqual(planned["facilities"][0]["summary"]["allocated_units"], 3)
        self.assertEqual(planned["facilities"][1]["status"], "Ready")
        self.assertEqual(planned["facilities"][1]["summary"]["allocated_units"], 2)


class HistoryTests(unittest.TestCase):
    def history(self):
        return load_json(ROOT / "examples/chase/history.json")

    def test_aggregate_chase_history_reconciles_without_deduping(self):
        r = audit_history(self.history())
        self.assertEqual(r["status"], "Ready")
        self.assertEqual(r["complete_weeks"], 34)
        self.assertEqual(r["reported_model_defined_shipment_records"], 334)
        self.assertEqual(r["candidate_distinct_not_adjudicated"], 332)
        self.assertEqual(r["unresolved_duplicate_excess"], 2)
        self.assertEqual(r["recent_window"]["shipment_records"], 76)
        self.assertEqual(r["totals"]["regular_clock_hours"], Decimal("765781.20"))
        self.assertEqual(r["totals"]["ot_clock_hours"], Decimal("279365.40"))
        self.assertEqual(r["totals"]["paid_hours"], Decimal("1047039.17"))

    def test_factor_eight_regression_is_not_a_routing(self):
        r = audit_history(self.history())
        recent = r["recent_window"]
        self.assertEqual(recent["understatement_factor"], 8)
        self.assertAlmostEqual(recent["correct_aggregate_clock_hours_per_record"],
                               recent["incorrect_average_week_hours_over_window_output"] * 8, places=20)
        self.assertTrue(any("NOT routing" in text for text in r["warnings"]))

    def test_history_missing_duplicate_or_inconsistent_weeks_block(self):
        for kind in ("missing", "duplicate", "count"):
            h = self.history()
            if kind == "missing":
                h["weekly"].pop()
            elif kind == "duplicate":
                h["weekly"].append(h["weekly"][0])
            else:
                h["reported_records"] += 1
            self.assertEqual(audit_history(h)["status"], "Blocked")

    def test_zero_output_denominator_is_unknown_not_zero_hpu(self):
        h = self.history()
        for week in h["weekly"][-8:]:
            week["shipment_records"] = 0
        h["reported_records"] = sum(w["shipment_records"] for w in h["weekly"])
        h["candidate_distinct_records"] = h["reported_records"] - h["unresolved_duplicate_excess"]
        r = audit_history(h)
        self.assertEqual(r["status"], "Ready")
        self.assertIsNone(r["recent_window"]["correct_aggregate_clock_hours_per_record"])

    def test_history_audit_is_pure(self):
        h = self.history()
        before = copy.deepcopy(h)
        audit_history(h)
        self.assertEqual(h, before)

    def test_history_result_provenance_does_not_alias_input(self):
        h = self.history()
        before = copy.deepcopy(h)
        result = audit_history(h)
        result["provenance"]["source_sha256"]["model_data.json"] = "external-mutation"
        self.assertEqual(h, before)
        self.assertNotEqual(audit_history(h)["provenance"], result["provenance"])


if __name__ == "__main__":
    unittest.main()
