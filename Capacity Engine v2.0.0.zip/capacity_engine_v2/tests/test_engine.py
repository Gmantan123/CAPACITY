import copy
import unittest
from datetime import date
from decimal import Decimal

from capacity_engine import plan
from support import EVIDENCE, add_family, config, demand, facility, integrated_config, no_gate


D = Decimal


class EngineTests(unittest.TestCase):
    def isolated(self, keep, quantity=10):
        c = config(end="2026-01-06")
        c["facilities"][0]["demands"][0]["quantity"] = quantity
        for gate in ("crew", "cell", "bay", "materials", "quality"):
            if gate not in keep:
                no_gate(c, gate)
        return c

    def result(self, c):
        result = plan(c)
        self.assertEqual(result["status"], "Ready", result["diagnostics"])
        return result["facilities"][0]

    def test_baseline_hand_oracle(self):
        r = self.result(config())
        self.assertEqual(r["summary"]["allocated_units"], 4)
        a = r["allocations"][0]
        self.assertEqual(a["start_date"], date(2026, 1, 5))
        self.assertEqual(a["modeled_ship_date"], date(2026, 1, 6))
        first_stock = r["inventory"][0]
        self.assertEqual((first_stock["consumed"], first_stock["ending_on_hand"]), (D(8), D(2)))

    def test_no_demand_distinct_from_unserved(self):
        c = config()
        c["facilities"][0]["demands"] = []
        r = plan(c)
        self.assertEqual(r["status"], "No demand")
        self.assertFalse(r["facilities"][0]["allocations"])
        c["facilities"][0]["demands"] = [demand(qty=0)]
        self.assertEqual(plan(c)["status"], "No demand")

    def test_closed_cancelled_releases_excluded_not_backlog(self):
        c = config()
        f = c["facilities"][0]
        f["demands"] = [{**demand("closed", qty=9), "status": "closed"}, {**demand("cancelled", qty=3), "status": "cancelled"}]
        r = plan(c)
        self.assertEqual(r["status"], "No demand")
        self.assertEqual(r["facilities"][0]["summary"]["unserved_known_units"], 0)
        self.assertTrue(all(o["status"] == "Excluded" for o in r["facilities"][0]["demand_outcomes"]))

    def test_undated_release_visible_queued_blocked(self):
        c = config()
        c["facilities"][0]["demands"][0]["customer_requested_date"] = None
        c["facilities"][0]["demands"][0]["internal_expected_date"] = "2026-01-06"
        r = plan(c)
        self.assertEqual(r["status"], "Blocked")
        o = r["facilities"][0]["demand_outcomes"][0]
        self.assertEqual(o["status"], "Queued incomplete")
        self.assertEqual(o["unserved_quantity"], 4)
        self.assertIsNone(o["modeled_first_ship_date"])

    def test_incomplete_qty_is_unknown_not_zero(self):
        c = config()
        c["facilities"][0]["demands"][0]["quantity"] = None
        r = plan(c)
        self.assertEqual(r["status"], "Blocked")
        self.assertIsNone(r["facilities"][0]["demand_outcomes"][0]["unserved_quantity"])

    def test_valid_rows_can_have_honest_partial_plan_beside_queue(self):
        c = config()
        c["facilities"][0]["demands"].append(demand("incomplete", qty=None))
        r = plan(c)
        self.assertEqual(r["status"], "Blocked")
        self.assertTrue(r["facilities"][0]["partial_plan"])
        self.assertEqual(r["facilities"][0]["summary"]["allocated_units"], 4)

    def test_whole_crews_attendance_and_uncrewed_payroll(self):
        c = self.isolated({"crew"})
        pool = c["facilities"][0]["labor"][0]
        pool.update(crew_size=3, max_concurrent_crews=2)
        for day in pool["calendar"]:
            day["shifts"][0].update(qualified_headcount=5, attendance="0.8", regular_paid_hours="2")
        c["facilities"][0]["routes"][0]["loads"][0].update(first_pass_hours_per_unit="3", required_crew_size=3)
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 2)
        self.assertEqual(r["labor_usage"][0]["whole_crews"], 1)
        self.assertEqual(r["labor_usage"][0]["expected_paid_regular_hours"], D(8))
        self.assertEqual(r["labor_usage"][0]["allocated_regular_hours"], D(6))

    def test_max_concurrent_crews_caps_capacity(self):
        c = self.isolated({"crew"}, 100)
        pool = c["facilities"][0]["labor"][0]
        pool["max_concurrent_crews"] = 1
        for day in pool["calendar"]:
            day["shifts"][0]["qualified_headcount"] = 8
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 8)

    def test_disjoint_shifts_add_without_duplicating_pool(self):
        c = self.isolated({"crew"}, 100)
        pool = c["facilities"][0]["labor"][0]
        for day in pool["calendar"]:
            first = day["shifts"][0]
            first.update(qualified_headcount=2, regular_paid_hours="4", start_hour="0")
            day["shifts"].append({**copy.deepcopy(first), "id": "evening", "start_hour": "12"})
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 8)

    def test_regular_ot_reservations_consume_global_budget(self):
        c = self.isolated({"crew"}, 100)
        for day in c["facilities"][0]["labor"][0]["calendar"]:
            day["shifts"][0].update(qualified_headcount=2, regular_paid_hours="4", ot_paid_hours="2",
                                  reserved_regular_hours="2", reserved_ot_hours="2")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 4)
        self.assertEqual(r["labor_usage"][0]["allocated_regular_hours"], D(6))
        self.assertEqual(r["labor_usage"][0]["allocated_ot_hours"], D(2))

    def test_labor_productivity_is_not_applied_twice(self):
        c = self.isolated({"crew"}, 100)
        for day in c["facilities"][0]["labor"][0]["calendar"]:
            day["shifts"][0].update(qualified_headcount=2, regular_paid_hours="4", productive_fraction="0.5")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 2)
        self.assertEqual(r["labor_usage"][0]["expected_paid_regular_hours"], D(8))
        self.assertEqual(r["labor_usage"][0]["allocated_regular_hours"], D(4))

    def test_machine_count_maintenance_uptime_performance_once(self):
        c = self.isolated({"cell"}, 100)
        for day in c["facilities"][0]["machines"][0]["calendar"]:
            day.update(count=2, scheduled_hours="8", maintenance_hours="4", uptime="0.5", performance="0.5", reserved_hours="1")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 1)
        row = next(row for row in r["resource_loads"] if row["kind"] == "machine")
        self.assertEqual((row["capacity"], row["load"], row["slack"]), (D(2), D(2), D(0)))

    def test_complete_machine_downtime_zero_not_unknown(self):
        c = self.isolated({"cell"})
        for day in c["facilities"][0]["machines"][0]["calendar"]:
            day["uptime"] = "0"
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 0)

    def test_separate_rework_adds_measured_load_once(self):
        c = self.isolated({"cell"})
        load = c["facilities"][0]["routes"][0]["loads"][0]
        load.update(first_pass_hours_per_unit="1", rework_hours_per_unit="1")
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 4)

    def test_bundled_rework_is_unchanged(self):
        c = self.isolated({"cell"})
        c["facilities"][0]["routes"][0]["loads"][0]["rework_mode"] = "bundled"
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 4)

    def test_setup_ceil_batches_with_partial_last_batch(self):
        c = self.isolated({"cell"})
        route = c["facilities"][0]["routes"][0]
        route["batch_size"] = 2
        route["loads"][0].update(first_pass_hours_per_unit="1", setup_hours_per_batch="2")
        for day in c["facilities"][0]["machines"][0]["calendar"]:
            day["scheduled_hours"] = "7"
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 3)
        self.assertEqual(r["allocations"][0]["batch_count"], 2)
        row = next(row for row in r["resource_loads"] if row["kind"] == "machine")
        self.assertEqual(row["load"], D(7))

    def test_setup_only_operation(self):
        c = self.isolated({"cell"}, 10)
        route = c["facilities"][0]["routes"][0]
        route["batch_size"] = 3
        route["loads"][0].update(first_pass_hours_per_unit="0", setup_hours_per_batch="2")
        for day in c["facilities"][0]["machines"][0]["calendar"]:
            day["scheduled_hours"] = "4"
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 6)

    def test_separate_releases_do_not_share_one_setup(self):
        c = self.isolated({"cell"}, 1)
        f = c["facilities"][0]
        f["demands"].append(demand("another-order", qty=1))
        f["routes"][0]["loads"][0].update(first_pass_hours_per_unit="1", setup_hours_per_batch="2")
        for day in f["machines"][0]["calendar"]:
            day["scheduled_hours"] = "5"
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 1)

    def test_shared_family_pool_consumes_one_budget(self):
        c = self.isolated({"cell"}, 4)
        add_family(c, quantity=4)
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 4)
        self.assertEqual(sum(row["load"] for row in r["resource_loads"] if row["kind"] == "machine"), D(8))

    def test_explicit_priority_precedes_due_date(self):
        c = self.isolated({"cell"}, 4)
        add_family(c, quantity=4, key="urgent")
        f = c["facilities"][0]
        f["demands"][0].update(priority=5, customer_requested_date="2026-01-04")
        f["demands"][1].update(priority=0, customer_requested_date="2026-01-09")
        self.assertEqual(self.result(c)["allocations"][0]["business_key"], "urgent")

    def test_earliest_due_breaks_equal_priority(self):
        c = self.isolated({"cell"}, 4)
        add_family(c, quantity=4, key="earlier")
        c["facilities"][0]["demands"][1]["customer_requested_date"] = "2026-01-04"
        self.assertEqual(self.result(c)["allocations"][0]["business_key"], "earlier")

    def test_same_due_tie_is_business_key_deterministic(self):
        c = self.isolated({"cell"}, 4)
        c["facilities"][0]["demands"][0]["business_key"] = "Z"
        add_family(c, quantity=4, key="A")
        r1 = plan(c)
        c["facilities"][0]["demands"].reverse()
        r2 = plan(c)
        self.assertEqual(r1["facilities"][0]["allocations"], r2["facilities"][0]["allocations"])
        self.assertEqual(r2["facilities"][0]["allocations"][0]["business_key"], "A")

    def test_zero_receipts_are_not_capacity(self):
        c = self.isolated({"materials"})
        s = c["facilities"][0]["stocks"][0]
        s.update(on_hand="0", receipts=[{"id": "zero", "date": "2026-01-05", "quantity": "0", "evidence": EVIDENCE}])
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 0)

    def test_future_receipts_do_not_satisfy_earlier_start(self):
        c = config()
        s = c["facilities"][0]["stocks"][0]
        s.update(on_hand="0", receipts=[{"id": "future", "date": "2026-01-07", "quantity": "8", "evidence": EVIDENCE}])
        r = self.result(c)
        self.assertEqual(r["allocations"][0]["start_date"], date(2026, 1, 7))
        self.assertTrue(all(row["consumed"] == 0 for row in r["inventory"] if row["date"] < date(2026, 1, 7)))
        self.assertEqual(r["allocations"][0]["requested_late_days"], 2)

    def test_cumulative_inventory_across_days(self):
        c = config()
        f = c["facilities"][0]
        f["demands"][0]["quantity"] = 6
        f["stocks"][0].update(on_hand="4", receipts=[{"id": "later", "date": "2026-01-07", "quantity": "4", "evidence": EVIDENCE}])
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 4)
        self.assertEqual(sum(row["consumed"] for row in r["inventory"]), D(8))
        self.assertEqual(r["inventory"][-1]["ending_on_hand"], D(0))

    def test_allocations_and_safety_stock_not_consumed(self):
        c = self.isolated({"materials"}, 10)
        c["facilities"][0]["stocks"][0].update(on_hand="10", allocated="2", safety_stock="2")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 3)
        self.assertEqual(r["inventory"][-1]["ending_on_hand"], D(4))

    def test_two_products_share_bom_conservatively(self):
        c = self.isolated({"materials"}, 4)
        add_family(c, quantity=4)
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 5)
        self.assertEqual(sum(row["consumed"] for row in r["inventory"]), D(10))

    def test_decimal_material_precision_no_float_rounding_loss(self):
        c = self.isolated({"materials"}, 10)
        f = c["facilities"][0]
        f["stocks"][0].update(uom="KG", on_hand="0.3")
        f["routes"][0]["materials"]["bom"][0].update(quantity_per_unit="0.1", uom="KG")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 3)
        self.assertEqual(r["inventory"][-1]["ending_on_hand"], D(0))

    def test_quality_future_release_is_not_borrowed(self):
        c = config()
        f = c["facilities"][0]
        f["families"][0]["quality"].update(released_units=0,
            releases=[{"id": "approval-later", "date": "2026-01-07", "quantity": 4, "evidence": EVIDENCE}])
        r = self.result(c)
        self.assertEqual(r["allocations"][0]["start_date"], date(2026, 1, 7))
        self.assertEqual(r["quality"][-1]["remaining"], D(0))

    def test_quality_shared_across_releases(self):
        c = self.isolated({"quality"}, 4)
        f = c["facilities"][0]
        f["families"][0]["quality"]["released_units"] = 5
        f["demands"].append(demand("another-order", qty=4))
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 5)

    def test_future_labor_not_borrowed_for_earlier_start(self):
        c = config()
        c["facilities"][0]["labor"][0]["calendar"][0]["shifts"] = []
        self.assertEqual(self.result(c)["allocations"][0]["start_date"], date(2026, 1, 6))

    def test_dated_operation_offset_and_lead_time(self):
        c = config()
        f = c["facilities"][0]
        f["routes"][0]["lead_days"] = 2
        f["routes"][0]["loads"][1]["offset_days"] = 1
        f["machines"][0]["calendar"][0]["scheduled_hours"] = "0"
        r = self.result(c)
        self.assertEqual(r["allocations"][0]["start_date"], date(2026, 1, 5))
        self.assertEqual(r["allocations"][0]["modeled_ship_date"], date(2026, 1, 7))
        used = [x for x in r["resource_loads"] if x["kind"] == "machine" and x["load"]]
        self.assertEqual(used[0]["date"], date(2026, 1, 6))

    def test_not_released_demand_cannot_start(self):
        c = config()
        c["facilities"][0]["demands"][0]["release_date"] = "2026-01-07"
        self.assertEqual(self.result(c)["allocations"][0]["start_date"], date(2026, 1, 7))

    def test_requested_promised_internal_modeled_dates_are_separate(self):
        c = config()
        d = c["facilities"][0]["demands"][0]
        d.update(customer_requested_date="2026-01-04", promised_date="2026-01-07", internal_expected_date="2026-01-10")
        c["facilities"][0]["due_date_policy"] = "promised_then_requested"
        a = self.result(c)["allocations"][0]
        self.assertEqual(a["due_date_used"], date(2026, 1, 7))
        self.assertEqual(a["modeled_ship_date"], date(2026, 1, 6))
        self.assertEqual(a["internal_expected_date"], date(2026, 1, 10))
        self.assertEqual((a["requested_late_days"], a["promised_late_days"]), (2, 0))

    def test_carryover_backlog_not_readded_daily(self):
        c = self.isolated({"materials"}, 8)
        f = c["facilities"][0]
        f["stocks"][0]["on_hand"] = "6"
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 3)
        self.assertEqual(r["summary"]["backlog_at_horizon_end"], 5)
        first, last = r["backlog"][0], r["backlog"][-1]
        self.assertEqual((first["in_plan_wip_quantity"], first["unstarted_quantity"], first["open_quantity"]), (3, 5, 8))
        self.assertEqual((last["completed_quantity"], last["open_quantity"]), (3, 5))

    def test_future_unreleased_quantity_is_not_current_backlog(self):
        c = config()
        c["facilities"][0]["demands"][0]["release_date"] = "2026-01-12"
        r = self.result(c)
        self.assertEqual(r["summary"]["future_unreleased_units"], 4)
        self.assertEqual(r["summary"]["backlog_at_horizon_end"], 0)
        self.assertEqual(r["demand_outcomes"][0]["reasons"][0]["code"], "RELEASE_OUTSIDE_HORIZON")

    def test_no_production_outside_validated_completion_horizon(self):
        c = config(end="2026-01-05")
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 0)
        self.assertEqual(r["demand_outcomes"][0]["reasons"][0]["code"], "COMPLETION_OUTSIDE_HORIZON")

    def test_space_peak_occupancy_retained_across_days(self):
        c = config(end="2026-01-09")
        f = c["facilities"][0]
        f["demands"][0]["quantity"] = 6
        f["stocks"][0]["on_hand"] = "12"
        r = self.result(c)
        self.assertEqual([(a["start_date"], a["quantity"]) for a in r["allocations"]], [(date(2026, 1, 5), 4), (date(2026, 1, 7), 2)])
        self.assertEqual(max(row["load"] for row in r["resource_loads"] if row["kind"] == "space_area"), D(100))

    def test_space_full_dwell_includes_weekends(self):
        c = config(start="2026-01-09", end="2026-01-13", tail="2026-01-16")
        f = c["facilities"][0]
        f["demands"][0]["quantity"] = 1
        f["routes"][0]["space"][0]["dwell_days"] = 3
        for day in f["space"][0]["calendar"]:
            if day["date"] in {"2026-01-10", "2026-01-11"}:
                day.update(usable_sqft="0", max_slots=0)
        for day in f["labor"][0]["calendar"]:
            if day["date"] in {"2026-01-10", "2026-01-11"}:
                day["shifts"] = []
        r = self.result(c)
        self.assertEqual(r["allocations"][0]["start_date"], date(2026, 1, 12))

    def test_space_checks_tail_past_shipment_horizon(self):
        c = self.isolated({"bay"}, 2)
        c["facilities"][0]["routes"][0]["space"][0]["dwell_days"] = 5
        c["facilities"][0]["space"][0]["calendar"][3].update(usable_sqft="25", max_slots=1)
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 1)
        tail = next(row for row in r["resource_loads"] if row["kind"] == "space_area" and row["date"] == date(2026, 1, 8))
        self.assertEqual(tail["load"], D(25))

    def test_unknown_space_tail_blocks_start_not_free_space(self):
        c = config(tail="2026-01-08")
        c["facilities"][0]["routes"][0]["space"][0]["dwell_days"] = 10
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 0)
        self.assertTrue(any(reason["code"] == "UNSUPPORTED_OCCUPIED_TAIL" for reason in r["demand_outcomes"][0]["reasons"]))

    def test_slot_limit_applies_even_with_abundant_area(self):
        c = self.isolated({"bay"}, 10)
        for day in c["facilities"][0]["space"][0]["calendar"]:
            day.update(usable_sqft="100000", max_slots=2)
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 2)

    def test_clearance_increases_footprint_not_average(self):
        c = self.isolated({"bay"}, 10)
        c["facilities"][0]["routes"][0]["space"][0].update(length_ft="3", width_ft="3", clearance_ft="1")
        self.assertEqual(self.result(c)["summary"]["allocated_units"], 4)

    def test_external_starting_space_reservations(self):
        c = self.isolated({"bay"}, 10)
        f = c["facilities"][0]
        f["wip"].update(state="external_reservations_only", reservations=[{
            "id": "external-wip", "resource": "bay", "from": "2026-01-01", "through": "2026-01-07",
            "sqft": "75", "slots": 3, "evidence": EVIDENCE}])
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 1)
        self.assertEqual(next(row for row in r["resource_loads"] if row["kind"] == "space_area")["reserved"], D(75))

    def test_independent_facility_addition_requires_no_code(self):
        c = config()
        c["facilities"].append(facility("TOTALLY_NEW_TEST_SITE", "new-custom-product"))
        r = plan(c)
        self.assertEqual(r["status"], "Ready")
        self.assertEqual([f["summary"]["allocated_units"] for f in r["facilities"]], [4, 4])
        self.assertEqual(r["facilities"][1]["allocations"][0]["family"], "new-custom-product")

    def test_blocked_site_does_not_borrow_from_or_block_valid_site(self):
        c = config()
        c["facilities"][0]["stocks"][0]["on_hand"] = None
        c["facilities"].append(facility("INDEPENDENT_TEST_SITE"))
        r = plan(c)
        self.assertEqual(r["status"], "Blocked")
        self.assertEqual(r["facilities"][0]["status"], "Blocked")
        self.assertEqual(r["facilities"][1]["summary"]["allocated_units"], 4)

    def test_integrated_two_site_mixed_resource_oracle(self):
        r = plan(integrated_config())
        self.assertEqual((r["status"], r["financial_status"]), ("Ready", "Ready"))
        a, b = r["facilities"]
        self.assertEqual((a["summary"]["allocated_units"], b["summary"]["allocated_units"]), (5, 2))
        self.assertEqual([(x["family"], x["quantity"], x["start_date"]) for x in a["allocations"]], [
            ("alpha", 2, date(2026, 1, 5)), ("beta", 1, date(2026, 1, 7)),
            ("alpha", 1, date(2026, 1, 8)), ("beta", 1, date(2026, 1, 8))])
        af = a["financials"]
        self.assertEqual(af["expected_staffed_payroll"]["direct_by_currency"], {"USD": D(1050)})
        self.assertEqual(af["expected_staffed_payroll"]["loaded_by_currency"], {"USD": D(1230)})
        self.assertEqual(af["allocated_touch_labor"]["direct_by_currency"], {"USD": D(170)})
        self.assertEqual(af["allocated_touch_labor"]["loaded_by_currency"], {"USD": D(204)})
        self.assertEqual(af["projected_shipment_value"]["by_currency"], {"USD": D(450)})
        self.assertEqual(af["modeled_occupied_area_cost"]["by_currency"], {"USD": D("13.2")})
        self.assertEqual(b["financials"]["projected_shipment_value"]["by_currency"], {"CAD": D(400)})
        self.assertEqual(b["financials"]["allocated_touch_labor"]["loaded_by_currency"], {"CAD": D(46)})

    def test_decimal_machine_capacity_rounding_never_exceeds_limit(self):
        c = self.isolated({"cell"}, 10)
        for day in c["facilities"][0]["machines"][0]["calendar"]:
            day["scheduled_hours"] = "1"
        c["facilities"][0]["routes"][0]["loads"][0]["first_pass_hours_per_unit"] = "0.3"
        r = self.result(c)
        self.assertEqual(r["summary"]["allocated_units"], 3)
        first = next(row for row in r["resource_loads"] if row["kind"] == "machine")
        self.assertEqual((first["load"], first["slack"]), (D("0.9"), D("0.1")))

    def test_plan_is_pure_and_hash_deterministic(self):
        c = integrated_config()
        before = copy.deepcopy(c)
        first, second = plan(c), plan(c)
        self.assertEqual(c, before)
        self.assertEqual(first, second)
        self.assertEqual(len(first["run_hash"]), 64)
        c["metadata"]["version"] = "different"
        self.assertNotEqual(plan(c)["run_hash"], first["run_hash"])


if __name__ == "__main__":
    unittest.main()
