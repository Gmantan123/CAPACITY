import copy
import unittest
from decimal import Decimal

from capacity_engine import ScenarioError, apply_scenario, plan, validate_config
from support import EVIDENCE, config, integrated_config, no_gate, scenario, value_rate, wage_rate


D = Decimal


class FinanceTests(unittest.TestCase):
    def test_ot_cost_distinguishes_paid_from_touch_hours(self):
        c = config(end="2026-01-06")
        f = c["facilities"][0]
        for gate in ("cell", "bay", "materials", "quality"):
            no_gate(c, gate)
        f["labor"][0]["calendar"][0]["shifts"][0].update(qualified_headcount=2, regular_paid_hours="1", ot_paid_hours="2", productive_fraction="0.5")
        f["labor"][0]["calendar"][1]["shifts"] = []
        r = plan(c)["facilities"][0]
        self.assertEqual(r["summary"]["allocated_units"], 1)
        costs = r["financials"]
        self.assertEqual(costs["expected_staffed_payroll"]["direct_by_currency"], {"USD": D(80)})
        self.assertEqual(costs["expected_staffed_payroll"]["loaded_by_currency"], {"USD": D(92)})
        self.assertEqual(costs["allocated_touch_labor"]["direct_by_currency"], {"USD": D(25)})
        self.assertEqual(costs["allocated_touch_labor"]["loaded_by_currency"], {"USD": D(29)})

    def test_regular_hours_across_shifts_used_before_ot(self):
        c = config(end="2026-01-06")
        f = c["facilities"][0]
        for gate in ("cell", "bay", "materials", "quality"):
            no_gate(c, gate)
        f["demands"][0]["quantity"] = 2
        for day in f["labor"][0]["calendar"]:
            a = day["shifts"][0]
            a.update(qualified_headcount=2, start_hour="0", regular_paid_hours="1", ot_paid_hours="1")
            day["shifts"].append({**copy.deepcopy(a), "id": "late", "start_hour": "12", "ot_paid_hours": "0"})
        r = plan(c)["facilities"][0]
        self.assertEqual(r["financials"]["allocated_touch_labor"]["direct_by_currency"], {"USD": D(40)})
        self.assertEqual(sum(s["allocated_ot_hours"] for s in r["labor_usage"]), D(0))

    def test_missing_rate_blocks_financial_total_not_units(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"] = []
        r = plan(c)
        self.assertEqual((r["status"], r["financial_status"]), ("Ready", "Blocked"))
        f = r["facilities"][0]
        self.assertEqual(f["summary"]["allocated_units"], 4)
        self.assertIsNone(f["financials"]["expected_staffed_payroll"]["direct_by_currency"])
        self.assertIsNone(f["financials"]["allocated_touch_labor"]["loaded_by_currency"])

    def test_annual_salary_not_treated_as_hourly(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"][0].update(rate_unit="currency_per_year", base_wage="75000")
        v = validate_config(c)
        self.assertFalse(v.physical_blocked)
        self.assertTrue(any(d.severity == "financial" and d.path.endswith("rate_unit") for d in v.diagnostics))
        f = plan(c)["facilities"][0]
        self.assertEqual(f["summary"]["allocated_units"], 4)
        self.assertIsNone(f["financials"]["expected_staffed_payroll"]["direct_by_currency"])

    def test_missing_rate_unit_not_assumed_hourly(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"][0].pop("rate_unit")
        self.assertEqual(plan(c)["financial_status"], "Blocked")

    def test_wrong_financial_units_block_financial_metric(self):
        for target in ("shipment", "psf"):
            c = config()
            if target == "shipment":
                c["facilities"][0]["families"][0]["shipment_values"][0]["rate_unit"] = "currency_per_order"
            else:
                c["facilities"][0]["space"][0]["psf_rates"][0]["rate_unit"] = "currency_per_sqft_year"
            self.assertEqual(plan(c)["financial_status"], "Blocked")

    def test_missing_unit_value_is_not_zero_or_revenue(self):
        c = config()
        c["facilities"][0]["families"][0]["shipment_values"] = []
        r = plan(c)
        self.assertEqual(r["status"], "Ready")
        self.assertIsNone(r["facilities"][0]["financials"]["projected_shipment_value"]["by_currency"])

    def test_explicit_zero_validated_money_rates(self):
        c = config()
        f = c["facilities"][0]
        f["labor"][0]["rates"][0].update(base_wage="0", burden_per_paid_hour="0")
        f["families"][0]["shipment_values"][0]["amount"] = "0"
        f["space"][0]["psf_rates"][0]["amount"] = "0"
        r = plan(c)
        self.assertEqual(r["financial_status"], "Ready")
        self.assertEqual(r["facilities"][0]["financials"]["projected_shipment_value"]["by_currency"], {"USD": D(0)})

    def test_wage_effectivity_on_operation_date_value_on_ship_date(self):
        c = config()
        f = c["facilities"][0]
        f["labor"][0]["rates"] = [wage_rate("10", end="2026-01-05"), wage_rate("20", start="2026-01-06", version="w2")]
        f["families"][0]["shipment_values"] = [value_rate("100", end="2026-01-05"), value_rate("200", start="2026-01-06", version="v2")]
        money = plan(c)["facilities"][0]["financials"]
        self.assertEqual(money["allocated_touch_labor"]["direct_by_currency"], {"USD": D(80)})
        self.assertEqual(money["expected_staffed_payroll"]["direct_by_currency"], {"USD": D(2240)})
        self.assertEqual(money["projected_shipment_value"]["by_currency"], {"USD": D(800)})

    def test_payroll_rate_gap_does_not_poison_known_touch_metric(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"][0]["effective_to"] = "2026-01-05"
        money = plan(c)["facilities"][0]["financials"]
        self.assertEqual(money["expected_staffed_payroll"]["status"], "Blocked")
        self.assertEqual(money["allocated_touch_labor"]["status"], "Ready")
        self.assertEqual(money["allocated_touch_labor"]["direct_by_currency"], {"USD": D(80)})

    def test_overlapping_wages_block_finance(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"].append(wage_rate("30", version="overlap"))
        v = validate_config(c)
        self.assertFalse(v.physical_blocked)
        self.assertTrue(any(d.code == "OVERLAPPING_EFFECTIVITY" and d.severity == "financial" for d in v.diagnostics))
        self.assertEqual(plan(c)["financial_status"], "Blocked")

    def test_currency_mismatch_not_implicitly_converted(self):
        c = config()
        c["facilities"][0]["labor"][0]["rates"][0]["currency"] = "CAD"
        v = validate_config(c)
        self.assertFalse(v.physical_blocked)
        self.assertIn("INCONSISTENT_CURRENCY", {d.code for d in v.diagnostics})
        self.assertIsNone(plan(c)["facilities"][0]["financials"]["allocated_touch_labor"]["direct_by_currency"])

    def test_currencies_remain_separate_site_buckets(self):
        r = plan(integrated_config())
        self.assertNotIn("grand_total", r)
        self.assertEqual(set(r["facilities"][0]["financials"]["projected_shipment_value"]["by_currency"]), {"USD"})
        self.assertEqual(set(r["facilities"][1]["financials"]["projected_shipment_value"]["by_currency"]), {"CAD"})

    def test_unapproved_rate_evidence_only_blocks_finance(self):
        c = config()
        c["evidence"].append({"id": "unapproved-rate", "version": "proposal", "source": "Synthetic proposal", "as_of": "2026-01-05", "approved": False, "approved_by": None})
        c["facilities"][0]["labor"][0]["rates"][0]["evidence"] = "unapproved-rate"
        r = plan(c)
        self.assertEqual((r["status"], r["financial_status"]), ("Ready", "Blocked"))

    def test_psf_cost_never_changes_space_capacity(self):
        c = config()
        original = plan(c)
        c["facilities"][0]["space"][0]["psf_rates"][0]["amount"] = "99999"
        changed = plan(c)
        self.assertEqual(original["facilities"][0]["allocations"], changed["facilities"][0]["allocations"])
        self.assertEqual(original["facilities"][0]["resource_loads"], changed["facilities"][0]["resource_loads"])

    def test_money_decimal_precision(self):
        c = config()
        c["facilities"][0]["families"][0]["shipment_values"][0]["amount"] = "0.10"
        money = plan(c)["facilities"][0]["financials"]["projected_shipment_value"]["by_currency"]["USD"]
        self.assertEqual(money, D("0.40"))


class ScenarioTests(unittest.TestCase):
    def test_deep_copy_independence_and_provenance(self):
        c = config()
        original = copy.deepcopy(c)
        s = scenario("/facilities/0/labor/0/calendar/0/shifts/0/qualified_headcount", 2)
        changed = apply_scenario(c, s)
        self.assertEqual(c, original)
        self.assertNotEqual(changed["metadata"]["version"], c["metadata"]["version"])
        self.assertEqual(changed["scenario"]["baseline_run_hash"], plan(c)["run_hash"])
        changed["facilities"][0]["stocks"][0]["on_hand"] = "0"
        self.assertEqual(c["facilities"][0]["stocks"][0]["on_hand"], "10")
        self.assertNotEqual(plan(changed)["run_hash"], plan(c)["run_hash"])

    def test_rework_reduction_requires_quality_approval(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["rework_hours_per_unit"] = "1"
        s = scenario("/facilities/0/routes/0/loads/0/rework_hours_per_unit", "0.5")
        with self.assertRaisesRegex(ScenarioError, "quality"):
            apply_scenario(c, s)

    def test_approved_separate_rework_scenario_correct_cost(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["rework_hours_per_unit"] = "1"
        s = scenario("/facilities/0/routes/0/loads/0/rework_hours_per_unit", "0.5",
            quality_approval={"approved": True, "approved_by": "Synthetic quality owner", "version": "q1", "source": "Synthetic experiment", "as_of": "2026-01-05"})
        changed = apply_scenario(c, s)
        before = plan(c)["facilities"][0]["financials"]["allocated_touch_labor"]["direct_by_currency"]["USD"]
        after = plan(changed)["facilities"][0]["financials"]["allocated_touch_labor"]["direct_by_currency"]["USD"]
        self.assertEqual((before, after), (D(120), D(100)))
        self.assertEqual(c["facilities"][0]["routes"][0]["loads"][0]["rework_hours_per_unit"], "1")

    def test_bundled_rework_discount_never_allowed(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["rework_mode"] = "bundled"
        s = scenario("/facilities/0/routes/0/loads/0/first_pass_hours_per_unit", "1",
            quality_approval={"approved": True, "approved_by": "Synthetic quality owner", "version": "q1", "source": "Synthetic experiment", "as_of": "2026-01-05"})
        with self.assertRaisesRegex(ScenarioError, "bundled"):
            apply_scenario(c, s)

    def test_unapproved_scenario_and_unknown_path_rejected(self):
        c = config()
        s = scenario("/facilities/0/stocks/0/on_hand", "0")
        s["approved"] = False
        with self.assertRaises(ScenarioError):
            apply_scenario(c, s)
        s["approved"] = True
        s["changes"][0]["path"] = "/facilities/0/routes/0/coverage/crew"
        with self.assertRaises(ScenarioError):
            apply_scenario(c, s)

    def test_invalid_numeric_scenario_never_mutates_baseline(self):
        c = config()
        original = copy.deepcopy(c)
        for value in (-1, True, "NaN"):
            with self.subTest(value=value), self.assertRaises(ScenarioError):
                apply_scenario(c, scenario("/facilities/0/stocks/0/on_hand", value))
        self.assertEqual(c, original)

    def test_duplicate_change_paths_block(self):
        s = scenario("/facilities/0/stocks/0/on_hand", "20")
        s["changes"] *= 2
        with self.assertRaisesRegex(ScenarioError, "Duplicate"):
            apply_scenario(config(), s)

    def test_nonexistent_target_is_not_silently_added(self):
        with self.assertRaisesRegex(ScenarioError, "Unknown scenario target"):
            apply_scenario(config(), scenario("/facilities/9/stocks/0/on_hand", "20"))

    def test_stale_or_incomplete_quality_approval_blocked(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["rework_hours_per_unit"] = "1"
        for approval in ({"approved": True}, {"approved": True, "approved_by": "Synthetic quality owner", "version": "q1", "source": "Synthetic experiment", "as_of": "2025-01-05"}):
            s = scenario("/facilities/0/routes/0/loads/0/rework_hours_per_unit", "0.5", quality_approval=approval)
            with self.assertRaises(ScenarioError):
                apply_scenario(c, s)

    def test_blocked_baseline_cannot_be_discounted_into_validity(self):
        c = config()
        c["facilities"][0]["stocks"][0]["on_hand"] = None
        with self.assertRaisesRegex(ScenarioError, "Baseline"):
            apply_scenario(c, scenario("/facilities/0/stocks/0/on_hand", "20"))


if __name__ == "__main__":
    unittest.main()
