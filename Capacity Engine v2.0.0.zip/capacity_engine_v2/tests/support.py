"""SYNTHETIC TEST FIXTURES ONLY — not Chase, operational forecasts, or live facility data."""
from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta


START = "2026-01-05"
END = "2026-01-08"
EVIDENCE = "synthetic-approved"


def date_strings(start: str, end: str) -> list[str]:
    begin, finish = date.fromisoformat(start), date.fromisoformat(end)
    return [(begin + timedelta(days=i)).isoformat() for i in range((finish-begin).days + 1)]


def value_rate(amount="100", currency="USD", unit="currency_per_EA", start=START, end="2026-12-31", version="v1"):
    return {"version": version, "effective_from": start, "effective_to": end, "currency": currency,
            "rate_unit": unit, "amount": amount, "evidence": EVIDENCE}


def wage_rate(wage="10", currency="USD", start=START, end="2026-12-31", version="w1"):
    return {"version": version, "effective_from": start, "effective_to": end, "currency": currency,
            "rate_unit": "currency_per_paid_person_hour", "base_wage": wage,
            "ot_multiplier": "1.5", "burden_per_paid_hour": "2", "evidence": EVIDENCE}


def demand(key="TEST-ORDER/1/1", family="alpha", qty=4, due="2026-01-06", release=START, priority=0):
    return {"business_key": key, "family": family, "quantity": qty, "uom": "EA", "status": "open",
            "priority": priority, "release_date": release, "customer_requested_date": due,
            "promised_date": None, "internal_expected_date": None, "evidence": EVIDENCE}


def facility(key="SYNTHETIC_A", family="alpha", currency="USD", start=START, end=END, tail="2026-01-10"):
    calendar = date_strings(start, end)
    return {
        "id": key, "name": key + " — INVENTED TEST DATA ONLY", "horizon": {"start": start, "end": end, "occupancy_end": tail},
        "due_date_policy": "customer_requested", "demand_snapshot": {"status": "complete", "evidence": EVIDENCE},
        "wip": {"state": "confirmed_none", "reservations": [], "evidence": EVIDENCE}, "evidence": EVIDENCE,
        "labor": [{"id": "crew", "physical_pool": key + ":workforce", "crew_size": 2, "max_concurrent_crews": 2,
            "currency": currency, "calendar": [{"date": day, "evidence": EVIDENCE, "shifts": [{
                "id": "day", "workforce": key + ":qualified-team", "start_hour": "6", "qualified_headcount": 4,
                "attendance": "1", "regular_paid_hours": "8", "ot_paid_hours": "0", "productive_fraction": "1",
                "reserved_regular_hours": "0", "reserved_ot_hours": "0", "evidence": EVIDENCE}]} for day in calendar],
            "rates": [wage_rate(currency=currency, start=start)], "evidence": EVIDENCE}],
        "machines": [{"id": "cell", "physical_pool": key + ":equipment", "loss_basis": "availability_performance_only",
            "calendar": [{"date": day, "count": 1, "scheduled_hours": "8", "maintenance_hours": "0", "uptime": "1",
                "performance": "1", "reserved_hours": "0", "evidence": EVIDENCE} for day in calendar], "evidence": EVIDENCE}],
        "space": [{"id": "bay", "physical_pool": key + ":floor", "currency": currency,
            "calendar": [{"date": day, "usable_sqft": "100", "max_slots": 4, "reserved_sqft": "0", "reserved_slots": 0,
                          "evidence": EVIDENCE} for day in date_strings(start, tail)],
            "psf_rates": [value_rate("0.1", currency, "currency_per_sqft_day", start)], "evidence": EVIDENCE}],
        "stocks": [{"id": "plate", "physical_stock": key + ":part-lot", "part": "SYNTHETIC_COMPONENT", "uom": "EA",
            "snapshot_date": start, "on_hand": "10", "allocated": "0", "safety_stock": "0", "receipts": [], "evidence": EVIDENCE}],
        "families": [{"id": family, "uom": "EA", "value_currency": currency,
            "quality": {"status": "required", "snapshot_date": start, "released_units": 20, "releases": [], "evidence": EVIDENCE},
            "shipment_values": [value_rate(currency=currency, start=start)], "evidence": EVIDENCE}],
        "routes": [{"family": family, "version": "route-1", "effective_from": start, "effective_to": "2026-12-31",
            "lead_days": 1, "batch_size": 10, "timing_model": "day_bucket",
            "coverage": {"crew": "required", "cell": "required", "bay": "required"},
            "loads": [
                {"resource": "crew", "offset_days": 0, "unit": "person_hour", "first_pass_hours_per_unit": "2",
                 "rework_hours_per_unit": "0", "rework_mode": "separate", "setup_hours_per_batch": "0", "required_crew_size": 2},
                {"resource": "cell", "offset_days": 0, "unit": "machine_hour", "first_pass_hours_per_unit": "2",
                 "rework_hours_per_unit": "0", "rework_mode": "separate", "setup_hours_per_batch": "0"}],
            "space": [{"resource": "bay", "offset_days": 0, "length_ft": "5", "width_ft": "5", "clearance_ft": "0", "dwell_days": 2}],
            "materials": {"status": "required", "bom": [{"stock": "plate", "quantity_per_unit": "2", "uom": "EA"}]}, "evidence": EVIDENCE}],
        "demands": [demand(key + "/ORDER/1/1", family, release=start)],
    }


def config(**kwargs):
    return {"schema_version": "capacity-engine/v2", "metadata": {"version": "synthetic-v1", "source": "Invented unittest fixture",
        "approved": True, "approved_by": "Synthetic test owner — not operational approval", "approved_on": START},
        "as_of": START, "synthetic": True, "freshness_policy": {"max_age_days": 30, "on_stale": "block"},
        "evidence": [{"id": EVIDENCE, "version": "test-v1", "source": "Hand-computable invented test inputs",
            "as_of": START, "approved": True, "approved_by": "Synthetic test owner"}],
        "facilities": [facility(**kwargs)]}


def no_gate(config, kind):
    f = config["facilities"][0]
    for route in f["routes"]:
        if kind in {"crew", "cell"}:
            route["coverage"][kind] = "not_required"
            route["loads"] = [load for load in route["loads"] if load["resource"] != kind]
        elif kind == "bay":
            route["coverage"][kind] = "not_required"
            route["space"] = []
        elif kind == "materials":
            route["materials"] = {"status": "not_required", "bom": []}
    if kind == "quality":
        for family in f["families"]:
            family["quality"] = {"status": "not_required", "evidence": EVIDENCE}


def add_family(config, family_id="beta", quantity=2, key="TEST-ORDER/2/1"):
    f = config["facilities"][0]
    family = deepcopy(f["families"][0])
    family["id"] = family_id
    f["families"].append(family)
    route = deepcopy(f["routes"][0])
    route["family"] = family_id
    f["routes"].append(route)
    f["demands"].append(demand(key, family_id, quantity))
    return family, route


def scenario(path, value, **extra):
    return {"schema_version": "capacity-scenario/v1", "id": "SYNTHETIC_CHANGE", "version": "1",
            "source": "Invented test scenario", "as_of": START, "approved": True, "approved_by": "Synthetic owner",
            "changes": [{"path": path, "value": value}], **extra}


def integrated_config():
    c = config(end="2026-01-09", tail="2026-01-12")
    a = c["facilities"][0]
    for day in a["labor"][0]["calendar"]:
        day["shifts"][0].update(qualified_headcount=3, regular_paid_hours="4", ot_paid_hours="2")
    for day in a["machines"][0]["calendar"]:
        day["scheduled_hours"] = "4"
    for day in a["space"][0]["calendar"]:
        day.update(usable_sqft="36", max_slots=3)
    a["stocks"][0].update(on_hand="6", allocated="1", safety_stock="1",
        receipts=[{"id": "SYNTHETIC_R1", "date": "2026-01-07", "quantity": "4", "evidence": EVIDENCE}])
    alpha = a["families"][0]
    alpha["quality"].update(released_units=2,
        releases=[{"id": "SYNTHETIC_Q1", "date": "2026-01-08", "quantity": 1, "evidence": EVIDENCE}])
    alpha["shipment_values"] = [value_rate("100", end="2026-01-07"), value_rate("150", start="2026-01-08", version="v2")]
    r = a["routes"][0]
    r["batch_size"] = 2
    r["loads"][0].update(rework_hours_per_unit="1", setup_hours_per_batch="1")
    r["loads"][1].update(first_pass_hours_per_unit="1", setup_hours_per_batch="1")
    r["space"][0].update(length_ft="2", width_ft="1", clearance_ft="1", dwell_days=3)
    a["demands"][0]["quantity"] = 3
    beta, beta_route = add_family(c, "beta", 3, "SYNTHETIC_A/ORDER/2/1")
    beta["quality"].update(released_units=3, releases=[])
    beta["shipment_values"] = [value_rate("50")]
    beta_route["loads"][0].update(first_pass_hours_per_unit="2", rework_hours_per_unit="0")
    beta_route["loads"][1].update(first_pass_hours_per_unit="0.5", setup_hours_per_batch="0")
    beta_route["space"][0].update(length_ft="3", width_ft="2", clearance_ft="0", dwell_days=2)
    beta_route["materials"]["bom"][0]["quantity_per_unit"] = "1"
    a["demands"][1].update(priority=1, customer_requested_date="2026-01-07")
    b = facility("SYNTHETIC_B", "gamma", "CAD", end="2026-01-09", tail="2026-01-12")
    b["labor"][0].update(crew_size=1, max_concurrent_crews=2,
        rates=[{**wage_rate("20", "CAD"), "burden_per_paid_hour": "3"}])
    for day in b["labor"][0]["calendar"]:
        day["shifts"][0].update(qualified_headcount=2, regular_paid_hours="4")
    for day in b["machines"][0]["calendar"]:
        day["scheduled_hours"] = "2"
    for day in b["space"][0]["calendar"]:
        day.update(usable_sqft="12", max_slots=2)
    b["space"][0]["psf_rates"][0]["amount"] = "0.2"
    b["stocks"][0]["on_hand"] = "2"
    b["families"][0]["quality"] = {"status": "not_required", "evidence": EVIDENCE}
    b["families"][0]["shipment_values"][0]["amount"] = "200"
    r = b["routes"][0]
    r["lead_days"] = 2
    r["loads"][0].update(first_pass_hours_per_unit="1", required_crew_size=1)
    r["loads"][1].update(first_pass_hours_per_unit="1", offset_days=1)
    r["space"][0].update(length_ft="3", width_ft="2")
    r["materials"]["bom"][0]["quantity_per_unit"] = "1"
    b["demands"][0].update(quantity=2, customer_requested_date="2026-01-07")
    c["facilities"].append(b)
    return c
