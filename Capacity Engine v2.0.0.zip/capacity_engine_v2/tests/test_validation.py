import copy
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from capacity_engine import plan, validate_config
from capacity_engine.io import load_json
from capacity_engine.domain import days
from support import EVIDENCE, add_family, config, demand, facility


class ValidationTests(unittest.TestCase):
    def assert_block(self, c, code=None):
        result = validate_config(c)
        self.assertEqual(result.as_dict()["status"], "Blocked")
        if code:
            self.assertIn(code, {d.code for d in result.diagnostics})
        return result

    def test_unknown_headcount_is_not_zero(self):
        c = config()
        c["facilities"][0]["labor"][0]["calendar"][0]["shifts"][0]["qualified_headcount"] = None
        self.assert_block(c, "MISSING")
        self.assertIsNone(plan(c)["facilities"][0]["summary"]["allocated_units"])

    def test_explicit_zero_headcount_is_evaluable(self):
        c = config()
        for day in c["facilities"][0]["labor"][0]["calendar"]:
            day["shifts"][0]["qualified_headcount"] = 0
        result = plan(c)
        self.assertEqual(result["status"], "Ready")
        self.assertEqual(result["facilities"][0]["summary"]["allocated_units"], 0)

    def test_negative_nonfinite_bool_and_fractional_headcounts(self):
        for value in (-1, True, False, "NaN", "Infinity", float("nan"), float("inf"), "1.5", [], {}):
            with self.subTest(value=repr(value)):
                c = config()
                c["facilities"][0]["labor"][0]["calendar"][0]["shifts"][0]["qualified_headcount"] = value
                self.assert_block(c)

    def test_nonfinite_demand_does_not_crash(self):
        for value in (float("nan"), float("inf"), Decimal("NaN")):
            c = config()
            c["facilities"][0]["demands"][0]["quantity"] = value
            self.assert_block(c)

    def test_fractional_demand_is_blocked(self):
        c = config()
        c["facilities"][0]["demands"][0]["quantity"] = "1.1"
        self.assert_block(c, "WHOLE_NUMBER")

    def test_unapproved_configuration(self):
        c = config()
        c["metadata"]["approved"] = False
        self.assert_block(c, "UNAPPROVED_CONFIGURATION")

    def test_unapproved_physical_evidence(self):
        c = config()
        c["evidence"][0]["approved"] = False
        self.assert_block(c, "UNAPPROVED")

    def test_unknown_evidence_reference(self):
        c = config()
        c["facilities"][0]["evidence"] = "missing-proof"
        self.assert_block(c, "UNKNOWN_EVIDENCE")

    def test_stale_evidence_blocks_by_policy(self):
        c = config()
        c["evidence"][0]["as_of"] = "2025-11-01"
        self.assert_block(c, "STALE_SOURCE")

    def test_stale_evidence_can_be_explicit_warning(self):
        c = config()
        c["evidence"][0]["as_of"] = "2025-11-01"
        c["freshness_policy"]["on_stale"] = "warn"
        r = validate_config(c)
        self.assertFalse(r.physical_blocked)
        self.assertTrue(any(d.code == "STALE_SOURCE" and d.severity == "warning" for d in r.diagnostics))
        self.assertEqual(r.provenance["evidence"][0]["age_days"], 65)

    def test_future_source_or_approval_rejected(self):
        for location in ("source", "approval"):
            c = config()
            if location == "source":
                c["evidence"][0]["as_of"] = "2026-01-06"
            else:
                c["metadata"]["approved_on"] = "2026-01-06"
            self.assert_block(c)

    def test_missing_horizon_and_impossible_date(self):
        for value in (None, "2026-02-30", "2026-1-5", "tomorrow"):
            c = config()
            c["facilities"][0]["horizon"]["start"] = value
            self.assert_block(c)

    def test_huge_invalid_horizon_never_expands_unbounded_days(self):
        def bounded(start, end):
            self.assertLessEqual((end-start).days, 731)
            return days(start, end)
        for start, end in (("0001-01-01", "9999-12-31"), ("1900-01-01", "2200-12-31"), ("2026-01-08", "2026-01-05")):
            c = config()
            c["facilities"][0]["horizon"].update(start=start, end=end, occupancy_end=end)
            with patch("capacity_engine.domain.days", side_effect=bounded):
                self.assert_block(c)

    def test_missing_calendar_is_not_a_closed_day(self):
        c = config()
        c["facilities"][0]["machines"][0]["calendar"].pop()
        self.assert_block(c, "MISSING_CALENDAR")

    def test_explicit_closed_calendar_is_valid(self):
        c = config()
        c["facilities"][0]["labor"][0]["calendar"][0]["shifts"] = []
        self.assertFalse(validate_config(c).physical_blocked)

    def test_duplicate_calendar(self):
        c = config()
        calendar = c["facilities"][0]["machines"][0]["calendar"]
        calendar.append(copy.deepcopy(calendar[0]))
        self.assert_block(c, "DUPLICATE_KEY")

    def test_overlapping_shifts_and_midnight(self):
        c = config()
        shifts = c["facilities"][0]["labor"][0]["calendar"][0]["shifts"]
        shifts.append({**copy.deepcopy(shifts[0]), "id": "other", "start_hour": "10"})
        self.assert_block(c, "OVERLAPPING_SHIFTS")
        shifts.pop()
        shifts[0]["start_hour"] = "20"
        self.assert_block(c, "SHIFT_CROSSES_DAY")

    def test_fractional_crew_requirements_and_mismatched_crew(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["required_crew_size"] = 3
        self.assert_block(c, "HETEROGENEOUS_CREW_UNSUPPORTED")

    def test_impossible_attendance_and_productivity(self):
        for field in ("attendance", "productive_fraction"):
            c = config()
            c["facilities"][0]["labor"][0]["calendar"][0]["shifts"][0][field] = "1.01"
            self.assert_block(c, "NUMBER_RANGE")

    def test_impossible_maintenance_and_reservations(self):
        for field, value, code in (("maintenance_hours", "9", "IMPOSSIBLE_MAINTENANCE"), ("reserved_hours", "9", "OVER_RESERVED"), ("uptime", "1.1", "NUMBER_RANGE")):
            c = config()
            c["facilities"][0]["machines"][0]["calendar"][0][field] = value
            self.assert_block(c, code)

    def test_unknown_resource_or_family(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["resource"] = "another-facility-crew"
        self.assert_block(c, "UNKNOWN_RESOURCE")
        c = config()
        c["facilities"][0]["demands"][0]["family"] = "undeclared"
        self.assert_block(c, "UNKNOWN_FAMILY")

    def test_missing_route_and_missing_applicability(self):
        c = config()
        c["facilities"][0]["routes"] = []
        self.assert_block(c, "MISSING_ROUTE")
        c = config()
        c["facilities"][0]["routes"][0]["coverage"].pop("crew")
        self.assert_block(c, "INCOMPLETE_RESOURCE_COVERAGE")

    def test_not_required_must_not_have_load(self):
        c = config()
        c["facilities"][0]["routes"][0]["coverage"]["cell"] = "not_required"
        self.assert_block(c, "ROUTE_COVERAGE_CONTRADICTION")

    def test_route_overlap_and_gap(self):
        c = config()
        r = copy.deepcopy(c["facilities"][0]["routes"][0])
        r["version"] = "route-2"
        c["facilities"][0]["routes"].append(r)
        self.assert_block(c, "OVERLAPPING_EFFECTIVITY")
        c["facilities"][0]["routes"] = [r]
        r["effective_from"] = "2026-01-06"
        self.assert_block(c, "MISSING_ROUTE")

    def test_wrong_units_or_late_operation(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["unit"] = "machine_hour"
        self.assert_block(c, "UNIT_MISMATCH")
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0]["offset_days"] = 1
        self.assert_block(c, "OPERATION_AFTER_COMPLETION")

    def test_double_rework_is_blocked(self):
        c = config()
        c["facilities"][0]["routes"][0]["loads"][0].update(rework_mode="bundled", rework_hours_per_unit="1")
        self.assert_block(c, "DOUBLE_REWORK")

    def test_material_snapshot_bom_and_unit_gates(self):
        c = config()
        c["facilities"][0]["stocks"] = []
        self.assert_block(c, "MISSING_MATERIAL_SNAPSHOT")
        c = config()
        c["facilities"][0]["routes"][0]["materials"]["bom"] = []
        self.assert_block(c, "MISSING_BOM")
        c = config()
        c["facilities"][0]["routes"][0]["materials"]["bom"][0]["uom"] = "KG"
        self.assert_block(c, "UNIT_MISMATCH")

    def test_snapshot_date_and_older_receipt_block(self):
        c = config()
        c["facilities"][0]["stocks"][0]["snapshot_date"] = "2026-01-04"
        self.assert_block(c, "SNAPSHOT_DATE")
        c = config()
        c["facilities"][0]["stocks"][0]["receipts"] = [{"id": "bad", "date": "2026-01-04", "quantity": "1", "evidence": EVIDENCE}]
        self.assert_block(c, "RECEIPT_BEFORE_SNAPSHOT")

    def test_allocated_plus_safety_cannot_exceed_onhand(self):
        c = config()
        c["facilities"][0]["stocks"][0].update(allocated="8", safety_stock="3")
        self.assert_block(c, "OVER_RESERVED")

    def test_unknown_and_active_wip_block(self):
        for state in ("unknown", "active_model_wip"):
            c = config()
            c["facilities"][0]["wip"]["state"] = state
            self.assert_block(c, "WIP_NOT_MODELED")

    def test_duplicate_identical_release_collapses_once(self):
        c = config()
        c["facilities"][0]["demands"] *= 2
        r = plan(c)
        self.assertEqual(r["status"], "Ready")
        self.assertEqual(r["facilities"][0]["summary"]["allocated_units"], 4)
        self.assertIn("DUPLICATE_DEMAND_COLLAPSED", {d["code"] for d in r["diagnostics"]})

    def test_conflicting_release_quantity_uom_or_site_blocks(self):
        for field, value in (("quantity", 8), ("uom", "KG"), ("promised_date", "2026-01-10")):
            c = config()
            d = copy.deepcopy(c["facilities"][0]["demands"][0])
            d[field] = value
            c["facilities"][0]["demands"].append(d)
            self.assert_block(c, "CONFLICTING_DEMAND_DUPLICATE")
        c = config()
        b = facility("OTHER_TEST_FACILITY")
        b["demands"][0]["business_key"] = c["facilities"][0]["demands"][0]["business_key"]
        c["facilities"].append(b)
        r = self.assert_block(c, "CROSS_SITE_DEMAND_DUPLICATE")
        self.assertTrue(all(r.blocked_for(f.id) for f in r.facilities))

    def test_physical_pool_cannot_be_duplicated_locally(self):
        c = config()
        a = c["facilities"][0]
        duplicate = copy.deepcopy(a["machines"][0])
        duplicate["id"] = "same-machine-again"
        a["machines"].append(duplicate)
        a["routes"][0]["coverage"][duplicate["id"]] = "not_required"
        self.assert_block(c, "DUPLICATED_PHYSICAL_POOL")

    def test_cross_site_shared_pool_explicitly_unsupported(self):
        c = config()
        b = facility("OTHER_TEST_FACILITY")
        b["machines"][0]["physical_pool"] = c["facilities"][0]["machines"][0]["physical_pool"]
        c["facilities"].append(b)
        r = self.assert_block(c, "UNSUPPORTED_CROSS_SITE_SHARED_POOL")
        self.assertTrue(all(r.blocked_for(f.id) for f in r.facilities))
        c = config()
        c["shared_pools"] = [{"id": "proposed-central-crew"}]
        self.assert_block(c, "UNSUPPORTED_CROSS_SITE_SHARED_POOL")

    def test_same_workforce_cannot_be_redeclared(self):
        c = config()
        a = c["facilities"][0]
        other = copy.deepcopy(a["labor"][0])
        other.update(id="borrowed-again", physical_pool="new-name-same-staff")
        a["labor"].append(other)
        a["routes"][0]["coverage"]["borrowed-again"] = "not_required"
        self.assert_block(c, "SHARED_WORKFORCE_DUPLICATED")

    def test_unknown_fields_block_instead_of_being_ignored(self):
        c = config()
        c["facilities"][0]["machines"][0]["yield"] = "0.5"
        self.assert_block(c, "UNKNOWN_FIELD")

    def test_numeric_precision_bound(self):
        c = config()
        c["facilities"][0]["stocks"][0]["on_hand"] = "0.1234567890123"
        self.assert_block(c, "NUMERIC_PRECISION")

    def test_validation_is_pure(self):
        c = config()
        before = copy.deepcopy(c)
        validate_config(c)
        self.assertEqual(c, before)

    def test_duplicate_release_normalizes_supported_integer_representation(self):
        c = config()
        duplicate = copy.deepcopy(c["facilities"][0]["demands"][0])
        duplicate.update(quantity="4", priority=Decimal("0.0"))
        c["facilities"][0]["demands"].append(duplicate)
        r = plan(c)
        self.assertEqual(r["status"], "Ready")
        self.assertEqual(r["facilities"][0]["summary"]["allocated_units"], 4)
        self.assertIn("DUPLICATE_DEMAND_COLLAPSED", {d["code"] for d in r["diagnostics"]})

    def test_validate_status_is_blocked_for_queued_rows(self):
        c = config()
        c["facilities"][0]["demands"][0]["release_date"] = None
        self.assertEqual(validate_config(c).as_dict()["status"], "Blocked")
        self.assertEqual(validate_config(c).as_dict()["facilities"][0]["status"], "Blocked")

    def test_validate_no_demand_status(self):
        c = config()
        c["facilities"][0]["demands"] = []
        self.assertEqual(validate_config(c).as_dict()["status"], "No demand")

    def test_mixed_release_queue_blocks_exported_readiness_not_partial_allocation(self):
        root = Path(__file__).resolve().parents[1]
        c = load_json(root / "examples/synthetic/two_site.json")
        c["facilities"][0]["demands"][0]["quantity"] = None
        validated = validate_config(c)
        exported = validated.as_dict()
        self.assertFalse(validated.physical_blocked)
        self.assertFalse(validated.blocked_for("SYNTHETIC_A"))
        self.assertEqual(exported["status"], "Blocked")
        self.assertEqual(exported["facilities"], [
            {"id": "SYNTHETIC_A", "status": "Blocked"},
            {"id": "SYNTHETIC_B", "status": "Ready"},
        ])
        self.assertTrue(any(d["code"] == "INCOMPLETE_DEMAND" and d["severity"] == "queue"
                            for d in exported["diagnostics"]))
        planned = plan(validated)
        self.assertEqual(planned["status"], "Blocked")
        affected, independent = planned["facilities"]
        self.assertEqual(affected["status"], "Blocked")
        self.assertTrue(affected["partial_plan"])
        self.assertEqual(affected["summary"]["allocated_units"], 3)
        self.assertTrue(all(a["family"] == "beta" for a in affected["allocations"]))
        incomplete = next(d for d in affected["demand_outcomes"] if d["family"] == "alpha")
        self.assertEqual(incomplete["status"], "Queued incomplete")
        self.assertIsNone(incomplete["input_quantity"])
        self.assertIsNone(incomplete["unserved_quantity"])
        self.assertEqual(independent["status"], "Ready")
        self.assertFalse(independent["partial_plan"])
        self.assertEqual(independent["summary"]["allocated_units"], 2)


if __name__ == "__main__":
    unittest.main()
