# Capacity Engine v2.0.0 — start here

**Prerequisite:** Python **3.11+**. Standard library only; no installation, network connection or credentials required. Extract the ZIP, open a terminal in this `capacity_engine_v2` folder, then use these root-relative commands.

## Run and verify

```sh
# Invented two-site example: 5 units at SYNTHETIC_A, 2 at SYNTHETIC_B
python -B -m capacity_engine plan examples/synthetic/two_site.json --output release_verification/quick_start_plan.json --csv-dir release_verification/quick_start_csv

# Builder self-tests: expected 146 passing tests
python -B -m unittest discover -s tests -v

# Independent checks: expected 59 PASS, 0 FAIL, 1 DEFERRED_CAPABILITY
python -B independent_validation/run_acceptance.py --engine-root . --final

# Chase operating-input gate: expected Blocked and exit code 2
python -B -m capacity_engine plan examples/chase/blocked_config.json --output release_verification/chase_gate.json
```

The Chase result must have unknown (`null`) allocated units—not an invented forecast or an asserted zero-unit capacity. The deferred independent capability is **not** a passed capability. The independent harness also supports an explicit `--engine-root` when invoked from another working directory. It rewrites its generated inputs/reports, not engine code. Historical development/debug artifacts referenced in its report are intentionally not distributed.

## Know which data you are using

- `examples/chase/history.json`: source-backed aggregate history only. It retains Garrett's model-defined shipment population and unresolved duplicate flags; clock/pay ratios are **not routing standards**.
- `examples/chase/blocked_config.json`: deliberately unapproved/missing operating inputs. No Chase forecast is populated.
- `examples/synthetic/` and `independent_validation/inputs/`: conspicuously invented test data, never Chase or live-facility assumptions.
- `data_readiness.json`: parent's sanitized source-readiness supplement; not approval to load its provisional information as operating inputs.

## Scope and next steps

This is an offline, day-bucket **rough-cut** greedy engine—not optimal/finite APS. Cross-site shared pooling, active modeled starting WIP, mixed crew sizes within one pool, and overlapping/overnight shifts are unsupported. There are no implicit site transfers, alternate routes or currency conversions. Approved same-facility shared pools and explicit external reservations are supported. Review `README.md`, `schema/input_contract.json`, and the independent report for the full limits and deferred/policy differences.

This is **not a live app or Epicor connection**, and it does **not repair or certify the held Excel workbook**. No raw Office files, employee records, individual wages or credentials are included. Shipment value is not recognized revenue or profit; approval flags are metadata, not access control.

The original `README.md` and `BUILD_REPORT.json` are preserved. New staging-run evidence is in `release_verification/`; `RELEASE_MANIFEST.json` hashes the distributed files without replacing the original build manifest. All copied documentation/reports were already portable: no private-path normalization was needed.
