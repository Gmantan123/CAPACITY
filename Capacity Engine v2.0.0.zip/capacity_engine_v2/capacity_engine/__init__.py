"""Offline capacity calculation API; Python 3.11+, standard library only."""
from .domain import ENGINE_VERSION as __version__, ValidationResult
from .engine import plan
from .history import audit_history
from .scenario import ScenarioError, apply_scenario
from .validation import validate_config

__all__ = ["plan", "validate_config", "apply_scenario", "audit_history", "ValidationResult", "ScenarioError", "__version__"]
