"""Narrow numeric scenario edits on a deep copy, with explicit provenance and quality gates."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from decimal import Decimal, InvalidOperation
import re
from typing import Any

from .io import fingerprint
from .validation import validate_config


class ScenarioError(ValueError):
    pass


_ALLOWED = re.compile(
    r"/facilities/\d+/(?:"
    r"labor/\d+/calendar/\d+/shifts/\d+/(?:qualified_headcount|attendance|regular_paid_hours|ot_paid_hours|productive_fraction|reserved_regular_hours|reserved_ot_hours)|"
    r"labor/\d+/rates/\d+/(?:base_wage|ot_multiplier|burden_per_paid_hour)|"
    r"machines/\d+/calendar/\d+/(?:count|scheduled_hours|maintenance_hours|uptime|performance|reserved_hours)|"
    r"space/\d+/calendar/\d+/(?:usable_sqft|max_slots|reserved_sqft|reserved_slots)|"
    r"space/\d+/psf_rates/\d+/amount|"
    r"stocks/\d+/(?:on_hand|allocated|safety_stock|receipts/\d+/quantity)|"
    r"families/\d+/shipment_values/\d+/amount|"
    r"routes/\d+/(?:lead_days|batch_size|loads/\d+/(?:first_pass_hours_per_unit|rework_hours_per_unit|setup_hours_per_batch)|"
    r"space/\d+/(?:length_ft|width_ft|clearance_ft|dwell_days))"
    r")"
)


def _text(obj: dict[str, Any], key: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ScenarioError(f"Scenario {key} must be nonblank text")
    return value


def _date(value: Any, label: str) -> date:
    if not isinstance(value, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
        raise ScenarioError(f"{label} must be an ISO date")
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise ScenarioError(f"{label} is an impossible date") from error


def _approval(obj: Any, label: str, as_of: date) -> None:
    if not isinstance(obj, dict) or obj.get("approved") is not True:
        raise ScenarioError(f"{label} requires explicit approved=true (metadata, not authentication)")
    for key in ("approved_by", "source", "version"):
        _text(obj, key)
    if _date(obj.get("as_of"), label + ".as_of") > as_of:
        raise ScenarioError(f"{label} approval may not be future dated")


def _decimal(value: Any) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise ScenarioError("Scenario replacements must be finite numbers, not booleans")
    try:
        result = Decimal(str(value))
    except InvalidOperation as error:
        raise ScenarioError("Invalid scenario decimal") from error
    if not result.is_finite():
        raise ScenarioError("Scenario replacements must be finite")
    return result


def apply_scenario(baseline: dict[str, Any], scenario: dict[str, Any]) -> dict[str, Any]:
    """Apply existing numeric-leaf replacements; identities, routing applicability and calendars cannot be bypassed."""
    valid = validate_config(baseline)
    if valid.physical_blocked:
        raise ScenarioError("Baseline has blocked physical inputs; first reconcile and approve its configuration")
    if not isinstance(scenario, dict):
        raise ScenarioError("Scenario must be an object")
    allowed = {"schema_version", "id", "version", "source", "as_of", "approved", "approved_by", "quality_approval", "changes"}
    if set(scenario) - allowed:
        raise ScenarioError("Unknown scenario fields: " + ", ".join(sorted(set(scenario) - allowed)))
    if scenario.get("schema_version") != "capacity-scenario/v1":
        raise ScenarioError("Expected schema_version capacity-scenario/v1")
    as_of = _date(scenario.get("as_of"), "scenario.as_of")
    _approval(scenario, "Scenario", as_of)
    if as_of < _date(baseline["as_of"], "baseline.as_of"):
        raise ScenarioError("Scenario as_of cannot predate its baseline")
    identity = _text(scenario, "id")
    if not isinstance(scenario.get("changes"), list) or not scenario["changes"]:
        raise ScenarioError("Scenario needs a nonempty changes list")
    result = deepcopy(baseline)
    evidence_id = "scenario:" + identity + ":" + scenario["version"]
    if any(e["id"] == evidence_id for e in result["evidence"]):
        raise ScenarioError("Scenario evidence/version already exists; use a new explicit version")
    touched = set()
    for change in scenario["changes"]:
        if not isinstance(change, dict) or set(change) != {"path", "value"}:
            raise ScenarioError("Each change must contain exactly path and value")
        path = change["path"]
        if not isinstance(path, str) or _ALLOWED.fullmatch(path) is None:
            raise ScenarioError(f"Unsupported scenario path: {path!r}; edit and revalidate a versioned baseline for structural changes")
        if path in touched:
            raise ScenarioError(f"Duplicate scenario path {path!r}")
        touched.add(path)
        pieces = path.split("/")[1:]
        parent: Any = result
        owners: list[dict[str, Any]] = []
        try:
            for piece in pieces[:-1]:
                if isinstance(parent, dict):
                    owners.append(parent)
                    parent = parent[piece]
                elif isinstance(parent, list):
                    parent = parent[int(piece)]
                else:
                    raise ScenarioError(f"Noncontainer in scenario path {path!r}")
            if not isinstance(parent, dict) or pieces[-1] not in parent:
                raise ScenarioError(f"Scenario target must already exist: {path!r}")
        except (KeyError, IndexError) as error:
            raise ScenarioError(f"Unknown scenario target: {path!r}") from error
        old = _decimal(parent[pieces[-1]])
        new = _decimal(change["value"])
        if new < old and pieces[-1] in {"rework_hours_per_unit", "first_pass_hours_per_unit"}:
            if parent.get("rework_mode") == "bundled":
                raise ScenarioError("A bundled rework standard cannot be discounted by this scenario; obtain a separately measured approved replacement route")
            if pieces[-1] == "rework_hours_per_unit":
                approval = scenario.get("quality_approval")
                _approval(approval, "Rework reduction quality approval", as_of)
                age = (as_of - _date(approval["as_of"], "quality_approval.as_of")).days
                if age > int(Decimal(str(baseline["freshness_policy"]["max_age_days"]))):
                    raise ScenarioError("Quality approval is stale under the baseline policy")
        parent[pieces[-1]] = deepcopy(change["value"])
        owners.append(parent)
        for owner in reversed(owners):
            if "evidence" in owner:
                owner["evidence"] = evidence_id
                break
    result["as_of"] = as_of.isoformat()
    result["metadata"]["version"] = baseline["metadata"]["version"] + "+" + identity + ":" + scenario["version"]
    result["metadata"]["source"] = scenario["source"]
    result["metadata"]["approved_by"] = scenario["approved_by"]
    result["metadata"]["approved_on"] = as_of.isoformat()
    result["evidence"].append({"id": evidence_id, "version": scenario["version"], "source": scenario["source"],
        "as_of": as_of.isoformat(), "approved": True, "approved_by": scenario["approved_by"]})
    result["scenario"] = {**deepcopy(scenario), "baseline_run_hash": fingerprint(baseline),
                          "baseline_version": baseline["metadata"]["version"]}
    checked = validate_config(result)
    if checked.physical_blocked:
        issues = [f"{d.path}: {d.message}" for d in checked.diagnostics if d.severity == "block"]
        raise ScenarioError("Scenario violates physical input contract: " + "; ".join(issues))
    return result
