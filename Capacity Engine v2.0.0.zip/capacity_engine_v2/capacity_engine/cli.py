"""Offline CLI. Invalid rows remain diagnostics; no broad exception-to-success path."""
from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .engine import plan
from .history import audit_history
from .io import InputFileError, export_plan_csv, json_default, load_json, replace_demands_from_csv, write_json
from .scenario import ScenarioError, apply_scenario
from .validation import validate_config


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="python -m capacity_engine", description="Offline facility-configurable day-bucket rough-cut capacity engine")
    commands = root.add_subparsers(dest="command", required=True)
    for name in ("validate", "plan", "scenario", "history-audit"):
        sub = commands.add_parser(name)
        sub.add_argument("input", help="Relative or absolute local JSON input path")
        sub.add_argument("--output", help="Write JSON to this path instead of stdout")
        if name in {"validate", "plan"}:
            sub.add_argument("--demand-csv", help="Replace ALL facility demand lists with this canonical offline CSV; snapshot approvals remain required")
        if name == "plan":
            sub.add_argument("--csv-dir", help="Export allocation/load/outcome/inventory/backlog CSV tables")
        if name == "scenario":
            sub.add_argument("scenario", help="Versioned scenario JSON file")
            sub.add_argument("--config-output", help="Optionally save the deep-copied scenario configuration")
    return root


def main(argv: Sequence[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        config = load_json(args.input)
        if getattr(args, "demand_csv", None):
            config = replace_demands_from_csv(config, args.demand_csv)
        if args.command == "validate":
            result = validate_config(config).as_dict()
        elif args.command == "plan":
            result = plan(config)
            if args.csv_dir:
                export_plan_csv(result, args.csv_dir)
        elif args.command == "scenario":
            modified = apply_scenario(config, load_json(args.scenario))
            result = plan(modified)
            if args.config_output:
                write_json(args.config_output, modified)
        else:
            result = audit_history(config)
        if args.output:
            write_json(args.output, result)
        else:
            print(json.dumps(result, default=json_default, indent=2, sort_keys=True, allow_nan=False))
        return 2 if result["status"] == "Blocked" else 0
    except (InputFileError, ScenarioError, OSError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "Blocked", "error": type(error).__name__, "message": str(error)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
