"""Separate payroll, rate-costed touch effort, occupancy expense and shipment value."""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Any

from .domain import Facility, ZERO


def effective(rates: tuple[Any, ...], day: date) -> Any | None:
    matches = [rate for rate in rates if rate.start <= day <= rate.end]
    return matches[0] if len(matches) == 1 else None


def _metric(direct: dict[str, Decimal], loaded: dict[str, Decimal], missing: list[dict[str, Any]],
            hours: dict[str, Decimal]) -> dict[str, Any]:
    return {"status": "Blocked" if missing else "Ready",
            "direct_by_currency": None if missing else dict(sorted(direct.items())),
            "loaded_by_currency": None if missing else dict(sorted(loaded.items())),
            "hours": hours, "missing": missing}


def calculate_financials(facility: Facility, allocations: list[dict[str, Any]],
                         labor_usage: list[dict[str, Any]],
                         resource_loads: list[dict[str, Any]]) -> dict[str, Any]:
    pools = {pool.id: pool for pool in facility.labor}
    payroll_direct: dict[str, Decimal] = defaultdict(Decimal)
    payroll_loaded: dict[str, Decimal] = defaultdict(Decimal)
    touch_direct: dict[str, Decimal] = defaultdict(Decimal)
    touch_loaded: dict[str, Decimal] = defaultdict(Decimal)
    payroll_missing: list[dict[str, Any]] = []
    touch_missing: list[dict[str, Any]] = []
    paid_hours = {"regular_paid": ZERO, "ot_paid": ZERO}
    touch_hours = {"regular_productive": ZERO, "ot_productive": ZERO}
    rate_usage = set()
    for usage in labor_usage:
        pool = pools[usage["resource"]]
        rate = effective(pool.rates, usage["date"])
        pr, po = usage["expected_paid_regular_hours"], usage["expected_paid_ot_hours"]
        tr, to = usage["allocated_regular_hours"], usage["allocated_ot_hours"]
        paid_hours["regular_paid"] += pr
        paid_hours["ot_paid"] += po
        touch_hours["regular_productive"] += tr
        touch_hours["ot_productive"] += to
        if rate is None:
            missing = {"resource": pool.id, "date": usage["date"], "required": "effective approved base_wage, OT multiplier, burden, currency"}
            if pr + po > 0:
                payroll_missing.append(missing)
            if tr + to > 0:
                touch_missing.append(missing)
            continue
        rate_usage.add(("labor", pool.id, rate.version, rate.evidence))
        payroll = pr * rate.wage + po * rate.wage * rate.ot_multiplier
        touch = tr * rate.wage + to * rate.wage * rate.ot_multiplier
        payroll_direct[rate.currency] += payroll
        payroll_loaded[rate.currency] += payroll + (pr + po) * rate.burden
        touch_direct[rate.currency] += touch
        touch_loaded[rate.currency] += touch + (tr + to) * rate.burden
    families = {family.id: family for family in facility.families}
    values: dict[str, Decimal] = defaultdict(Decimal)
    value_missing = []
    for allocation in allocations:
        family = families[allocation["family"]]
        rate = effective(family.values, allocation["modeled_ship_date"])
        if rate is None:
            value_missing.append({"family": family.id, "date": allocation["modeled_ship_date"],
                                  "required": "effective validated shipment unit value and currency"})
        else:
            values[rate.currency] += allocation["quantity"] * rate.amount
            rate_usage.add(("shipment_value", family.id, rate.version, rate.evidence))
    space_pools = {space.id: space for space in facility.space}
    space_costs: dict[str, Decimal] = defaultdict(Decimal)
    space_missing = []
    area_days = ZERO
    for row in resource_loads:
        if row["kind"] != "space_area" or row["load"] == 0:
            continue
        area_days += row["load"]
        resource = space_pools[row["resource"]]
        rate = effective(resource.psf_rates, row["date"])
        if rate is None:
            space_missing.append({"resource": resource.id, "date": row["date"],
                                  "required": "effective validated currency per occupied sqft-day"})
        else:
            space_costs[rate.currency] += row["load"] * rate.amount
            rate_usage.add(("occupancy_psf", resource.id, rate.version, rate.evidence))
    metrics = {
        "expected_staffed_payroll": _metric(payroll_direct, payroll_loaded, payroll_missing, paid_hours),
        "allocated_touch_labor": _metric(touch_direct, touch_loaded, touch_missing, touch_hours),
        "projected_shipment_value": {"status": "Blocked" if value_missing else "Ready",
            "by_currency": None if value_missing else dict(sorted(values.items())), "missing": value_missing},
        "modeled_occupied_area_cost": {"status": "Blocked" if space_missing else "Ready",
            "by_currency": None if space_missing else dict(sorted(space_costs.items())),
            "occupied_sqft_days": area_days, "missing": space_missing},
    }
    return {"status": "Blocked" if any(m["status"] == "Blocked" for m in metrics.values()) else "Ready",
        "scope": "Staffed horizon payroll and actually modeled allocations only; queued/unserved demand is not financially forecast.",
        **metrics, "rate_versions_used": [{"type": t, "key": key, "version": version, "evidence": evidence}
                                         for t, key, version, evidence in sorted(rate_usage)],
        "notes": ["No currency conversion or cross-currency grand total.",
                  "Payroll includes expected attended paid hours, including nonproductive and uncrewed time.",
                  "Touch cost rates productive person-hours; it is not additional to payroll and is not a paid-hours allocation.",
                  "Shipment value is NOT recognized revenue, margin, cash, or profitability.",
                  "Currency per occupied sqft-day is financial only; it never increases physical space.",
                  "Unrounded Decimal values are retained; round display totals only under an approved currency policy."]}
