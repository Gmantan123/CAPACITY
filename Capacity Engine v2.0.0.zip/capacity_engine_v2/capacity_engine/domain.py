"""Immutable, validated planning inputs. Units are explicit; dates are calendar days."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from types import MappingProxyType
from collections.abc import Mapping
from typing import Any

ZERO = Decimal("0")
ONE = Decimal("1")
ENGINE_VERSION = "2.0.0"
SCHEMA_VERSION = "capacity-engine/v2"


def days(start: date, end: date) -> tuple[date, ...]:
    return tuple(start + timedelta(days=i) for i in range((end - start).days + 1))


@dataclass(frozen=True)
class Diagnostic:
    severity: str
    code: str
    path: str
    message: str
    facility: str | None = None
    metric: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {"severity": self.severity, "code": self.code, "path": self.path,
                "message": self.message, "facility": self.facility, "metric": self.metric}


@dataclass(frozen=True)
class Horizon:
    start: date
    end: date
    occupancy_end: date

    @property
    def planning_days(self) -> tuple[date, ...]:
        return days(self.start, self.end)

    @property
    def occupied_days(self) -> tuple[date, ...]:
        return days(self.start, self.occupancy_end)


@dataclass(frozen=True)
class WageRate:
    version: str
    start: date
    end: date
    currency: str
    wage: Decimal
    ot_multiplier: Decimal
    burden: Decimal
    evidence: str


@dataclass(frozen=True)
class ValueRate:
    version: str
    start: date
    end: date
    currency: str
    amount: Decimal
    evidence: str


@dataclass(frozen=True)
class Shift:
    id: str
    day: date
    workforce: str
    start_hour: Decimal
    qualified_headcount: int
    attendance: Decimal
    regular_paid_hours: Decimal
    ot_paid_hours: Decimal
    productive_fraction: Decimal
    reserved_regular_hours: Decimal
    reserved_ot_hours: Decimal
    evidence: str


@dataclass(frozen=True)
class LaborPool:
    id: str
    physical_pool: str
    crew_size: int
    max_concurrent_crews: int
    currency: str
    shifts: tuple[Shift, ...]
    rates: tuple[WageRate, ...]
    evidence: str


@dataclass(frozen=True)
class MachineDay:
    day: date
    count: int
    scheduled_hours: Decimal
    maintenance_hours: Decimal
    uptime: Decimal
    performance: Decimal
    reserved_hours: Decimal
    evidence: str


@dataclass(frozen=True)
class MachinePool:
    id: str
    physical_pool: str
    calendar: tuple[MachineDay, ...]
    evidence: str


@dataclass(frozen=True)
class SpaceDay:
    day: date
    usable_sqft: Decimal
    max_slots: int
    reserved_sqft: Decimal
    reserved_slots: int
    evidence: str


@dataclass(frozen=True)
class SpacePool:
    id: str
    physical_pool: str
    currency: str
    calendar: tuple[SpaceDay, ...]
    psf_rates: tuple[ValueRate, ...]
    evidence: str


@dataclass(frozen=True)
class DatedQuantity:
    id: str
    day: date
    quantity: Decimal
    evidence: str


@dataclass(frozen=True)
class Stock:
    id: str
    physical_stock: str
    part: str
    uom: str
    snapshot_date: date
    on_hand: Decimal
    allocated: Decimal
    safety_stock: Decimal
    receipts: tuple[DatedQuantity, ...]
    evidence: str


@dataclass(frozen=True)
class QualityGate:
    status: str
    snapshot_date: date | None
    released_units: int
    releases: tuple[DatedQuantity, ...]
    evidence: str


@dataclass(frozen=True)
class Family:
    id: str
    uom: str
    currency: str
    quality: QualityGate
    values: tuple[ValueRate, ...]
    evidence: str


@dataclass(frozen=True)
class ResourceLoad:
    resource: str
    offset_days: int
    unit: str
    first_pass: Decimal
    rework: Decimal
    rework_mode: str
    setup: Decimal
    required_crew_size: int | None

    @property
    def per_unit(self) -> Decimal:
        return self.first_pass + self.rework


@dataclass(frozen=True)
class SpaceUse:
    resource: str
    offset_days: int
    length_ft: Decimal
    width_ft: Decimal
    clearance_ft: Decimal
    dwell_days: int

    @property
    def footprint(self) -> Decimal:
        return (self.length_ft + 2 * self.clearance_ft) * (self.width_ft + 2 * self.clearance_ft)


@dataclass(frozen=True)
class BomLine:
    stock: str
    quantity: Decimal
    uom: str


@dataclass(frozen=True)
class Route:
    family: str
    version: str
    start: date
    end: date
    lead_days: int
    batch_size: int
    coverage: tuple[tuple[str, str], ...]
    loads: tuple[ResourceLoad, ...]
    space: tuple[SpaceUse, ...]
    materials_status: str
    bom: tuple[BomLine, ...]
    evidence: str


@dataclass(frozen=True)
class Demand:
    business_key: str
    family: str | None
    quantity: int | None
    uom: str | None
    status: str
    priority: int
    release_date: date | None
    customer_requested_date: date | None
    promised_date: date | None
    internal_expected_date: date | None
    incomplete_fields: tuple[str, ...]
    evidence: str


@dataclass(frozen=True)
class SpaceReservation:
    id: str
    resource: str
    start: date
    end: date
    sqft: Decimal
    slots: int
    evidence: str


@dataclass(frozen=True)
class Facility:
    id: str
    name: str
    horizon: Horizon
    due_policy: str
    labor: tuple[LaborPool, ...]
    machines: tuple[MachinePool, ...]
    space: tuple[SpacePool, ...]
    stocks: tuple[Stock, ...]
    families: tuple[Family, ...]
    routes: tuple[Route, ...]
    demands: tuple[Demand, ...]
    reservations: tuple[SpaceReservation, ...]
    evidence: str


def freeze_tree(value: Any) -> Any:
    """Own and recursively freeze metadata; dataclass frozen alone is only shallow."""
    if isinstance(value, Mapping):
        return MappingProxyType({key: freeze_tree(item) for key, item in value.items()})
    if isinstance(value, (tuple, list)):
        return tuple(freeze_tree(item) for item in value)
    return value


def thaw_tree(value: Any) -> Any:
    """Produce a new JSON-compatible tree for every public export."""
    if isinstance(value, Mapping):
        return {key: thaw_tree(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [thaw_tree(item) for item in value]
    return value


@dataclass(frozen=True)
class ValidationResult:
    facilities: tuple[Facility, ...]
    facility_ids: tuple[str, ...]
    diagnostics: tuple[Diagnostic, ...]
    provenance: Mapping[str, Any]
    run_hash: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "provenance", freeze_tree(self.provenance))

    @property
    def physical_blocked(self) -> bool:
        return any(d.severity == "block" for d in self.diagnostics)

    def blocked_for(self, facility: str) -> bool:
        return any(d.severity == "block" and d.facility in (None, facility)
                   for d in self.diagnostics)

    def as_dict(self) -> dict[str, Any]:
        facility_statuses = []
        for facility in self.facilities:
            queued = any(d.severity == "queue" and d.facility == facility.id for d in self.diagnostics)
            has_demand = any(d.status == "open" and d.quantity for d in facility.demands)
            status = "Blocked" if self.blocked_for(facility.id) or queued else "Ready" if has_demand else "No demand"
            facility_statuses.append({"id": facility.id, "status": status})
        blocked = self.physical_blocked or any(f["status"] == "Blocked" for f in facility_statuses)
        no_demand = facility_statuses and all(f["status"] == "No demand" for f in facility_statuses)
        return {
            "status": "Blocked" if blocked else "No demand" if no_demand else "Ready",
            "financial_status": "Blocked" if any(d.severity == "financial" for d in self.diagnostics) else "Ready",
            "run_hash": self.run_hash,
            "facilities": facility_statuses,
            "diagnostics": [d.as_dict() for d in self.diagnostics],
            "provenance": thaw_tree(self.provenance),
        }
