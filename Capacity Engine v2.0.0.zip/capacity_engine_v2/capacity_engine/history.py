"""Audit aggregate shipment/clock history; never convert it into a routing or forecast."""
from __future__ import annotations

from datetime import timedelta
from copy import deepcopy
from decimal import Decimal, localcontext
from typing import Any

from .domain import ZERO
from .io import fingerprint
from .validation import Validator


def audit_history(raw: dict[str, Any]) -> dict[str, Any]:
    v = Validator()
    root = v.obj(raw, "", {"schema_version", "facility", "synthetic", "window_start", "window_end",
        "reported_records", "candidate_distinct_records", "unresolved_duplicate_excess", "business_definition",
        "labor_basis", "weekly", "provenance", "notes"})
    v.enum(root.get("schema_version"), {"capacity-history/v1"}, "/schema_version")
    v.text(root.get("facility"), "/facility")
    v.boolean(root.get("synthetic"), "/synthetic")
    v.text(root.get("business_definition"), "/business_definition")
    v.enum(root.get("labor_basis"), {"clock_pay_not_proven_touch"}, "/labor_basis")
    start = v.day(root.get("window_start"), "/window_start")
    end = v.day(root.get("window_end"), "/window_end")
    if end < start or start.weekday() != 0 or end.weekday() != 6:
        v.issue("HISTORY_WINDOW", "", "Use an ordered window of complete Monday–Sunday weeks.")
    reported = v.integer(root.get("reported_records"), "/reported_records")
    distinct = v.integer(root.get("candidate_distinct_records"), "/candidate_distinct_records")
    excess = v.integer(root.get("unresolved_duplicate_excess"), "/unresolved_duplicate_excess")
    if distinct + excess != reported:
        v.issue("DUPLICATE_RECONCILIATION", "", "Candidate distinct + unresolved duplicate excess must equal reported records; this is not adjudication.")
    weekly = []
    for index, value in enumerate(v.arr(root.get("weekly"), "/weekly")):
        p = f"/weekly/{index}"
        item = v.obj(value, p, {"week_start", "shipment_records", "regular_clock_hours", "ot_clock_hours", "paid_hours"})
        week = v.day(item.get("week_start"), p + "/week_start")
        weekly.append({"date": week, "shipment_records": v.integer(item.get("shipment_records"), p + "/shipment_records"),
            **{key: v.number(item.get(key), p + "/" + key) for key in ("regular_clock_hours", "ot_clock_hours", "paid_hours")}})
        if week.weekday() != 0 or not start <= week <= end:
            v.issue("HISTORY_WEEK", p, "Week must be a Monday inside the complete window.")
    weekly.sort(key=lambda r: r["date"])
    v.unique([r["date"].isoformat() for r in weekly], "/weekly")
    expected = []
    if 0 <= (end-start).days <= 36500:
        day = start
        while day <= end:
            expected.append(day)
            day += timedelta(days=7)
    if [r["date"] for r in weekly] != expected:
        v.issue("INCOMPLETE_HISTORY", "/weekly", "History weeks must cover the entire complete window exactly once.")
    if sum(r["shipment_records"] for r in weekly) != reported:
        v.issue("HISTORY_TOTAL", "/reported_records", "Weekly shipment records do not reconcile to reported_records.")
    if any(d.severity == "block" for d in v.diagnostics):
        return {"status": "Blocked", "diagnostics": [d.as_dict() for d in v.diagnostics]}
    with localcontext() as context:
        context.prec = 50
        totals = {key: sum((r[key] for r in weekly), ZERO) for key in ("regular_clock_hours", "ot_clock_hours", "paid_hours")}
        recent = weekly[-8:]
        units = sum(r["shipment_records"] for r in recent)
        clock = sum((r["regular_clock_hours"] + r["ot_clock_hours"] for r in recent), ZERO)
        ratio = clock / units if units else None
        erroneous = clock / len(recent) / units if units and recent else None
        return {"status": "Ready", "meaning": "Aggregate-history audit only; NOT operating forecast readiness.",
            "run_hash": fingerprint(raw), "facility": root["facility"], "synthetic": root["synthetic"],
            "complete_weeks": len(weekly), "reported_model_defined_shipment_records": reported,
            "candidate_distinct_not_adjudicated": distinct, "unresolved_duplicate_excess": excess,
            "totals": totals, "regular_plus_ot_clock_hours": totals["regular_clock_hours"] + totals["ot_clock_hours"],
            "paid_less_regular_plus_ot": totals["paid_hours"]-totals["regular_clock_hours"]-totals["ot_clock_hours"],
            "recent_window": {"weeks": len(recent), "shipment_records": units, "regular_plus_ot_clock_hours": clock,
                "correct_aggregate_clock_hours_per_record": ratio,
                "incorrect_average_week_hours_over_window_output": erroneous,
                "understatement_factor": len(recent) if units else None},
            "provenance": deepcopy(root.get("provenance")), "business_definition": root["business_definition"],
            "warnings": ["The input's business shipment definition and source-field provenance are retained; no independent ERP line reconciliation is claimed.",
                "Duplicate candidates are NOT an approved deletion or reconciled distinct output count.",
                "Clock/pay hours are NOT proven productive touch time; corrected aggregate ratios are NOT routing standards.",
                "No customer forward demand, usable space, staffing, material readiness, prices or current labor rates are inferred.",
                "The separate daily enclosure-quantity/shipment-value population, if supplied later, must not be forced to match this grain."]}
