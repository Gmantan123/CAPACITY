"""Strict offline JSON/CSV boundaries. No network, spreadsheet, or ERP clients."""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from .domain import ENGINE_VERSION


class InputFileError(ValueError):
    pass


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise InputFileError(f"Duplicate JSON object key: {key!r}")
        result[key] = value
    return result


def _nonfinite(value: str) -> None:
    raise InputFileError(f"Nonfinite JSON number: {value}")


def load_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as handle:
        result = json.load(handle, parse_float=Decimal, object_pairs_hook=_unique_pairs,
                           parse_constant=_nonfinite)
    if not isinstance(result, dict):
        raise InputFileError("The JSON root must be an object")
    return result


def json_default(value: Any) -> str:
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise InputFileError("Cannot serialize a nonfinite Decimal")
        return format(value, "f")
    if isinstance(value, date):
        return value.isoformat()
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def canonical_json(value: Any) -> str:
    return json.dumps(value, default=json_default, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def fingerprint(value: Any) -> str:
    payload = ENGINE_VERSION + "\n" + canonical_json(value)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_json(path: str | Path, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, default=json_default, indent=2, sort_keys=True,
                                 ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


DEMAND_COLUMNS = (
    "facility_id", "business_key", "family", "quantity", "uom", "status", "priority",
    "release_date", "customer_requested_date", "promised_date", "internal_expected_date", "evidence",
)


def load_demand_csv(path: str | Path) -> list[dict[str, Any]]:
    """Empty optional fields become unknown, never zero; no row is discarded."""
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise InputFileError("Missing or duplicate demand CSV headers")
        if set(reader.fieldnames) != set(DEMAND_COLUMNS):
            raise InputFileError(f"Demand CSV headers must be exactly: {', '.join(DEMAND_COLUMNS)}")
        rows: list[dict[str, Any]] = []
        for line, row in enumerate(reader, 2):
            if None in row or any(value is None for value in row.values()):
                raise InputFileError(f"Demand CSV line {line}: incorrect column count")
            normalized = {key: (value.strip() or None) for key, value in row.items()}
            for key in ("quantity", "priority"):
                value = normalized[key]
                if value is not None:
                    if not value.isdecimal():
                        raise InputFileError(f"Demand CSV line {line}: {key} must be a nonnegative whole integer")
                    normalized[key] = int(value)
            rows.append(normalized)
        return rows


def replace_demands_from_csv(config: dict[str, Any], path: str | Path) -> dict[str, Any]:
    from copy import deepcopy
    updated = deepcopy(config)
    facilities = {f["id"]: f for f in updated.get("facilities", [])}
    rows = load_demand_csv(path)
    for facility in facilities.values():
        facility["demands"] = []
    for row in rows:
        facility_id = row.pop("facility_id")
        if facility_id not in facilities:
            raise InputFileError(f"Unknown CSV facility: {facility_id!r}")
        facilities[facility_id]["demands"].append(row)
    return updated


def safe_csv_cell(value: Any) -> Any:
    """Neutralize spreadsheet formula-like TEXT; actual numeric values remain numeric."""
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        return json_default(value) if isinstance(value, Decimal) else value
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (list, dict)):
        value = canonical_json(value)
    if isinstance(value, str):
        leading = value.lstrip(" ")
        if leading and (leading[0] in "=+-@" or not leading[0].isprintable()):
            return "'" + value
    return value


def export_plan_csv(result: dict[str, Any], directory: str | Path) -> None:
    target = Path(directory)
    target.mkdir(parents=True, exist_ok=True)
    tables = {
        "allocations": ("facility", "business_key", "family", "batch_id", "quantity", "start_date",
                        "modeled_ship_date", "customer_requested_date", "promised_date", "internal_expected_date",
                        "route_version", "requested_late_days", "promised_late_days"),
        "resource_loads": ("facility", "date", "resource", "kind", "unit", "capacity", "load", "slack"),
        "demand_outcomes": ("facility", "business_key", "family", "status", "input_quantity",
                            "allocated_quantity", "unserved_quantity", "modeled_first_ship_date",
                            "modeled_last_ship_date", "reasons"),
        "inventory": ("facility", "date", "stock", "uom", "opening_on_hand", "receipts", "consumed",
                      "ending_on_hand", "protected_stock", "available"),
        "backlog": ("facility", "date", "business_key", "released_quantity", "completed_quantity",
                    "in_plan_wip_quantity", "unstarted_quantity", "open_quantity"),
    }
    for name, columns in tables.items():
        with (target / f"{name}.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
            writer.writeheader()
            for facility in result.get("facilities", []):
                for row in facility.get(name, []):
                    encoded = {key: safe_csv_cell(value) for key, value in row.items()}
                    writer.writerow(encoded)
