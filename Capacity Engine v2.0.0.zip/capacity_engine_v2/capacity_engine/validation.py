"""Strict, collecting validation. Invalid physical inputs never reach allocation."""
from __future__ import annotations

import re
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_FLOOR, localcontext
from typing import Any

from .domain import (
    SCHEMA_VERSION, ENGINE_VERSION, ONE, ZERO, BomLine, DatedQuantity, Demand, Diagnostic,
    Facility, Family, Horizon, LaborPool, MachineDay, MachinePool, QualityGate,
    ResourceLoad, Route, Shift, SpaceDay, SpacePool, SpaceReservation, SpaceUse, Stock,
    ValidationResult, ValueRate, WageRate, days,
)
from .io import canonical_json, fingerprint

DATE_FALLBACK = date(2000, 1, 1)
MATERIAL_UOMS = {"EA", "KG", "LB", "M", "FT", "L", "SQFT"}


class Validator:
    def __init__(self) -> None:
        self.diagnostics: list[Diagnostic] = []
        self.facility: str | None = None
        self.evidence: dict[str, dict[str, Any]] = {}
        self.as_of = DATE_FALLBACK
        self.max_age = 30
        self.stale_action = "block"
        self.physical_owners: dict[str, tuple[str, str]] = {}
        self.workforce_owners: dict[str, tuple[str, str]] = {}
        self.demand_owners: dict[str, str] = {}

    def issue(self, code: str, path: str, message: str, severity: str = "block",
              metric: str | None = None) -> None:
        self.diagnostics.append(Diagnostic(severity, code, path, message, self.facility, metric))

    def obj(self, value: Any, path: str, allowed: set[str] | None = None,
            severity: str = "block") -> dict[str, Any]:
        if not isinstance(value, dict):
            self.issue("MISSING" if value is None else "TYPE", path, "Expected an object; unknown is not zero.", severity)
            return {}
        if allowed is not None:
            for key in sorted(set(value) - allowed):
                self.issue("UNKNOWN_FIELD", f"{path}/{key}", "Unknown field; check spelling and schema.", severity)
        return value

    def arr(self, value: Any, path: str, severity: str = "block") -> list[Any]:
        if not isinstance(value, list):
            self.issue("MISSING" if value is None else "TYPE", path, "Expected an explicit list (empty is allowed where documented).", severity)
            return []
        return value

    def text(self, value: Any, path: str, severity: str = "block") -> str:
        if not isinstance(value, str) or not value.strip() or value != value.strip():
            self.issue("MISSING" if value is None else "TEXT", path, "Expected nonblank text without leading/trailing whitespace.", severity)
            return "<invalid>"
        return value

    def boolean(self, value: Any, path: str, severity: str = "block") -> bool:
        if type(value) is not bool:
            self.issue("MISSING" if value is None else "TYPE", path, "Expected an explicit boolean.", severity)
            return False
        return value

    def enum(self, value: Any, choices: set[str], path: str, severity: str = "block") -> str:
        if not isinstance(value, str) or value not in choices:
            self.issue("MISSING" if value is None else "ENUM", path, f"Expected one of {sorted(choices)}.", severity)
            return "<invalid>"
        return value

    def number(self, value: Any, path: str, *, minimum: Decimal = ZERO,
               maximum: Decimal = Decimal("1000000000000"), integer: bool = False,
               severity: str = "block") -> Decimal:
        if value is None:
            self.issue("MISSING", path, "A validated number is required; unknown is not zero.", severity)
            return ZERO
        if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
            self.issue("NUMBER", path, "Boolean or nonnumeric value is not a number.", severity)
            return ZERO
        try:
            number = Decimal(str(value))
        except InvalidOperation:
            self.issue("NUMBER", path, "Invalid decimal number.", severity)
            return ZERO
        if not number.is_finite() or not minimum <= number <= maximum:
            self.issue("NUMBER_RANGE", path, f"Expected a finite number in [{minimum}, {maximum}].", severity)
            return ZERO
        if integer and number != number.to_integral_value():
            self.issue("WHOLE_NUMBER", path, "Expected a whole integer.", severity)
            return ZERO
        if number.as_tuple().exponent < -12:
            self.issue("NUMERIC_PRECISION", path, "At most 12 fractional decimal places are supported.", severity)
            return ZERO
        return number

    def integer(self, value: Any, path: str, minimum: int = 0, maximum: int = 10**12,
                severity: str = "block") -> int:
        return int(self.number(value, path, minimum=Decimal(minimum), maximum=Decimal(maximum),
                               integer=True, severity=severity))

    def day(self, value: Any, path: str, severity: str = "block") -> date:
        if not isinstance(value, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
            self.issue("MISSING" if value is None else "DATE", path, "Expected an ISO calendar date YYYY-MM-DD.", severity)
            return DATE_FALLBACK
        try:
            parsed = date.fromisoformat(value)
        except ValueError:
            self.issue("DATE", path, "Impossible calendar date.", severity)
            return DATE_FALLBACK
        if not 1900 <= parsed.year <= 2200:
            self.issue("DATE_RANGE", path, "Supported years are 1900 through 2200.", severity)
            return DATE_FALLBACK
        return parsed

    def currency(self, value: Any, path: str) -> str:
        if not isinstance(value, str) or re.fullmatch(r"[A-Z]{3}", value) is None:
            self.issue("CURRENCY", path, "Currency must be a three-letter uppercase currency code.", "financial")
            return "<invalid>"
        return value

    def ref(self, value: Any, path: str, severity: str = "block", metric: str | None = None) -> str:
        key = self.text(value, path, severity)
        evidence = self.evidence.get(key)
        if evidence is None:
            self.issue("UNKNOWN_EVIDENCE", path, f"Unknown evidence reference {key!r}.", severity, metric)
        else:
            if not evidence["approved"]:
                self.issue("UNAPPROVED", path, f"Evidence {key!r} needs an accountable approval.", severity, metric)
            if evidence["age_days"] > self.max_age:
                gate = severity if self.stale_action == "block" else "warning"
                self.issue("STALE_SOURCE", path, f"Evidence {key!r} is {evidence['age_days']} days old; policy is {self.max_age} days.", gate, metric)
        return key

    def unique(self, values: list[str], path: str, severity: str = "block") -> None:
        seen: set[str] = set()
        for value in values:
            if value in seen:
                self.issue("DUPLICATE_KEY", path, f"Duplicate key {value!r}.", severity)
            seen.add(value)

    def physical_owner(self, identity: str, kind: str, resource: str, path: str) -> None:
        old = self.physical_owners.get(identity)
        if old is not None:
            code = "UNSUPPORTED_CROSS_SITE_SHARED_POOL" if old[0] != self.facility else "DUPLICATED_PHYSICAL_POOL"
            self.issue(code, path,
                       f"Physical budget {identity!r} already belongs to {old[0]}/{old[1]}; one facility-owned pool may be referenced by many families. Cross-site pooling is unsupported and blocked.")
            self.diagnostics.append(Diagnostic("block", code, path,
                                               f"Physical budget {identity!r} is duplicated by {self.facility}/{resource}; no cross-site pooled plan is produced.", old[0]))
        else:
            self.physical_owners[identity] = (self.facility or "", resource)

    def interval(self, obj: dict[str, Any], path: str, severity: str = "block") -> tuple[date, date]:
        start = self.day(obj.get("effective_from"), path + "/effective_from", severity)
        end = self.day(obj.get("effective_to"), path + "/effective_to", severity)
        if end < start:
            self.issue("DATE_ORDER", path, "effective_to must be on/after effective_from (both inclusive).", severity)
        return start, end

    def no_overlaps(self, values: list[Any], path: str, severity: str = "block") -> None:
        ordered = sorted(values, key=lambda item: (item.start, item.end))
        for prev, cur in zip(ordered, ordered[1:]):
            if cur.start <= prev.end:
                self.issue("OVERLAPPING_EFFECTIVITY", path,
                           f"Overlapping inclusive effective intervals: {prev.version!r}, {cur.version!r}.", severity)
        self.unique([value.version for value in values], path, severity)

    def calendar_days(self, value: Any, path: str, expected: tuple[date, ...],
                      allowed: set[str]) -> list[tuple[date, dict[str, Any], str]]:
        parsed = []
        observed: list[str] = []
        expected_set = set(expected)
        for i, raw in enumerate(self.arr(value, path)):
            p = f"{path}/{i}"
            item = self.obj(raw, p, allowed | {"date", "evidence"})
            day = self.day(item.get("date"), p + "/date")
            observed.append(day.isoformat())
            if day not in expected_set:
                self.issue("CALENDAR_OUTSIDE_HORIZON", p, "Calendar date is outside the required resource horizon.")
            parsed.append((day, item, p))
        self.unique(observed, path)
        missing = sorted(expected_set - {day for day, _, _ in parsed})
        if missing:
            dates_text = ", ".join(d.isoformat() for d in missing[:8])
            self.issue("MISSING_CALENDAR", path,
                       f"Missing {len(missing)} dated capacity records, including {dates_text}; closed days require explicit zero records.")
        return parsed

    def wage_rates(self, raw: Any, path: str, currency: str) -> tuple[WageRate, ...]:
        before = len(self.diagnostics)
        result = []
        for i, value in enumerate(self.arr(raw, path, "financial")):
            p = f"{path}/{i}"
            item = self.obj(value, p, {"version", "effective_from", "effective_to", "currency", "rate_unit", "base_wage",
                                       "ot_multiplier", "burden_per_paid_hour", "evidence"}, "financial")
            self.enum(item.get("rate_unit"), {"currency_per_paid_person_hour"}, p + "/rate_unit", "financial")
            start, end = self.interval(item, p, "financial")
            curr = self.currency(item.get("currency"), p + "/currency")
            if curr != currency:
                self.issue("INCONSISTENT_CURRENCY", p, "Rate currency differs from the resource's declared currency; no implicit FX.", "financial")
            result.append(WageRate(
                self.text(item.get("version"), p + "/version", "financial"), start, end, curr,
                self.number(item.get("base_wage"), p + "/base_wage", severity="financial"),
                self.number(item.get("ot_multiplier"), p + "/ot_multiplier", minimum=ONE, severity="financial"),
                self.number(item.get("burden_per_paid_hour"), p + "/burden_per_paid_hour", severity="financial"),
                self.ref(item.get("evidence"), p + "/evidence", "financial")))
        self.no_overlaps(result, path, "financial")
        return () if any(d.severity == "financial" for d in self.diagnostics[before:]) else tuple(result)

    def value_rates(self, raw: Any, path: str, currency: str, rate_unit: str) -> tuple[ValueRate, ...]:
        before = len(self.diagnostics)
        result = []
        for i, value in enumerate(self.arr(raw, path, "financial")):
            p = f"{path}/{i}"
            item = self.obj(value, p, {"version", "effective_from", "effective_to", "currency", "rate_unit", "amount", "evidence"}, "financial")
            self.enum(item.get("rate_unit"), {rate_unit}, p + "/rate_unit", "financial")
            start, end = self.interval(item, p, "financial")
            curr = self.currency(item.get("currency"), p + "/currency")
            if curr != currency:
                self.issue("INCONSISTENT_CURRENCY", p, "Rate currency differs from the declared currency; use separate currency buckets.", "financial")
            result.append(ValueRate(self.text(item.get("version"), p + "/version", "financial"), start, end, curr,
                                    self.number(item.get("amount"), p + "/amount", severity="financial"),
                                    self.ref(item.get("evidence"), p + "/evidence", "financial")))
        self.no_overlaps(result, path, "financial")
        return () if any(d.severity == "financial" for d in self.diagnostics[before:]) else tuple(result)

    def labor_pool(self, raw: Any, path: str, horizon: Horizon) -> LaborPool:
        item = self.obj(raw, path, {"id", "physical_pool", "crew_size", "max_concurrent_crews", "currency", "calendar", "rates", "evidence"})
        key = self.text(item.get("id"), path + "/id")
        physical = self.text(item.get("physical_pool"), path + "/physical_pool")
        self.physical_owner(physical, "labor", key, path)
        crew = self.integer(item.get("crew_size"), path + "/crew_size", minimum=1)
        concurrent = self.integer(item.get("max_concurrent_crews"), path + "/max_concurrent_crews")
        currency = self.currency(item.get("currency"), path + "/currency")
        shifts: list[Shift] = []
        for day, rec, p in self.calendar_days(item.get("calendar"), path + "/calendar", horizon.planning_days, {"shifts"}):
            self.ref(rec.get("evidence"), p + "/evidence")
            daily = []
            for i, raw_shift in enumerate(self.arr(rec.get("shifts"), p + "/shifts")):
                q = f"{p}/shifts/{i}"
                s = self.obj(raw_shift, q, {"id", "workforce", "start_hour", "qualified_headcount", "attendance",
                    "regular_paid_hours", "ot_paid_hours", "productive_fraction", "reserved_regular_hours", "reserved_ot_hours", "evidence"})
                workforce = self.text(s.get("workforce"), q + "/workforce")
                owner = self.workforce_owners.get(workforce)
                if owner is not None and owner != (self.facility, key):
                    self.issue("SHARED_WORKFORCE_DUPLICATED", q, f"Workforce {workforce!r} already belongs to {owner}; use a single shared labor pool.")
                    self.diagnostics.append(Diagnostic("block", "SHARED_WORKFORCE_DUPLICATED", q,
                        "Workforce also assigned to another pool/facility.", owner[0]))
                else:
                    self.workforce_owners[workforce] = (self.facility or "", key)
                shift = Shift(
                    self.text(s.get("id"), q + "/id"), day, workforce,
                    self.number(s.get("start_hour"), q + "/start_hour", maximum=Decimal(24)),
                    self.integer(s.get("qualified_headcount"), q + "/qualified_headcount"),
                    self.number(s.get("attendance"), q + "/attendance", maximum=ONE),
                    self.number(s.get("regular_paid_hours"), q + "/regular_paid_hours", maximum=Decimal(24)),
                    self.number(s.get("ot_paid_hours"), q + "/ot_paid_hours", maximum=Decimal(24)),
                    self.number(s.get("productive_fraction"), q + "/productive_fraction", maximum=ONE),
                    self.number(s.get("reserved_regular_hours"), q + "/reserved_regular_hours"),
                    self.number(s.get("reserved_ot_hours"), q + "/reserved_ot_hours"),
                    self.ref(s.get("evidence"), q + "/evidence"))
                if shift.start_hour + shift.regular_paid_hours + shift.ot_paid_hours > 24:
                    self.issue("SHIFT_CROSSES_DAY", q, "A shift must fit one calendar day; split overnight shifts explicitly.")
                crews = min(int((Decimal(shift.qualified_headcount) * shift.attendance / max(crew, 1)).to_integral_value(rounding=ROUND_FLOOR)), concurrent)
                reg = crews * crew * shift.regular_paid_hours * shift.productive_fraction
                ot = crews * crew * shift.ot_paid_hours * shift.productive_fraction
                if shift.reserved_regular_hours > reg or shift.reserved_ot_hours > ot:
                    self.issue("OVER_RESERVED", q, "External productive-hour reservations exceed whole-crew productive capacity.")
                daily.append(shift)
            self.unique([s.id for s in daily], p + "/shifts")
            ordered = sorted(daily, key=lambda s: s.start_hour)
            for prev, cur in zip(ordered, ordered[1:]):
                if prev.start_hour + prev.regular_paid_hours + prev.ot_paid_hours > cur.start_hour:
                    self.issue("OVERLAPPING_SHIFTS", p, "Overlapping shifts within a pool are unsupported; use disjoint shifts, not duplicated concurrency.")
            shifts.extend(daily)
        rates = self.wage_rates(item.get("rates"), path + "/rates", currency)
        for shift in shifts:
            if shift.qualified_headcount * shift.attendance * (shift.regular_paid_hours + shift.ot_paid_hours) > 0:
                if not any(r.start <= shift.day <= r.end for r in rates):
                    self.issue("MISSING_WAGE_RATE", path + "/rates", f"No validated wage/OT/burden rate for staffed date {shift.day}.", "financial", "staffed_payroll")
        return LaborPool(key, physical, crew, concurrent, currency, tuple(shifts), rates,
                         self.ref(item.get("evidence"), path + "/evidence"))

    def machine_pool(self, raw: Any, path: str, horizon: Horizon) -> MachinePool:
        item = self.obj(raw, path, {"id", "physical_pool", "loss_basis", "calendar", "evidence"})
        key = self.text(item.get("id"), path + "/id")
        physical = self.text(item.get("physical_pool"), path + "/physical_pool")
        self.physical_owner(physical, "machine", key, path)
        self.enum(item.get("loss_basis"), {"availability_performance_only"}, path + "/loss_basis")
        calendar = []
        allowed = {"count", "scheduled_hours", "maintenance_hours", "uptime", "performance", "reserved_hours"}
        for day, rec, p in self.calendar_days(item.get("calendar"), path + "/calendar", horizon.planning_days, allowed):
            cap = MachineDay(day, self.integer(rec.get("count"), p + "/count"),
                self.number(rec.get("scheduled_hours"), p + "/scheduled_hours", maximum=Decimal(24)),
                self.number(rec.get("maintenance_hours"), p + "/maintenance_hours"),
                self.number(rec.get("uptime"), p + "/uptime", maximum=ONE),
                self.number(rec.get("performance"), p + "/performance", maximum=ONE),
                self.number(rec.get("reserved_hours"), p + "/reserved_hours"),
                self.ref(rec.get("evidence"), p + "/evidence"))
            gross = cap.count * cap.scheduled_hours
            if cap.maintenance_hours > gross:
                self.issue("IMPOSSIBLE_MAINTENANCE", p, "Maintenance is total machine-hours and cannot exceed scheduled count × hours.")
            if cap.reserved_hours > max(ZERO, gross - cap.maintenance_hours) * cap.uptime * cap.performance:
                self.issue("OVER_RESERVED", p, "Machine reservations exceed availability/performance-adjusted capacity.")
            calendar.append(cap)
        return MachinePool(key, physical, tuple(calendar), self.ref(item.get("evidence"), path + "/evidence"))

    def space_pool(self, raw: Any, path: str, horizon: Horizon) -> SpacePool:
        item = self.obj(raw, path, {"id", "physical_pool", "currency", "calendar", "psf_rates", "evidence"})
        key = self.text(item.get("id"), path + "/id")
        physical = self.text(item.get("physical_pool"), path + "/physical_pool")
        self.physical_owner(physical, "space", key, path)
        currency = self.currency(item.get("currency"), path + "/currency")
        calendar = []
        for day, rec, p in self.calendar_days(item.get("calendar"), path + "/calendar", horizon.occupied_days,
                                             {"usable_sqft", "max_slots", "reserved_sqft", "reserved_slots"}):
            cap = SpaceDay(day, self.number(rec.get("usable_sqft"), p + "/usable_sqft"),
                self.integer(rec.get("max_slots"), p + "/max_slots"),
                self.number(rec.get("reserved_sqft"), p + "/reserved_sqft"),
                self.integer(rec.get("reserved_slots"), p + "/reserved_slots"),
                self.ref(rec.get("evidence"), p + "/evidence"))
            if cap.reserved_sqft > cap.usable_sqft or cap.reserved_slots > cap.max_slots:
                self.issue("OVER_RESERVED", p, "Space reservations exceed safe area or concurrent slots.")
            if (cap.reserved_slots == 0) != (cap.reserved_sqft == 0):
                self.issue("SPACE_RESERVATION_UNITS", p, "A nonzero reservation needs both occupied area and slots.")
            calendar.append(cap)
        rates = self.value_rates(item.get("psf_rates"), path + "/psf_rates", currency, "currency_per_sqft_day")
        return SpacePool(key, physical, currency, tuple(calendar), rates, self.ref(item.get("evidence"), path + "/evidence"))

    def quantities(self, raw: Any, path: str, snapshot: date, integer: bool = False) -> tuple[DatedQuantity, ...]:
        result = []
        for i, value in enumerate(self.arr(raw, path)):
            p = f"{path}/{i}"
            item = self.obj(value, p, {"id", "date", "quantity", "evidence"})
            day = self.day(item.get("date"), p + "/date")
            if day < snapshot:
                self.issue("RECEIPT_BEFORE_SNAPSHOT", p, "A pre-snapshot receipt/release must already be reconciled into the opening snapshot.")
            result.append(DatedQuantity(self.text(item.get("id"), p + "/id"), day,
                self.number(item.get("quantity"), p + "/quantity", integer=integer),
                self.ref(item.get("evidence"), p + "/evidence")))
        self.unique([r.id for r in result], path)
        return tuple(result)

    def stock(self, raw: Any, path: str, horizon: Horizon) -> Stock:
        item = self.obj(raw, path, {"id", "physical_stock", "part", "uom", "snapshot_date", "on_hand", "allocated", "safety_stock", "receipts", "evidence"})
        key = self.text(item.get("id"), path + "/id")
        physical = self.text(item.get("physical_stock"), path + "/physical_stock")
        self.physical_owner(physical, "stock", key, path)
        snapshot = self.day(item.get("snapshot_date"), path + "/snapshot_date")
        if snapshot != horizon.start:
            self.issue("SNAPSHOT_DATE", path + "/snapshot_date", "An opening material snapshot dated exactly horizon.start is required.")
        on_hand = self.number(item.get("on_hand"), path + "/on_hand")
        allocated = self.number(item.get("allocated"), path + "/allocated")
        safety = self.number(item.get("safety_stock"), path + "/safety_stock")
        if allocated + safety > on_hand:
            self.issue("OVER_RESERVED", path, "Opening allocated + safety stock exceeds on-hand; reconcile the opening stock first.")
        return Stock(key, physical, self.text(item.get("part"), path + "/part"),
            self.enum(item.get("uom"), MATERIAL_UOMS, path + "/uom"), snapshot, on_hand, allocated, safety,
            self.quantities(item.get("receipts"), path + "/receipts", snapshot),
            self.ref(item.get("evidence"), path + "/evidence"))

    def family(self, raw: Any, path: str, horizon: Horizon) -> Family:
        item = self.obj(raw, path, {"id", "uom", "value_currency", "quality", "shipment_values", "evidence"})
        qpath = path + "/quality"
        q = self.obj(item.get("quality"), qpath, {"status", "snapshot_date", "released_units", "releases", "evidence"})
        status = self.enum(q.get("status"), {"required", "not_required"}, qpath + "/status")
        if status == "not_required":
            if any(key in q for key in ("snapshot_date", "released_units", "releases")):
                self.issue("NOT_REQUIRED_HAS_VALUES", qpath, "not_required must not carry an unused quality allowance.")
            quality = QualityGate(status, None, 0, (), self.ref(q.get("evidence"), qpath + "/evidence"))
        else:
            snapshot = self.day(q.get("snapshot_date"), qpath + "/snapshot_date")
            if snapshot != horizon.start:
                self.issue("SNAPSHOT_DATE", qpath, "Quality authorization snapshot must be dated horizon.start.")
            quality = QualityGate(status, snapshot,
                self.integer(q.get("released_units"), qpath + "/released_units"),
                self.quantities(q.get("releases"), qpath + "/releases", snapshot, True),
                self.ref(q.get("evidence"), qpath + "/evidence"))
        currency = self.currency(item.get("value_currency"), path + "/value_currency")
        return Family(self.text(item.get("id"), path + "/id"),
            self.enum(item.get("uom"), {"EA"}, path + "/uom"), currency, quality,
            self.value_rates(item.get("shipment_values"), path + "/shipment_values", currency, "currency_per_EA"),
            self.ref(item.get("evidence"), path + "/evidence"))

    def route(self, raw: Any, path: str, resources: dict[str, Any], stocks: dict[str, Stock],
              families: set[str]) -> Route:
        item = self.obj(raw, path, {"family", "version", "effective_from", "effective_to", "lead_days", "batch_size",
                                  "timing_model", "coverage", "loads", "space", "materials", "evidence"})
        family = self.text(item.get("family"), path + "/family")
        if family not in families:
            self.issue("UNKNOWN_FAMILY", path + "/family", "Route references an unknown family.")
        start, end = self.interval(item, path)
        lead = self.integer(item.get("lead_days"), path + "/lead_days", minimum=1, maximum=366)
        batch = self.integer(item.get("batch_size"), path + "/batch_size", minimum=1)
        self.enum(item.get("timing_model"), {"day_bucket"}, path + "/timing_model")
        coverage_raw = self.obj(item.get("coverage"), path + "/coverage")
        coverage = {}
        for key, value in coverage_raw.items():
            coverage[key] = self.enum(value, {"required", "not_required"}, path + "/coverage/" + key)
        if set(coverage) != set(resources):
            self.issue("INCOMPLETE_RESOURCE_COVERAGE", path + "/coverage",
                       f"Every declared resource needs required/not_required. Missing={sorted(set(resources)-set(coverage))}; unknown={sorted(set(coverage)-set(resources))}.")
        loads = []
        for i, value in enumerate(self.arr(item.get("loads"), path + "/loads")):
            p = f"{path}/loads/{i}"
            r = self.obj(value, p, {"resource", "offset_days", "unit", "first_pass_hours_per_unit", "rework_hours_per_unit", "rework_mode", "setup_hours_per_batch", "required_crew_size"})
            key = self.text(r.get("resource"), p + "/resource")
            resource = resources.get(key)
            if not isinstance(resource, (LaborPool, MachinePool)):
                self.issue("UNKNOWN_RESOURCE", p, "A load must reference a labor or machine resource owned by this facility.")
            offset = self.integer(r.get("offset_days"), p + "/offset_days", maximum=365)
            if offset >= lead:
                self.issue("OPERATION_AFTER_COMPLETION", p, "All operation offsets must be less than lead_days.")
            unit = self.enum(r.get("unit"), {"person_hour", "machine_hour"}, p + "/unit")
            expected = "person_hour" if isinstance(resource, LaborPool) else "machine_hour"
            if unit != expected:
                self.issue("UNIT_MISMATCH", p + "/unit", f"Resource requires {expected}.")
            crew = None
            if isinstance(resource, LaborPool):
                crew = self.integer(r.get("required_crew_size"), p + "/required_crew_size", minimum=1)
                if crew != resource.crew_size:
                    self.issue("HETEROGENEOUS_CREW_UNSUPPORTED", p, "The routing crew size must equal the pool's simultaneous crew size.")
            elif "required_crew_size" in r:
                self.issue("UNEXPECTED_CREW", p, "Only labor loads have required_crew_size.")
            first = self.number(r.get("first_pass_hours_per_unit"), p + "/first_pass_hours_per_unit")
            rework = self.number(r.get("rework_hours_per_unit"), p + "/rework_hours_per_unit")
            mode = self.enum(r.get("rework_mode"), {"separate", "bundled"}, p + "/rework_mode")
            setup = self.number(r.get("setup_hours_per_batch"), p + "/setup_hours_per_batch")
            if mode == "bundled" and rework != 0:
                self.issue("DOUBLE_REWORK", p, "A bundled standard requires incremental rework=0; never deduct or add it twice.")
            if first + rework + setup <= 0:
                self.issue("ZERO_REQUIRED_ROUTE", p, "Required resources need positive variable or setup work; otherwise explicitly mark not_required.")
            loads.append(ResourceLoad(key, offset, unit, first, rework, mode, setup, crew))
        self.unique([f"{load.resource}@{load.offset_days}" for load in loads], path + "/loads")
        spaces = []
        for i, value in enumerate(self.arr(item.get("space"), path + "/space")):
            p = f"{path}/space/{i}"
            s = self.obj(value, p, {"resource", "offset_days", "length_ft", "width_ft", "clearance_ft", "dwell_days"})
            key = self.text(s.get("resource"), p + "/resource")
            if not isinstance(resources.get(key), SpacePool):
                self.issue("UNKNOWN_RESOURCE", p, "Space occupancy must reference a space pool owned by this facility.")
            length = self.number(s.get("length_ft"), p + "/length_ft")
            width = self.number(s.get("width_ft"), p + "/width_ft")
            if length <= 0 or width <= 0:
                self.issue("FOOTPRINT", p, "Required occupancy needs positive length and width, with explicit clearance.")
            offset = self.integer(s.get("offset_days"), p + "/offset_days", maximum=365)
            if offset >= lead:
                self.issue("OCCUPANCY_AFTER_COMPLETION", p, "Occupied space must start before modeled shipment; dwell may extend into the tail.")
            spaces.append(SpaceUse(key, offset, length, width,
                self.number(s.get("clearance_ft"), p + "/clearance_ft"),
                self.integer(s.get("dwell_days"), p + "/dwell_days", minimum=1, maximum=732)))
        self.unique([f"{s.resource}@{s.offset_days}" for s in spaces], path + "/space")
        used = {load.resource for load in loads} | {s.resource for s in spaces}
        for key, state in coverage.items():
            if (state == "required") != (key in used):
                self.issue("ROUTE_COVERAGE_CONTRADICTION", path + "/coverage/" + key,
                           "required needs an explicit load/occupancy; not_required must have no load.")
        for key in used - set(coverage):
            self.issue("MISSING_APPLICABILITY", path, f"Load {key!r} has no explicit applicability entry.")
        m = self.obj(item.get("materials"), path + "/materials", {"status", "bom"})
        mstatus = self.enum(m.get("status"), {"required", "not_required"}, path + "/materials/status")
        bom = []
        for i, value in enumerate(self.arr(m.get("bom"), path + "/materials/bom")):
            p = f"{path}/materials/bom/{i}"
            b = self.obj(value, p, {"stock", "quantity_per_unit", "uom"})
            key = self.text(b.get("stock"), p + "/stock")
            uom = self.enum(b.get("uom"), MATERIAL_UOMS, p + "/uom")
            quantity = self.number(b.get("quantity_per_unit"), p + "/quantity_per_unit")
            if quantity <= 0:
                self.issue("BOM_QUANTITY", p, "A required BOM component needs positive quantity_per_unit.")
            if key not in stocks:
                self.issue("MISSING_MATERIAL_SNAPSHOT", p, "BOM stock has no dated snapshot in this facility.")
            elif stocks[key].uom != uom:
                self.issue("UNIT_MISMATCH", p, "BOM UOM differs from inventory UOM; no implicit conversion.")
            bom.append(BomLine(key, quantity, uom))
        self.unique([b.stock for b in bom], path + "/materials/bom")
        if (mstatus == "required") != bool(bom):
            self.issue("MISSING_BOM", path + "/materials", "required needs a nonempty BOM; not_required needs an explicit empty BOM.")
        return Route(family, self.text(item.get("version"), path + "/version"), start, end,
                     lead, batch, tuple(sorted(coverage.items())), tuple(loads), tuple(spaces), mstatus, tuple(bom),
                     self.ref(item.get("evidence"), path + "/evidence"))

    def demands(self, raw: Any, path: str, families: set[str], due_policy: str) -> tuple[Demand, ...]:
        result = []
        seen: dict[str, str] = {}
        fields = {"business_key", "family", "quantity", "uom", "status", "priority", "release_date",
                  "customer_requested_date", "promised_date", "internal_expected_date", "evidence"}
        for i, value in enumerate(self.arr(raw, path)):
            p = f"{path}/{i}"
            item = self.obj(value, p, fields)
            key = self.text(item.get("business_key"), p + "/business_key")
            signature = {name: item.get(name) for name in fields}
            signature.update(item)
            for number_field in ("quantity", "priority"):
                number_value = signature[number_field]
                if not isinstance(number_value, bool) and isinstance(number_value, (str, int, float, Decimal)):
                    try:
                        parsed_number = Decimal(str(number_value))
                    except InvalidOperation:
                        continue
                    if parsed_number.is_finite() and 0 <= parsed_number <= 10**12 and parsed_number == parsed_number.to_integral_value():
                        signature[number_field] = int(parsed_number)
            try:
                normalized = canonical_json(signature)
            except (TypeError, ValueError):
                self.issue("NON_JSON_INPUT", p, "Demand contains a nonfinite or unsupported JSON value.")
                normalized = repr(item)
            if key in seen:
                if seen[key] == normalized:
                    self.issue("DUPLICATE_DEMAND_COLLAPSED", p, f"Identical release {key!r} counted once.", "warning")
                else:
                    self.issue("CONFLICTING_DEMAND_DUPLICATE", p, f"Release {key!r} has conflicting quantity/UOM/dates/attributes; adjudicate, do not sum.")
                continue
            seen[key] = normalized
            owner = self.demand_owners.get(key)
            if owner is not None and owner != self.facility:
                self.issue("CROSS_SITE_DEMAND_DUPLICATE", p, "Business release already appears in another facility; no implicit split or transfer.")
                self.diagnostics.append(Diagnostic("block", "CROSS_SITE_DEMAND_DUPLICATE", p,
                    "Business release also appears in another facility.", owner))
            self.demand_owners[key] = self.facility or ""
            status = self.enum(item.get("status"), {"open", "closed", "cancelled"}, p + "/status")
            incomplete = []
            family = item.get("family")
            if family is None:
                incomplete.append("family")
            else:
                family = self.text(family, p + "/family")
                if family not in families:
                    self.issue("UNKNOWN_FAMILY", p + "/family", "Demand family is not declared by this facility.")
            quantity = None if item.get("quantity") is None else self.integer(item["quantity"], p + "/quantity")
            if quantity is None:
                incomplete.append("quantity")
            uom = item.get("uom")
            if uom is None:
                incomplete.append("uom")
            else:
                uom = self.enum(uom, {"EA"}, p + "/uom")
            parsed_dates: dict[str, date | None] = {}
            for name in ("release_date", "customer_requested_date", "promised_date", "internal_expected_date"):
                parsed_dates[name] = None if item.get(name) is None else self.day(item[name], p + "/" + name)
            if parsed_dates["release_date"] is None:
                incomplete.append("release_date")
            due = parsed_dates["customer_requested_date"]
            if due_policy == "promised_then_requested":
                due = parsed_dates["promised_date"] or due
            if due is None:
                incomplete.append("customer_requested_date" if due_policy == "customer_requested" else "promised_date_or_customer_requested_date")
            if status != "open":
                incomplete = []
            if incomplete:
                self.issue("INCOMPLETE_DEMAND", p, "Queued, not allocated: " + ", ".join(incomplete), "queue")
            result.append(Demand(key, family, quantity, uom, status,
                self.integer(item.get("priority"), p + "/priority"),
                parsed_dates["release_date"], parsed_dates["customer_requested_date"],
                parsed_dates["promised_date"], parsed_dates["internal_expected_date"], tuple(incomplete),
                self.ref(item.get("evidence"), p + "/evidence")))
        return tuple(result)

    def parse_facility(self, raw: Any, index: int) -> Facility:
        path = f"/facilities/{index}"
        item = self.obj(raw, path, {"id", "name", "horizon", "due_date_policy", "demand_snapshot", "wip",
            "labor", "machines", "space", "stocks", "families", "routes", "demands", "evidence", "open_gaps"})
        key = self.text(item.get("id"), path + "/id")
        self.facility = key
        h = self.obj(item.get("horizon"), path + "/horizon", {"start", "end", "occupancy_end"})
        start = self.day(h.get("start"), path + "/horizon/start")
        end = self.day(h.get("end"), path + "/horizon/end")
        tail = self.day(h.get("occupancy_end"), path + "/horizon/occupancy_end")
        if not (0 <= (end - start).days < 366 and end <= tail and (tail - start).days < 732):
            self.issue("HORIZON_RANGE", path + "/horizon", "Use 1–366 planning days and at most 732 occupied days, with start <= end <= occupancy_end.")
            end = tail = start
        horizon = Horizon(start, end, tail)
        due_policy = self.enum(item.get("due_date_policy"), {"customer_requested", "promised_then_requested"}, path + "/due_date_policy")
        demand_snapshot = self.obj(item.get("demand_snapshot"), path + "/demand_snapshot", {"status", "evidence"})
        self.enum(demand_snapshot.get("status"), {"complete"}, path + "/demand_snapshot/status")
        self.ref(demand_snapshot.get("evidence"), path + "/demand_snapshot/evidence")
        labor = tuple(self.labor_pool(v, f"{path}/labor/{i}", horizon) for i, v in enumerate(self.arr(item.get("labor"), path + "/labor")))
        machines = tuple(self.machine_pool(v, f"{path}/machines/{i}", horizon) for i, v in enumerate(self.arr(item.get("machines"), path + "/machines")))
        spaces = tuple(self.space_pool(v, f"{path}/space/{i}", horizon) for i, v in enumerate(self.arr(item.get("space"), path + "/space")))
        stocks = tuple(self.stock(v, f"{path}/stocks/{i}", horizon) for i, v in enumerate(self.arr(item.get("stocks"), path + "/stocks")))
        families = tuple(self.family(v, f"{path}/families/{i}", horizon) for i, v in enumerate(self.arr(item.get("families"), path + "/families")))
        self.unique([r.id for r in (*labor, *machines, *spaces)], path + "/resources")
        self.unique([s.id for s in stocks], path + "/stocks")
        self.unique([f.id for f in families], path + "/families")
        if not families:
            self.issue("MISSING_FAMILIES", path + "/families", "Declare at least one approved family with routing and quality applicability.")
        resources = {r.id: r for r in (*labor, *machines, *spaces)}
        stock_map = {s.id: s for s in stocks}
        family_ids = {f.id for f in families}
        routes = tuple(self.route(v, f"{path}/routes/{i}", resources, stock_map, family_ids)
                       for i, v in enumerate(self.arr(item.get("routes"), path + "/routes")))
        for family in families:
            related = [r for r in routes if r.family == family.id]
            self.no_overlaps(related, path + "/routes")
            missing = [day for day in horizon.planning_days if not any(r.start <= day <= r.end for r in related)]
            if missing:
                self.issue("MISSING_ROUTE", path + "/routes", f"Family {family.id!r} lacks an approved effective route on {len(missing)} dates, starting {missing[0]}.")
            if not family.values:
                self.issue("MISSING_SHIPMENT_VALUE", path + "/families", f"Family {family.id!r} has no validated shipment unit value; physical units remain evaluable.", "financial", "shipment_value")
        w = self.obj(item.get("wip"), path + "/wip", {"state", "reservations", "evidence"})
        state = self.enum(w.get("state"), {"confirmed_none", "external_reservations_only", "active_model_wip", "unknown"}, path + "/wip/state")
        if state in {"active_model_wip", "unknown"}:
            self.issue("WIP_NOT_MODELED", path + "/wip/state", "Active modeled WIP/unknown WIP is unsupported. Supply a reconciled no-WIP snapshot or external-only reservations; do not assume zero.")
        self.ref(w.get("evidence"), path + "/wip/evidence")
        reservations = []
        for i, value in enumerate(self.arr(w.get("reservations"), path + "/wip/reservations")):
            p = f"{path}/wip/reservations/{i}"
            r = self.obj(value, p, {"id", "resource", "from", "through", "sqft", "slots", "evidence"})
            resource = self.text(r.get("resource"), p + "/resource")
            if not isinstance(resources.get(resource), SpacePool):
                self.issue("UNKNOWN_RESOURCE", p, "External occupancy must reference a facility space pool.")
            begin = self.day(r.get("from"), p + "/from")
            finish = self.day(r.get("through"), p + "/through")
            if finish < begin or finish < start or begin > tail:
                self.issue("RESERVATION_DATES", p, "Reservation must be ordered and intersect the occupied horizon.")
            sqft = self.number(r.get("sqft"), p + "/sqft")
            slots = self.integer(r.get("slots"), p + "/slots", minimum=1)
            if sqft <= 0:
                self.issue("FOOTPRINT", p, "Nonempty reservations need positive area.")
            reservations.append(SpaceReservation(self.text(r.get("id"), p + "/id"), resource,
                begin, finish, sqft, slots, self.ref(r.get("evidence"), p + "/evidence")))
        self.unique([r.id for r in reservations], path + "/wip/reservations")
        if (state == "confirmed_none" and reservations) or (state == "external_reservations_only" and not reservations):
            self.issue("WIP_CONTRADICTION", path + "/wip", "WIP state contradicts its explicit external occupancy reservations.")
        for space in spaces:
            for day in space.calendar:
                used_area = day.reserved_sqft + sum((r.sqft for r in reservations if r.resource == space.id and r.start <= day.day <= r.end), ZERO)
                used_slots = day.reserved_slots + sum(r.slots for r in reservations if r.resource == space.id and r.start <= day.day <= r.end)
                if used_area > day.usable_sqft or used_slots > day.max_slots:
                    self.issue("OVER_RESERVED", path + "/wip", f"Combined calendar/WIP reservations exceed {space.id} on {day.day}.")
        for i, gap in enumerate(self.arr(item.get("open_gaps", []), path + "/open_gaps")):
            self.issue("DECLARED_MISSING_INPUT", f"{path}/open_gaps/{i}", self.text(gap, f"{path}/open_gaps/{i}"))
        demands = self.demands(item.get("demands"), path + "/demands", family_ids, due_policy)
        return Facility(key, self.text(item.get("name"), path + "/name"), horizon, due_policy,
                        labor, machines, spaces, stocks, families, routes, demands, tuple(reservations),
                        self.ref(item.get("evidence"), path + "/evidence"))

    def parse(self, raw: Any) -> ValidationResult:
        root = self.obj(raw, "", {"schema_version", "metadata", "as_of", "synthetic", "freshness_policy", "evidence", "facilities", "scenario", "shared_pools"})
        if "shared_pools" in root:
            self.issue("UNSUPPORTED_CROSS_SITE_SHARED_POOL", "/shared_pools", "Root/cross-site shared-pool planning is unimplemented and blocked. Same-facility families must reference one facility resource ledger; do not duplicate its budget.")
        self.enum(root.get("schema_version"), {SCHEMA_VERSION}, "/schema_version")
        self.as_of = self.day(root.get("as_of"), "/as_of")
        self.boolean(root.get("synthetic"), "/synthetic")
        m = self.obj(root.get("metadata"), "/metadata", {"version", "source", "approved", "approved_by", "approved_on"})
        for key in ("version", "source"):
            self.text(m.get(key), "/metadata/" + key)
        approved = self.boolean(m.get("approved"), "/metadata/approved")
        if not approved:
            self.issue("UNAPPROVED_CONFIGURATION", "/metadata/approved", "Operating configuration needs explicit validation-owner approval.")
        else:
            self.text(m.get("approved_by"), "/metadata/approved_by")
            approved_on = self.day(m.get("approved_on"), "/metadata/approved_on")
            if approved_on > self.as_of:
                self.issue("FUTURE_APPROVAL", "/metadata/approved_on", "Approval cannot be later than as_of.")
        policy = self.obj(root.get("freshness_policy"), "/freshness_policy", {"max_age_days", "on_stale"})
        self.max_age = self.integer(policy.get("max_age_days"), "/freshness_policy/max_age_days", maximum=36500)
        self.stale_action = self.enum(policy.get("on_stale"), {"block", "warn"}, "/freshness_policy/on_stale")
        evidence_keys = []
        for i, raw_evidence in enumerate(self.arr(root.get("evidence"), "/evidence")):
            p = f"/evidence/{i}"
            e = self.obj(raw_evidence, p, {"id", "version", "source", "as_of", "approved", "approved_by"})
            key = self.text(e.get("id"), p + "/id")
            evidence_keys.append(key)
            source_date = self.day(e.get("as_of"), p + "/as_of")
            if source_date > self.as_of:
                self.issue("FUTURE_SOURCE", p + "/as_of", "Source evidence cannot be future-dated relative to as_of.")
            approved_e = self.boolean(e.get("approved"), p + "/approved")
            approver = self.text(e.get("approved_by"), p + "/approved_by") if approved_e else None
            self.evidence[key] = {"id": key, "version": self.text(e.get("version"), p + "/version"),
                "source": self.text(e.get("source"), p + "/source"), "as_of": source_date.isoformat(),
                "age_days": (self.as_of-source_date).days, "approved": approved_e, "approved_by": approver}
        self.unique(evidence_keys, "/evidence")
        facilities = []
        for i, item in enumerate(self.arr(root.get("facilities"), "/facilities")):
            self.facility = item.get("id") if isinstance(item, dict) and isinstance(item.get("id"), str) else f"invalid-{i}"
            facilities.append(self.parse_facility(item, i))
        self.facility = None
        ids = [facility.id for facility in facilities]
        self.unique(ids, "/facilities")
        if not facilities:
            self.issue("MISSING_FACILITIES", "/facilities", "At least one explicit facility is required.")
        try:
            run_hash = fingerprint(raw)
        except (TypeError, ValueError):
            run_hash = fingerprint({"invalid_unserializable_input": True})
            self.issue("NON_JSON_INPUT", "", "Input contains values outside the finite JSON data model.")
        provenance = {"engine_version": ENGINE_VERSION, "schema_version": SCHEMA_VERSION,
            "configuration_version": m.get("version"), "configuration_source": m.get("source"),
            "as_of": self.as_of.isoformat(), "synthetic": root.get("synthetic"),
            "freshness_policy": policy, "evidence": list(self.evidence.values()),
            "scenario": root.get("scenario"),
            "approval_notice": "Metadata flags document asserted approvals; they are NOT authentication, authorization, or RBAC."}
        return ValidationResult(tuple(facilities), tuple(ids), tuple(self.diagnostics), provenance, run_hash)


def validate_config(raw: dict[str, Any]) -> ValidationResult:
    """Collect validation errors without mutating input; independent facilities remain isolated."""
    with localcontext() as context:
        context.prec = 50
        return Validator().parse(raw)
