"""Deterministic priority/earliest-due, earliest-start day-bucket rough-cut planning."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal, ROUND_FLOOR, localcontext
from typing import Any

from .domain import Facility, Route, ValidationResult, ZERO, days, thaw_tree
from .finance import calculate_financials
from .validation import validate_config

METHOD = "day-bucket greedy: ascending explicit priority, then due date, then business key; earliest start; whole units"


class Ledger:
    def __init__(self, facility: Facility) -> None:
        self.facility = facility
        self.capacity: dict[tuple[str, date, str], Decimal] = {}
        self.load: dict[tuple[str, date, str], Decimal] = defaultdict(Decimal)
        self.details: dict[tuple[str, date, str], dict[str, Any]] = {}
        self.labor_usage: list[dict[str, Any]] = []
        self.material_used: dict[str, Decimal] = defaultdict(Decimal)
        self.material_by_day: dict[tuple[str, date], Decimal] = defaultdict(Decimal)
        self.quality_used: dict[str, Decimal] = defaultdict(Decimal)
        self.quality_by_day: dict[tuple[str, date], Decimal] = defaultdict(Decimal)
        for pool in facility.labor:
            for day in facility.horizon.planning_days:
                key = (pool.id, day, "labor")
                self.capacity[key] = ZERO
                self.details[key] = {"gross_productive_hours": ZERO, "reserved_hours": ZERO,
                                     "regular_capacity": ZERO, "ot_capacity": ZERO}
            for shift in sorted(pool.shifts, key=lambda s: (s.day, s.start_hour, s.id)):
                expected_people = Decimal(shift.qualified_headcount) * shift.attendance
                crews = min(int((expected_people / pool.crew_size).to_integral_value(rounding=ROUND_FLOOR)), pool.max_concurrent_crews)
                regular_gross = crews * pool.crew_size * shift.regular_paid_hours * shift.productive_fraction
                ot_gross = crews * pool.crew_size * shift.ot_paid_hours * shift.productive_fraction
                regular = regular_gross - shift.reserved_regular_hours
                ot = ot_gross - shift.reserved_ot_hours
                key = (pool.id, shift.day, "labor")
                self.capacity[key] += regular + ot
                details = self.details[key]
                details["gross_productive_hours"] += regular_gross + ot_gross
                details["reserved_hours"] += shift.reserved_regular_hours + shift.reserved_ot_hours
                details["regular_capacity"] += regular
                details["ot_capacity"] += ot
                self.labor_usage.append({"facility": facility.id, "resource": pool.id, "date": shift.day,
                    "shift": shift.id, "workforce": shift.workforce, "whole_crews": crews,
                    "required_crew_size": pool.crew_size, "qualified_headcount": shift.qualified_headcount,
                    "expected_attended_headcount": expected_people, "productive_fraction": shift.productive_fraction,
                    "regular_capacity": regular, "ot_capacity": ot,
                    "expected_paid_regular_hours": expected_people * shift.regular_paid_hours,
                    "expected_paid_ot_hours": expected_people * shift.ot_paid_hours,
                    "allocated_regular_hours": ZERO, "allocated_ot_hours": ZERO})
        for pool in facility.machines:
            for day in pool.calendar:
                gross = day.count * day.scheduled_hours
                adjusted = (gross - day.maintenance_hours) * day.uptime * day.performance
                key = (pool.id, day.day, "machine")
                self.capacity[key] = adjusted - day.reserved_hours
                self.details[key] = {"count": day.count, "scheduled_hours_per_machine": day.scheduled_hours,
                    "gross_machine_hours": gross, "maintenance_hours": day.maintenance_hours,
                    "uptime": day.uptime, "performance": day.performance, "reserved_hours": day.reserved_hours}
        for pool in facility.space:
            for day in pool.calendar:
                reserved_area = day.reserved_sqft + sum((r.sqft for r in facility.reservations
                    if r.resource == pool.id and r.start <= day.day <= r.end), ZERO)
                reserved_slots = day.reserved_slots + sum(r.slots for r in facility.reservations
                    if r.resource == pool.id and r.start <= day.day <= r.end)
                area_key = (pool.id, day.day, "space_area")
                slot_key = (pool.id, day.day, "space_slots")
                self.capacity[area_key] = day.usable_sqft - reserved_area
                self.capacity[slot_key] = Decimal(day.max_slots - reserved_slots)
                self.details[area_key] = {"gross_safe_capacity": day.usable_sqft, "reserved": reserved_area}
                self.details[slot_key] = {"gross_safe_capacity": day.max_slots, "reserved": reserved_slots}

    def material_available(self, stock_id: str, day: date) -> Decimal:
        stock = next(s for s in self.facility.stocks if s.id == stock_id)
        receipts = sum((receipt.quantity for receipt in stock.receipts if receipt.day <= day), ZERO)
        return stock.on_hand + receipts - stock.allocated - stock.safety_stock - self.material_used[stock_id]

    def quality_available(self, family_id: str, day: date) -> Decimal:
        quality = next(f.quality for f in self.facility.families if f.id == family_id)
        return Decimal(quality.released_units) + sum((r.quantity for r in quality.releases if r.day <= day), ZERO) - self.quality_used[family_id]

    def requirements(self, route: Route, start: date, quantity: int) -> dict[tuple[str, date, str], Decimal]:
        result: dict[tuple[str, date, str], Decimal] = defaultdict(Decimal)
        batches = (quantity + route.batch_size - 1) // route.batch_size
        for load in route.loads:
            day = start + timedelta(days=load.offset_days)
            kind = "labor" if load.unit == "person_hour" else "machine"
            result[(load.resource, day, kind)] += quantity * load.per_unit + batches * load.setup
        for space in route.space:
            begin = start + timedelta(days=space.offset_days)
            for day in days(begin, begin + timedelta(days=space.dwell_days-1)):
                result[(space.resource, day, "space_area")] += quantity * space.footprint
                result[(space.resource, day, "space_slots")] += Decimal(quantity)
        return dict(result)

    def failures(self, route: Route, start: date, quantity: int) -> list[dict[str, Any]]:
        failures: list[dict[str, Any]] = []
        ship = start + timedelta(days=route.lead_days)
        if ship > self.facility.horizon.end:
            return [{"code": "COMPLETION_OUTSIDE_HORIZON", "date": start, "modeled_ship_date": ship,
                     "message": "No partial production is credited beyond the validated shipment horizon."}]
        requirements = self.requirements(route, start, quantity)
        for key, needed in sorted(requirements.items()):
            resource, day, kind = key
            if key not in self.capacity:
                failures.append({"code": "UNSUPPORTED_OCCUPIED_TAIL" if kind.startswith("space_") else "RESOURCE_OUTSIDE_HORIZON",
                    "resource": resource, "date": day, "needed": needed,
                    "message": "Extend the dated capacity/occupancy horizon before starting this work."})
                continue
            available = self.capacity[key] - self.load[key]
            if needed > available:
                failures.append({"code": kind.upper() + "_CAPACITY", "resource": resource, "date": day,
                    "needed": needed, "available": available, "shortfall": needed - available,
                    "unit": {"labor": "person_hour", "machine": "machine_hour", "space_area": "sqft", "space_slots": "slot"}[kind]})
        for line in route.bom:
            needed = quantity * line.quantity
            available = self.material_available(line.stock, start)
            if needed > available:
                stock = next(s for s in self.facility.stocks if s.id == line.stock)
                future = sorted(r.day for r in stock.receipts if r.day > start and r.quantity > 0)
                failures.append({"code": "MATERIAL", "resource": line.stock, "date": start,
                    "needed": needed, "available": available, "shortfall": needed - available,
                    "unit": line.uom, "next_positive_receipt_date": future[0] if future else None})
        quality = next(f.quality for f in self.facility.families if f.id == route.family)
        if quality.status == "required":
            available = self.quality_available(route.family, start)
            if quantity > available:
                failures.append({"code": "QUALITY_RELEASE", "resource": route.family, "date": start,
                    "needed": quantity, "available": available, "shortfall": Decimal(quantity) - available, "unit": "EA"})
        return failures

    def commit(self, route: Route, start: date, quantity: int) -> None:
        for key, needed in self.requirements(route, start, quantity).items():
            self.load[key] += needed
            if key[2] == "labor":
                remaining = needed
                candidates = [r for r in self.labor_usage if r["resource"] == key[0] and r["date"] == key[1]]
                for mode in ("regular", "ot"):
                    for row in candidates:
                        available = row[mode + "_capacity"] - row["allocated_" + mode + "_hours"]
                        used = min(available, remaining)
                        row["allocated_" + mode + "_hours"] += used
                        remaining -= used
                if remaining != 0:
                    raise AssertionError("Internal labor ledger failed conservation")
        for line in route.bom:
            self.material_used[line.stock] += quantity * line.quantity
            self.material_by_day[(line.stock, start)] += quantity * line.quantity
        quality = next(f.quality for f in self.facility.families if f.id == route.family)
        if quality.status == "required":
            self.quality_used[route.family] += Decimal(quantity)
            self.quality_by_day[(route.family, start)] += Decimal(quantity)

    def resource_rows(self) -> list[dict[str, Any]]:
        units = {"labor": "person_hour", "machine": "machine_hour", "space_area": "sqft", "space_slots": "slot"}
        result = []
        for key, capacity in sorted(self.capacity.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
            resource, day, kind = key
            used = self.load[key]
            if not ZERO <= used <= capacity:
                raise AssertionError("Internal resource capacity conservation failed")
            result.append({"facility": self.facility.id, "date": day, "resource": resource, "kind": kind,
                "unit": units[kind], "capacity": capacity, "load": used, "slack": capacity - used,
                **self.details[key]})
        return result

    def inventory_rows(self) -> list[dict[str, Any]]:
        result = []
        for stock in sorted(self.facility.stocks, key=lambda s: s.id):
            on_hand = stock.on_hand
            for day in self.facility.horizon.planning_days:
                opening = on_hand
                receipts = sum((r.quantity for r in stock.receipts if r.day == day), ZERO)
                consumed = self.material_by_day[(stock.id, day)]
                on_hand += receipts - consumed
                protected = stock.allocated + stock.safety_stock
                if on_hand < protected:
                    raise AssertionError("Internal inventory conservation failed")
                result.append({"facility": self.facility.id, "date": day, "stock": stock.id, "uom": stock.uom,
                    "opening_on_hand": opening, "receipts": receipts, "consumed": consumed,
                    "ending_on_hand": on_hand, "protected_stock": protected, "available": on_hand - protected})
        return result

    def quality_rows(self) -> list[dict[str, Any]]:
        result = []
        for family in self.facility.families:
            gate = family.quality
            if gate.status != "required":
                continue
            available = Decimal(gate.released_units)
            for day in self.facility.horizon.planning_days:
                releases = sum((r.quantity for r in gate.releases if r.day == day), ZERO)
                used = self.quality_by_day[(family.id, day)]
                available += releases - used
                if available < 0:
                    raise AssertionError("Internal quality allowance conservation failed")
                result.append({"facility": self.facility.id, "family": family.id, "date": day,
                               "released": releases, "used": used, "remaining": available})
        return result


def _due(facility: Facility, demand: Any) -> date | None:
    if facility.due_policy == "promised_then_requested":
        return demand.promised_date or demand.customer_requested_date
    return demand.customer_requested_date


def _plan_facility(facility: Facility) -> dict[str, Any]:
    ledger = Ledger(facility)
    eligible = [d for d in facility.demands if d.status == "open" and not d.incomplete_fields and d.quantity]
    eligible.sort(key=lambda d: (d.priority, _due(facility, d), d.business_key))
    remaining = {d.business_key: d.quantity for d in eligible}
    allocations = []
    attempts = []
    for start in facility.horizon.planning_days:
        for demand in eligible:
            outstanding = remaining[demand.business_key]
            if outstanding == 0 or demand.release_date > start:
                continue
            routes = [r for r in facility.routes if r.family == demand.family and r.start <= start <= r.end]
            if len(routes) != 1:
                raise AssertionError("Validated route coverage violated")
            route = routes[0]
            low, high = 0, outstanding
            while low < high:
                middle = (low + high + 1) // 2
                if not ledger.failures(route, start, middle):
                    low = middle
                else:
                    high = middle - 1
            quantity = low
            if quantity < outstanding:
                failed = ledger.failures(route, start, quantity + 1)
                attempts.append({"facility": facility.id, "business_key": demand.business_key,
                    "start_date": start, "allocated_at_this_start": quantity,
                    "tested_quantity": quantity + 1, "constraints": failed,
                    "interpretation": "Shortfalls to add one whole unit to this release/date lot before its allocation. All listed gates must be satisfied; not a marginal throughput promise."})
            if quantity:
                ledger.commit(route, start, quantity)
                remaining[demand.business_key] -= quantity
                ship = start + timedelta(days=route.lead_days)
                allocations.append({"facility": facility.id, "business_key": demand.business_key,
                    "family": demand.family, "batch_id": f"{facility.id}:{demand.business_key}:{start.isoformat()}",
                    "quantity": quantity, "batch_count": (quantity + route.batch_size - 1) // route.batch_size,
                    "start_date": start, "modeled_ship_date": ship,
                    "customer_requested_date": demand.customer_requested_date, "promised_date": demand.promised_date,
                    "internal_expected_date": demand.internal_expected_date, "release_date": demand.release_date,
                    "priority": demand.priority, "due_date_used": _due(facility, demand),
                    "route_version": route.version, "route_evidence": route.evidence,
                    "requested_late_days": None if demand.customer_requested_date is None else max(0, (ship-demand.customer_requested_date).days),
                    "promised_late_days": None if demand.promised_date is None else max(0, (ship-demand.promised_date).days)})
    outcomes = []
    backlog = []
    for demand in sorted(facility.demands, key=lambda d: d.business_key):
        related = [a for a in allocations if a["business_key"] == demand.business_key]
        allocated = sum(a["quantity"] for a in related)
        unserved = None if demand.quantity is None else demand.quantity - allocated
        reasons: list[Any] = []
        if demand.status != "open":
            status = "Excluded"
            unserved = 0
            reasons = ["RELEASE_" + demand.status.upper()]
        elif demand.incomplete_fields:
            status = "Queued incomplete"
            reasons = [{"code": "INCOMPLETE_DEMAND", "fields": list(demand.incomplete_fields)}]
        elif demand.quantity == 0:
            status = "No demand"
        elif allocated == demand.quantity:
            status = "Planned"
        else:
            status = "Partially planned" if allocated else "Unplanned"
            relevant = [a for a in attempts if a["business_key"] == demand.business_key]
            if demand.release_date > facility.horizon.end:
                reasons = [{"code": "RELEASE_OUTSIDE_HORIZON", "release_date": demand.release_date}]
            else:
                codes = sorted({c["code"] for a in relevant for c in a["constraints"]})
                reasons = [{"code": code} for code in codes]
        outcomes.append({"facility": facility.id, "business_key": demand.business_key, "family": demand.family,
            "status": status, "input_quantity": demand.quantity, "allocated_quantity": allocated,
            "unserved_quantity": unserved, "release_date": demand.release_date,
            "customer_requested_date": demand.customer_requested_date, "promised_date": demand.promised_date,
            "internal_expected_date": demand.internal_expected_date,
            "modeled_first_ship_date": min((a["modeled_ship_date"] for a in related), default=None),
            "modeled_last_ship_date": max((a["modeled_ship_date"] for a in related), default=None),
            "earliest_date_scope": "First feasible allocation under this greedy priority plan, not an unconstrained/optimal promise.",
            "reasons": reasons})
        if demand in eligible:
            for day in facility.horizon.planning_days:
                released = demand.quantity if demand.release_date <= day else 0
                started = sum(a["quantity"] for a in related if a["start_date"] <= day)
                completed = sum(a["quantity"] for a in related if a["modeled_ship_date"] <= day)
                if not 0 <= completed <= started <= released:
                    raise AssertionError("Internal demand conservation failed")
                backlog.append({"facility": facility.id, "date": day, "business_key": demand.business_key,
                    "released_quantity": released, "completed_quantity": completed,
                    "in_plan_wip_quantity": started - completed, "unstarted_quantity": released - started,
                    "open_quantity": released - completed})
    rows = ledger.resource_rows()
    financials = calculate_financials(facility, allocations, ledger.labor_usage, rows)
    queued = any(d.status == "open" and d.incomplete_fields for d in facility.demands)
    status = "Blocked" if queued else "Ready" if eligible else "No demand"
    return {"id": facility.id, "name": facility.name, "status": status,
        "partial_plan": queued and bool(allocations), "method": METHOD,
        "horizon": {"start": facility.horizon.start, "end": facility.horizon.end, "occupancy_end": facility.horizon.occupancy_end},
        "summary": {"allocated_units": sum(a["quantity"] for a in allocations),
                    "unserved_known_units": sum(o["unserved_quantity"] or 0 for o in outcomes),
                    "incomplete_release_count": sum(d.status == "open" and bool(d.incomplete_fields) for d in facility.demands),
                    "backlog_at_horizon_end": sum(b["open_quantity"] for b in backlog if b["date"] == facility.horizon.end),
                    "future_unreleased_units": sum(d.quantity for d in eligible if d.release_date > facility.horizon.end)},
        "allocations": allocations, "demand_outcomes": outcomes, "backlog": backlog,
        "resource_loads": rows, "labor_usage": ledger.labor_usage,
        "inventory": ledger.inventory_rows(), "quality": ledger.quality_rows(),
        "one_extra_unit_tests": attempts, "financials": financials,
        "assumption_versions": [{"family": r.family, "route_version": r.version, "evidence": r.evidence,
                                  "effective_from": r.start, "effective_to": r.end} for r in facility.routes]}


def plan(raw: dict[str, Any] | ValidationResult) -> dict[str, Any]:
    """Pure calculation: no mutation, file writes, network, ERP access or Office edits."""
    with localcontext() as context:
        context.prec = 50
        validation = raw if isinstance(raw, ValidationResult) else validate_config(raw)
        results = []
        for facility in validation.facilities:
            if validation.blocked_for(facility.id):
                results.append({"id": facility.id, "name": facility.name, "status": "Blocked", "partial_plan": False,
                    "summary": {"allocated_units": None, "message": "Unknown physical feasibility; missing inputs are not a zero-unit forecast."},
                    "allocations": [], "resource_loads": [], "inventory": [], "backlog": [],
                    "demand_outcomes": [{"facility": facility.id, "business_key": d.business_key,
                        "family": d.family, "status": "Blocked by configuration", "input_quantity": d.quantity,
                        "allocated_quantity": None, "unserved_quantity": d.quantity,
                        "reasons": ["PHYSICAL_INPUT_VALIDATION"]} for d in facility.demands],
                    "financials": {"status": "Blocked", "reason": "Physical inputs not evaluable."}})
            else:
                results.append(_plan_facility(facility))
        status = "Blocked" if validation.physical_blocked or any(r["status"] == "Blocked" for r in results) else (
            "No demand" if results and all(r["status"] == "No demand" for r in results) else "Ready")
        return {"status": status, "method": METHOD, "run_hash": validation.run_hash,
                "physical_scope": "Independent facility day-bucket rough-cut feasibility; not finite/optimal APS or a committed forecast.",
                "financial_status": "Blocked" if status == "Blocked" or any(r["financials"]["status"] == "Blocked" for r in results) or
                    any(d.severity == "financial" for d in validation.diagnostics) else "Ready",
                "provenance": thaw_tree(validation.provenance), "diagnostics": [d.as_dict() for d in validation.diagnostics],
                "facilities": results,
                "limitations": ["No implicit alternate routings, stock transfers, cross-site staff, or cross-currency totals.",
                    "Whole-unit greedy allocation is order dependent and is not an optimum or intraday sequencing proof.",
                    "All BOM/quality authorization must be available at the opening of the start date; dated receipts are not borrowed backward.",
                    "Each offset operation fits one day bucket; intraday machine/crew synchronization, travel, scrap and partial modeled starting WIP are unsupported.",
                    "All occupied dates, including weekends and the explicit tail, are checked at full concurrent footprint and slots.",
                    "No future committed shipment/revenue is inferred from a successful calculation."]}
